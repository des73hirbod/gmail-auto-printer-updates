"""
Production-ready attachment handler with comprehensive validation and processing.
UPDATED: Better logging for copy tracking and improved error handling.
"""
import os
import base64
import logging
import asyncio
import traceback
import re
from pathlib import Path
from typing import Dict, Optional, List, Tuple
from googleapiclient.errors import HttpError

from config import Config
from utils import SystemUtils
from printer_manager import PrinterManager
from security_validator import SecurityValidator
from malware_scanner import MalwareScanner
from exceptions import AttachmentValidationError
from error_notifier import ErrorNotifier

logger = logging.getLogger(__name__)

class AttachmentHandler:
    """Handles email attachment processing with comprehensive validation."""
    
    def __init__(self, config: Config, gmail_client, printer_manager: PrinterManager, error_notifier: ErrorNotifier):
        """Initialize attachment handler with dependencies."""
        self.config = config
        self.gmail_client = gmail_client
        self.printer_manager = printer_manager
        self.error_notifier = error_notifier
        
        # Initialize security validator
        self.security_validator = SecurityValidator(config, error_notifier)
        
        # Initialize statistics
        self.stats = {
            'total_processed': 0,
            'successful_prints': 0,
            'validation_failures': 0,
            'print_failures': 0,
            'malware_detections': 0
        }
        
        logger.debug("AttachmentHandler initialized")

    def parse_subject_for_print_settings(self, subject: str, default_copies: int = 1, default_duplex: bool = False) -> Tuple[bool, int, bool]:
        """
        Parse email subject for print instructions.
        Returns (should_print, copies, duplex).
        
        Enhanced parsing to handle various formats:
        - "print 2 copies duplex"
        - "Print 14 copies duplex" 
        - "print two copies"
        - "Print duplex"
        - etc.
        """
        if not subject:
            return False, default_copies, default_duplex
        
        subject_lower = subject.lower()
        
        # Check if "print" is in subject (case-insensitive)
        should_print = "print" in subject_lower
        
        # If TARGET_SUBJECT is set, must match exactly (case-insensitive)
        if hasattr(self.config, 'TARGET_SUBJECT') and self.config.TARGET_SUBJECT:
            should_print = self.config.TARGET_SUBJECT.lower() in subject_lower
        
        if not should_print:
            return False, default_copies, default_duplex
        
        # Enhanced copy count parsing
        copies = default_copies
        
        # Look for patterns like "2 copies", "two copies", "print 2", "14 copies", etc.
        copy_patterns = [
            r"(\d+)\s*cop(?:y|ies)",           # "2 copies", "14 copies", "1 copy"
            r"print\s+(\d+)(?:\s+cop(?:y|ies))?",  # "print 2" or "print 2 copies"
            r"(\bone\b|\btwo\b|\bthree\b|\bfour\b|\bfive\b|\bsix\b|\bseven\b|\beight\b|\bnine\b|\bten\b)\s*cop(?:y|ies)"  # "two copies"
        ]
        
        for pattern in copy_patterns:
            match = re.search(pattern, subject_lower)
            if match:
                captured = match.group(1)
                if captured.isdigit():
                    copies = int(captured)
                    logger.debug(f"Found numeric copies: {copies}")
                    break
                else:
                    # Handle text numbers
                    number_map = {
                        "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
                        "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10
                    }
                    copies = number_map.get(captured, default_copies)
                    logger.debug(f"Found text copies: {captured} -> {copies}")
                    break
        
        # Check for duplex
        duplex = default_duplex
        if "duplex" in subject_lower or "double" in subject_lower or "both sides" in subject_lower:
            duplex = True
        
        # Ensure reasonable limits
        copies = max(1, min(copies, 20))  # Cap at 20 copies for safety
        
        logger.info(f"📋 Parsed subject '{subject}': print={should_print}, copies={copies}, duplex={duplex}")
        
        return should_print, copies, duplex

    async def download_attachments(self, message_id: str, msg: Dict, sender_email: str = None) -> int:
        """Download and process all valid attachments from an email."""
        attachment_count = 0
        payload = msg.get('payload', {})
        
        if not sender_email:
            headers = payload.get('headers', [])
            sender_email = self._extract_sender_email(headers)
        
        subject = self._extract_subject(payload.get('headers', []))
        logger.info(f"📧 Processing email from {sender_email}")
        logger.info(f"   Subject: {subject}")
        
        # Enhanced sender validation
        if not self._validate_sender(sender_email):
            logger.info(f"⏭️ Skipping email {message_id}: sender {sender_email} not allowed")
            return 0
        
        # Parse subject for print settings
        should_print, copies, duplex = self.parse_subject_for_print_settings(
            subject,
            default_copies=self.config.COPIES,
            default_duplex=self.config.ENABLE_DUPLEX
        )
        if not should_print:
            logger.info(f"⏭️ Skipping email {message_id}: 'print' not in subject or doesn't match TARGET_SUBJECT")
            return 0
        
        parts = self._get_email_parts(payload)
        if not parts:
            logger.info(f"📎 No attachments found in email {message_id}")
            return 0
        
        logger.info(f"📎 Found {len(parts)} potential attachments")
        
        for i, part in enumerate(parts, 1):
            filename = part.get('filename', '').strip()
            attachment_id = part.get('body', {}).get('attachmentId')
            mime_type = part.get('mimeType', '')
            
            if not filename or not attachment_id:
                logger.debug(f"Skipping part {i}: no filename or attachment ID")
                continue
            
            logger.info(f"🔄 Processing attachment {i}/{len(parts)}: {filename}")
            logger.info(f"   Will print {copies} copies, duplex={duplex}")
            
            try:
                self.stats['total_processed'] += 1
                
                success = await self._process_single_attachment(
                    message_id, attachment_id, filename, mime_type, sender_email,
                    copies=copies, duplex=duplex  # Pass parsed settings
                )
                
                if success:
                    attachment_count += 1
                    self.stats['successful_prints'] += 1
                    logger.info(f"✅ Successfully processed: {filename} ({copies} copies printed)")
                else:
                    logger.warning(f"❌ Failed to process: {filename}")
                    
            except Exception as e:
                logger.error(f"💥 Error processing attachment {filename}: {e}")
                await self.error_notifier.send_error_notification(
                    title="Attachment Processing Error",
                    error_message=f"Failed to process {filename}: {str(e)}",
                    stack_trace=traceback.format_exc(),
                    error_type="attachment_processing"
                )
                self.stats['validation_failures'] += 1
                continue
        
        if attachment_count > 0:
            total_copies = attachment_count * copies
            logger.info(f"🎉 Successfully processed {attachment_count} attachments from email {message_id}")
            logger.info(f"📄 Total physical copies printed: {total_copies} ({attachment_count} attachments × {copies} copies each)")
        else:
            logger.info(f"⚠️  No attachments could be processed from email {message_id}")
        
        return attachment_count

    def _validate_sender(self, sender_email: str) -> bool:
        """Validate sender email against configured restrictions."""
        if not sender_email or sender_email == 'unknown@unknown.com':
            logger.debug(f"Invalid sender email: {sender_email}")
            return False
        
        # If TARGET_SENDER is set, only allow that sender
        if hasattr(self.config, 'TARGET_SENDER') and self.config.TARGET_SENDER:
            if sender_email.lower() != self.config.TARGET_SENDER.lower():
                logger.debug(f"Sender {sender_email} doesn't match TARGET_SENDER {self.config.TARGET_SENDER}")
                return False
            else:
                logger.debug(f"✅ Sender {sender_email} matches TARGET_SENDER")
                return True
        
        # If ALLOWED_SENDER_DOMAINS is set, validate domain
        if hasattr(self.config, 'ALLOWED_SENDER_DOMAINS') and self.config.ALLOWED_SENDER_DOMAINS:
            sender_domain = sender_email.split('@')[1].lower() if '@' in sender_email else ''
            allowed_domains = [d.lower() for d in self.config.ALLOWED_SENDER_DOMAINS]
            if sender_domain not in allowed_domains:
                logger.debug(f"Sender domain {sender_domain} not in allowed domains: {allowed_domains}")
                return False
            else:
                logger.debug(f"✅ Sender domain {sender_domain} is allowed")
                return True
        
        # If no restrictions are set, allow all senders
        logger.debug(f"✅ No sender restrictions, allowing {sender_email}")
        return True

    async def _process_single_attachment(self, message_id: str, attachment_id: str, 
                                       filename: str, mime_type: str, sender_email: str,
                                       copies: int = 1, duplex: bool = False) -> bool:
        """Process a single attachment through the complete pipeline."""
        file_path = None
        
        try:
            logger.debug(f"Step 1: Validating filename and type for {filename}")
            if not self._validate_filename_and_type(filename, mime_type):
                self.stats['validation_failures'] += 1
                await self.error_notifier.send_error_notification(
                    title="Filename/Type Validation Failure",
                    error_message=f"Invalid filename or type: {filename}",
                    stack_trace="",
                    error_type="validation_failure"
                )
                return False
            
            logger.debug(f"✅ Filename and type validation passed: {filename}")
            
            logger.debug(f"Step 2: Downloading attachment {filename}")
            attachment_data = await self._fetch_attachment_data(message_id, attachment_id, filename)
            if not attachment_data:
                self.stats['validation_failures'] += 1
                return False
            
            size_mb = len(attachment_data) / (1024 * 1024)
            logger.debug(f"Step 3: Size check - {size_mb:.2f}MB")
            if size_mb > self.config.MAX_ATTACHMENT_SIZE_MB:
                logger.warning(f"❌ File too large: {filename} ({size_mb:.2f}MB > {self.config.MAX_ATTACHMENT_SIZE_MB}MB)")
                self.stats['validation_failures'] += 1
                await self.error_notifier.send_error_notification(
                    title="File Size Validation Failure",
                    error_message=f"File too large: {filename} ({size_mb:.2f}MB > {self.config.MAX_ATTACHMENT_SIZE_MB}MB)",
                    stack_trace="",
                    error_type="validation_failure"
                )
                return False
            
            logger.debug(f"Step 4: Saving to disk: {filename}")
            file_path = await self._save_attachment(filename, attachment_data)
            if not file_path:
                self.stats['validation_failures'] += 1
                return False
            
            logger.debug(f"✅ Saved attachment: {file_path}")
            
            logger.debug(f"Step 5: Security validation for {filename}")
            validation_result = await self.security_validator.validate_attachment(
                sender_email, filename, file_path
            )
            
            if not validation_result['is_valid']:
                logger.error(f"🛡️ Security validation failed for {filename}: {validation_result['details']}")
                self.stats['validation_failures'] += 1
                if 'malware' in validation_result['details'].lower():
                    self.stats['malware_detections'] += 1
                return False
            
            logger.debug(f"Step 6: Printing {filename} ({copies} copies, duplex={duplex})")
            print_success = await self._print_attachment(file_path, filename, copies, duplex)
            if not print_success:
                self.stats['print_failures'] += 1
                return False
            
            logger.info(f"✅ Complete pipeline success: {filename} - {copies} copies printed")
            return True
            
        except Exception as e:
            logger.error(f"💥 Error in attachment processing pipeline for {filename}: {e}")
            await self.error_notifier.send_error_notification(
                title="Attachment Processing Pipeline Error",
                error_message=f"Pipeline error for {filename}: {str(e)}",
                stack_trace=traceback.format_exc(),
                error_type="attachment_pipeline"
            )
            self.stats['validation_failures'] += 1
            return False
        finally:
            if file_path and file_path.exists():
                SystemUtils.cleanup_file(file_path)
                logger.debug(f"🧹 Cleaned up temporary file: {file_path}")

    async def _print_attachment(self, file_path: Path, filename: str, copies: int = 1, duplex: bool = False) -> bool:
        """Print the attachment using the printer manager."""
        try:
            if self.config.DRY_RUN:
                logger.info(f"DRY-RUN: Would print {filename} ({copies} copies, duplex={duplex})")
                return True
            
            logger.info(f"🖨️ Printing: {filename} ({copies} copies, duplex={duplex})")
            
            success = await self.printer_manager.print_file(
                file_path,
                copies=copies,
                duplex=duplex
            )
            
            if success:
                logger.info(f"✅ Print successful: {filename} - {copies} copies sent to printer")
            else:
                logger.error(f"❌ Print failed: {filename}")
                await self.error_notifier.send_error_notification(
                    title="Print Failure",
                    error_message=f"Failed to print {filename} ({copies} copies requested)",
                    stack_trace=traceback.format_exc(),
                    error_type="print_failure"
                )
                
            return success
            
        except Exception as e:
            logger.error(f"Error printing {filename}: {e}")
            await self.error_notifier.send_error_notification(
                title="Print Error",
                error_message=f"Error printing {filename}: {str(e)}",
                stack_trace=traceback.format_exc(),
                error_type="print_error"
            )
            return False

    def _extract_sender_email(self, headers: List[Dict]) -> str:
        """Extract sender email from headers."""
        for header in headers:
            if header.get('name', '').lower() == 'from':
                value = header.get('value', '')
                # Extract email from "Name <email@domain.com>" format
                if '<' in value and '>' in value:
                    start = value.find('<') + 1
                    end = value.find('>')
                    return value[start:end]
                return value
        return 'unknown@unknown.com'

    def _extract_subject(self, headers: List[Dict]) -> str:
        """Extract subject from headers."""
        for header in headers:
            if header.get('name', '').lower() == 'subject':
                return header.get('value', '')
        return ''

    def _get_email_parts(self, payload: Dict) -> List[Dict]:
        """Extract email parts that might contain attachments."""
        parts = []
        
        def extract_parts(part):
            if 'parts' in part:
                for subpart in part['parts']:
                    extract_parts(subpart)
            else:
                filename = part.get('filename', '')
                attachment_id = part.get('body', {}).get('attachmentId')
                if filename and attachment_id:
                    parts.append(part)
        
        extract_parts(payload)
        return parts

    def _validate_filename_and_type(self, filename: str, mime_type: str) -> bool:
        """Basic filename and MIME type validation."""
        if not filename or not filename.strip():
            return False
        
        # Check for dangerous characters
        dangerous_chars = ['<', '>', ':', '"', '|', '?', '*', '\0']
        for char in dangerous_chars:
            if char in filename:
                logger.warning(f"Dangerous character '{char}' in filename: {filename}")
                return False
        
        # Check file extension
        if not self.config.ALLOW_ALL_FILE_TYPES:
            file_ext = SystemUtils.get_file_extension(filename)
            if not file_ext or file_ext.lower() not in [ext.lower() for ext in self.config.ALLOWED_FILE_TYPES]:
                logger.warning(f"File type not allowed: {file_ext}")
                return False
        
        return True

    async def _fetch_attachment_data(self, message_id: str, attachment_id: str, filename: str) -> Optional[bytes]:
        """Fetch attachment data from Gmail."""
        try:
            if self.config.DRY_RUN:
                logger.debug(f"DRY-RUN: Would download attachment {filename}")
                return b"dummy_data_for_dry_run"
            
            attachment = await asyncio.to_thread(
                self.gmail_client.service.users().messages().attachments().get,
                userId='me',
                messageId=message_id,
                id=attachment_id
            )
            
            result = await asyncio.to_thread(attachment.execute)
            data = base64.urlsafe_b64decode(result['data'])
            logger.debug(f"Downloaded {len(data)} bytes for {filename}")
            return data
            
        except Exception as e:
            logger.error(f"Failed to download attachment {filename}: {e}")
            return None

    async def _save_attachment(self, filename: str, data: bytes) -> Optional[Path]:
        """Save attachment data to disk."""
        try:
            # Sanitize filename
            safe_filename = SystemUtils.sanitize_filename(filename)
            file_path = self.config.DOWNLOAD_DIR / safe_filename
            
            # Ensure unique filename
            counter = 1
            original_path = file_path
            while file_path.exists():
                stem = original_path.stem
                suffix = original_path.suffix
                file_path = original_path.parent / f"{stem}_{counter}{suffix}"
                counter += 1
            
            # Write file
            await asyncio.to_thread(file_path.write_bytes, data)
            logger.debug(f"Saved attachment to {file_path}")
            return file_path
            
        except Exception as e:
            logger.error(f"Failed to save attachment {filename}: {e}")
            return None

    async def cleanup(self):
        """Cleanup attachment handler resources."""
        try:
            # Cleanup any temporary files
            if hasattr(self.config, 'DOWNLOAD_DIR') and self.config.DOWNLOAD_DIR.exists():
                temp_files = list(self.config.DOWNLOAD_DIR.glob('*'))
                for temp_file in temp_files:
                    try:
                        if temp_file.is_file():
                            temp_file.unlink()
                    except Exception as e:
                        logger.debug(f"Could not cleanup {temp_file}: {e}")
            
            logger.debug("AttachmentHandler cleanup completed")
        except Exception as e:
            logger.error(f"Error during attachment handler cleanup: {e}")

    def get_stats(self) -> Dict:
        """Get attachment processing statistics."""
        return self.stats.copy()
"""
Attachment handler for processing email attachments.
"""
import asyncio
import logging
import base64
import re
import json
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from datetime import datetime
import img2pdf
from utils import SystemUtils
from docx_converter import DocxConverter
from printer_manager import PrinterManager
from security_validator import SecurityValidator
from rapidfuzz import fuzz  # Added for parse_print_subject

logger = logging.getLogger(__name__)

def parse_print_subject(subject: str, max_copies: int = 50, default_copies: int = 1, default_duplex: bool = False):
    """
    Parses an email subject for a print command with fuzzy matching on 'print'.
    Enforces:
      - 'print' (or fuzzy match, 85%+ similarity) appears before any number or duplex keywords.
      - Copies: digits or spelled numbers (up to 20).
      - Duplex detection with multiple keywords.
      - Validation of copies count and single number rule.
    
    Args:
        subject: Email subject string.
        max_copies: Maximum allowed copies (default: 50).
        default_copies: Default number of copies (default: 1).
        default_duplex: Default duplex setting (default: False).
    
    Returns:
        dict with keys {"copies": int, "duplex": bool} on success,
        or {"error": str} on failure.
    """
    if not isinstance(subject, str):
        logger.warning("Subject parsing failed: Subject must be a string")
        return {"error": "Subject must be a string"}

    if not subject.strip():
        logger.warning("Subject parsing failed: Empty or whitespace-only subject")
        return {"error": "Empty or whitespace-only subject"}

    # Normalize subject: lowercase, preserve hyphens for duplex terms, replace other punctuation
    normalized = ''.join(ch.lower() if ch.isalnum() or ch in (' ', '-') else ' ' for ch in subject)
    tokens = normalized.split()

    # Config
    VALID_TRIGGERS = ["print"]
    DUPLEX_WORDS = {"duplex", "double", "two-sided", "twosided", "two sided"}
    NUMBER_WORDS = {
        "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
        "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
        "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
        "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18,
        "nineteen": 19, "twenty": 20
    }

    def is_fuzzy_print(word, max_tokens=5):
        # Limit fuzzy matching to first max_tokens to optimize performance
        if tokens.index(word) >= max_tokens:
            return False
        return any(fuzz.partial_ratio(word, t) >= 85 for t in VALID_TRIGGERS)

    # Find the first token that fuzzily matches print
    print_index = None
    for i, token in enumerate(tokens):
        if is_fuzzy_print(token):
            print_index = i
            break
    if print_index is None:
        logger.warning(f"Subject parsing failed for '{subject}': No print trigger found")
        return {"error": "No print trigger found"}

    # Enforce order: no number or duplex tokens before print
    def is_number_token(tok):
        return tok.isdigit() or tok in NUMBER_WORDS

    def is_duplex_token(tok):
        return tok in DUPLEX_WORDS

    for i, tok in enumerate(tokens):
        if i >= print_index:
            break
        if is_number_token(tok) or is_duplex_token(tok):
            logger.warning(f"Subject parsing failed for '{subject}': Number or duplex token before print trigger")
            return {"error": "Number or duplex token before print trigger"}

    # Parse tokens after print_index for copies and duplex
    copies = default_copies
    duplex = default_duplex
    number_found = False

    i = print_index + 1
    while i < len(tokens):
        tok = tokens[i]

        # Check for number token if no number found yet
        if not number_found and is_number_token(tok):
            if tok.isdigit():
                copies_candidate = int(tok)
            else:
                copies_candidate = NUMBER_WORDS.get(tok, default_copies)

            if copies_candidate <= 0:
                logger.warning(f"Subject parsing failed for '{subject}': Invalid copies count ({copies_candidate})")
                return {"error": f"Invalid copies count ({copies_candidate})"}
            if copies_candidate > max_copies:
                logger.warning(f"Subject parsing failed for '{subject}': Copies count exceeds max limit ({max_copies})")
                return {"error": f"Copies count exceeds max limit ({max_copies})"}

            copies = copies_candidate
            number_found = True

            # Skip 'copies' word if present
            if i + 1 < len(tokens) and re.match(r"copp?ies?|copys?|copie|copi", tokens[i + 1]):
                i += 1

        elif is_duplex_token(tok):
            duplex = True

        # Check for additional numbers to reject ambiguity
        elif number_found and is_number_token(tok):
            logger.warning(f"Subject parsing failed for '{subject}': Multiple numbers found")
            return {"error": "Multiple numbers found in subject"}

        i += 1

    logger.debug(f"Parsed subject '{subject}': copies={copies}, duplex={duplex}")
    return {"copies": copies, "duplex": duplex}

class AttachmentHandler:
    """Handles email attachment processing, validation, and printing."""
    
    def __init__(self, config, args, docx_converter: DocxConverter, printer_manager: PrinterManager, error_notifier, security_validator: SecurityValidator):
        self.config = config
        self.args = args
        self.docx_converter = docx_converter
        self.printer_manager = printer_manager
        self.error_notifier = error_notifier
        self.security_validator = security_validator
        self.processed_count = 0
        self.successful_prints = 0
        self.validation_failures = 0
        self.download_dir = Path(self.config.DOWNLOAD_DIR)
        self.processed_ids_file = Path(self.config.PROCESSED_IDS_FILE)
        self.processed_ids = self._load_processed_ids()
        logger.debug("AttachmentHandler initialized")

    def _load_processed_ids(self) -> set:
        """Load processed email IDs from file."""
        try:
            if self.processed_ids_file.exists():
                with open(self.processed_ids_file, 'r') as f:
                    content = f.read().strip()
                    if not content:  # Handle empty file
                        logger.debug("Processed IDs file is empty, starting with empty set")
                        return set()
                    return set(json.loads(content))
            else:
                logger.debug("Processed IDs file does not exist, starting with empty set")
                return set()
        except json.JSONDecodeError as e:
            logger.warning(f"Corrupted processed IDs file, resetting: {e}")
            # Reset corrupted file
            try:
                with open(self.processed_ids_file, 'w') as f:
                    json.dump([], f)
            except Exception as write_e:
                logger.error(f"Failed to reset processed IDs file: {write_e}")
            return set()
        except Exception as e:
            logger.error(f"Error loading processed IDs: {e}")
            return set()

    def _save_processed_ids(self):
        """Save processed email IDs to file."""
        try:
            # Ensure directory exists
            self.processed_ids_file.parent.mkdir(parents=True, exist_ok=True)
            
            # Write to temporary file first, then rename for atomic operation
            temp_file = self.processed_ids_file.with_suffix('.tmp')
            with open(temp_file, 'w') as f:
                json.dump(list(self.processed_ids), f, indent=2)
            
            # Atomic rename
            temp_file.replace(self.processed_ids_file)
            logger.debug(f"Saved {len(self.processed_ids)} processed IDs to file")
            
        except Exception as e:
            logger.error(f"Error saving processed IDs: {e}")
            # Clean up temp file if it exists
            temp_file = self.processed_ids_file.with_suffix('.tmp')
            if temp_file.exists():
                try:
                    temp_file.unlink()
                except:
                    pass

    async def process_email(self, email_data: Dict, gmail_service) -> Tuple[int, int]:
        """Process a single email and its attachments."""
        try:
            message_id = email_data.get('id')
            if message_id in self.processed_ids:
                logger.debug(f"Skipping already processed email: {message_id}")
                return 0, 0

            sender = self._get_sender(email_data)
            if not self._validate_sender(sender):
                logger.info(f"⏭️ Skipping email {message_id}: sender {sender} not allowed")
                return 0, 0

            subject = self._get_subject(email_data)
            logger.info(f"📧 Processing email from {sender}")
            logger.info(f"   Subject: {subject}")

            copies, duplex = self._parse_subject(subject)
            logger.info(f"📋 Parsed subject '{subject}': print=True, copies={copies}, duplex={duplex}")

            attachments = self._get_attachments(email_data)
            logger.info(f"📎 Found {len(attachments)} potential attachments")

            total_copies = 0
            successful_attachments = 0

            for idx, attachment in enumerate(attachments, 1):
                logger.info(f"🔄 Processing attachment {idx}/{len(attachments)}: {attachment['filename']}")
                logger.info(f"   Will print {copies} copies, duplex={duplex}")
                success = await self._process_single_attachment(attachment, message_id, gmail_service, copies, duplex)
                if success:
                    successful_attachments += 1
                    total_copies += copies
                else:
                    self.validation_failures += 1

            self.processed_ids.add(message_id)
            self._save_processed_ids()
            logger.info(f"🎉 Successfully processed {successful_attachments} attachments from email {message_id}")
            logger.info(f"📄 Total physical copies printed: {total_copies} ({successful_attachments} attachments × {copies} copies each)")
            return successful_attachments, total_copies

        except Exception as e:
            logger.error(f"Error processing email {message_id}: {e}")
            await self.error_notifier.send_error_notification(
                title="Email Processing Error",
                error_message=f"Failed to process email {message_id}: {str(e)}",
                stack_trace="",
                error_type="email_processing_error"
            )
            return 0, 0

    def _get_sender(self, email_data: Dict) -> str:
        """Extract sender email from email data."""
        headers = email_data.get('payload', {}).get('headers', [])
        for header in headers:
            if header.get('name', '').lower() == 'from':
                return SystemUtils.decode_email_header(header.get('value', ''))
        return ""

    def _validate_sender(self, sender: str) -> bool:
        """Validate if sender is allowed."""
        if not self.config.TARGET_SENDER:
            return True
        sender_email = sender.lower().split('<')[-1].strip('>').strip()
        logger.debug(f"Validating sender: {sender_email} against {self.config.TARGET_SENDER}")
        return sender_email == self.config.TARGET_SENDER.lower()

    def _get_subject(self, email_data: Dict) -> str:
        """Extract subject from email data."""
        headers = email_data.get('payload', {}).get('headers', [])
        for header in headers:
            if header.get('name', '').lower() == 'subject':
                return SystemUtils.decode_email_header(header.get('value', ''))
        return ""

    def _parse_subject(self, subject: str) -> Tuple[int, bool]:
        """Parse subject line for print instructions using parse_print_subject."""
        result = parse_print_subject(
            subject,
            max_copies=getattr(self.config, 'MAX_COPIES', 50),
            default_copies=self.config.COPIES,
            default_duplex=self.config.ENABLE_DUPLEX
        )
        if "error" in result:
            logger.warning(f"Subject parsing failed: {result['error']}")
            return self.config.COPIES, self.config.ENABLE_DUPLEX
        return result["copies"], result["duplex"]

    def _is_allowed_file_type(self, filename: str, mime_type: str) -> bool:
        """
        Check if file type is allowed based on both filename extension and MIME type.
        This handles the proper detection of Word documents and other file types.
        """
        if not filename:
            return False
            
        # Get file extension
        file_ext = SystemUtils.get_file_extension(filename).lower()
        
        # Check if extension is in allowed list
        if file_ext not in self.config.ALLOWED_FILE_TYPES:
            return False
        
        # Define MIME type mappings for better detection
        mime_type_mappings = {
            '.pdf': ['application/pdf'],
            '.jpg': ['image/jpeg'],
            '.jpeg': ['image/jpeg'],
            '.png': ['image/png'],
            '.docx': [
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'application/octet-stream'  # Sometimes .docx files are sent with this generic MIME type
            ],
            '.doc': [
                'application/msword',
                'application/octet-stream'  # Sometimes .doc files are sent with this generic MIME type
            ]
        }
        
        # If we have a MIME type mapping for this extension, verify it matches
        if file_ext in mime_type_mappings:
            expected_mimes = mime_type_mappings[file_ext]
            if mime_type and mime_type.lower() not in [m.lower() for m in expected_mimes]:
                logger.debug(f"MIME type mismatch for {filename}: got '{mime_type}', expected one of {expected_mimes}")
                # For Word documents, be more lenient with MIME type checking
                # as some email clients send them with generic MIME types
                if file_ext in ['.docx', '.doc']:
                    logger.debug(f"Allowing Word document {filename} despite MIME type mismatch")
                    return True
                return False
        
        return True

    def _get_attachments(self, email_data: Dict) -> List[Dict]:
        """Extract attachments from email data with improved Word document detection."""
        attachments = []
        payload = email_data.get('payload', {})
        
        # Check if the main payload itself is an attachment (single attachment emails)
        if payload.get('filename') and payload.get('body', {}).get('attachmentId'):
            filename = payload.get('filename', '')
            mime_type = payload.get('mimeType', '')
            
            logger.debug(f"Found potential main attachment: {filename} (MIME: {mime_type})")
            
            if self._is_allowed_file_type(filename, mime_type):
                logger.debug(f"✅ Main attachment accepted: {filename}")
                attachments.append({
                    'filename': filename,
                    'attachmentId': payload.get('body').get('attachmentId'),
                    'mimeType': mime_type
                })
            else:
                logger.debug(f"❌ Main attachment rejected: {filename} (MIME: {mime_type})")
        
        # Process parts recursively
        parts = payload.get('parts', [])
        
        def process_part(part, attachments, depth=0):
            indent = "  " * depth
            part_filename = part.get('filename', '')
            part_mime = part.get('mimeType', '')
            attachment_id = part.get('body', {}).get('attachmentId')
            
            logger.debug(f"{indent}Processing part: filename='{part_filename}', mime='{part_mime}', has_attachment_id={bool(attachment_id)}")
            
            # Check if this part has an attachment
            if part_filename and attachment_id:
                logger.debug(f"{indent}Found potential attachment: {part_filename} (MIME: {part_mime})")
                
                if self._is_allowed_file_type(part_filename, part_mime):
                    logger.debug(f"{indent}✅ Attachment accepted: {part_filename}")
                    attachments.append({
                        'filename': part_filename,
                        'attachmentId': attachment_id,
                        'mimeType': part_mime
                    })
                else:
                    logger.debug(f"{indent}❌ Attachment rejected: {part_filename} (MIME: {part_mime})")
            
            # Process nested parts
            for subpart in part.get('parts', []):
                process_part(subpart, attachments, depth + 1)

        for part in parts:
            process_part(part, attachments)
        
        logger.debug(f"Total attachments found: {len(attachments)}")
        for att in attachments:
            logger.debug(f"  - {att['filename']} (MIME: {att['mimeType']})")
        
        return attachments

    async def _process_single_attachment(self, attachment: Dict, message_id: str, gmail_service, copies: int, duplex: bool) -> bool:
        """Process a single attachment through the pipeline."""
        filename = attachment['filename']
        attachment_id = attachment['attachmentId']
        save_path = None
        temp_pdf_path = None
        
        try:
            logger.debug(f"Step 1: Validating filename and type for {filename}")
            if not self._validate_filename_and_type(filename):
                logger.error(f"File type not allowed: {SystemUtils.get_file_extension(filename)}")
                await self.error_notifier.send_error_notification(
                    title="Attachment Processing Error",
                    error_message=f"Invalid filename or type: {filename}",
                    stack_trace="",
                    error_type="attachment_processing_error"
                )
                return False
            logger.debug(f"✅ Filename and type validation passed: {filename}")

            logger.debug(f"Step 2: Downloading attachment {filename}")
            attachment_data = await self._download_attachment(gmail_service, message_id, attachment_id)
            if not attachment_data:
                logger.error(f"Failed to download attachment: {filename}")
                return False

            logger.debug(f"Step 3: Size check - {len(attachment_data) / 1024 / 1024:.2f}MB")
            if len(attachment_data) > self.config.MAX_ATTACHMENT_SIZE_MB * 1024 * 1024:
                logger.error(f"Attachment {filename} exceeds size limit: {len(attachment_data) / 1024 / 1024:.2f}MB")
                await self.error_notifier.send_error_notification(
                    title="Attachment Processing Error",
                    error_message=f"Attachment {filename} exceeds size limit: {len(attachment_data) / 1024 / 1024:.2f}MB",
                    stack_trace="",
                    error_type="attachment_processing_error"
                )
                return False

            logger.debug(f"Step 4: Saving to disk: {filename}")
            save_path = self._get_unique_filepath(filename)
            with open(save_path, 'wb') as f:
                f.write(attachment_data)
            logger.debug(f"Saved attachment to {save_path}")
            logger.debug(f"✅ Saved attachment: {save_path}")

            logger.debug(f"Step 5: Security validation for {filename}")
            if self.config.ENABLE_MALWARE_SCAN and not self.config.DISABLE_MALWARE_SCAN:
                validation_result = await self.security_validator.validate_attachment(
                    sender_email=self._get_sender({'id': message_id}),
                    filename=filename,
                    file_path=save_path
                )
                if not validation_result['is_valid']:
                    logger.error(f"Security validation failed for {filename}: {validation_result['details']}")
                    await self.error_notifier.send_error_notification(
                        title="Attachment Processing Error",
                        error_message=f"Security validation failed for {filename}: {validation_result['details']}",
                        stack_trace="",
                        error_type="attachment_processing_error"
                    )
                    if not self.args.debug:
                        save_path.unlink(missing_ok=True)
                    return False
            else:
                logger.debug(f"Skipping security validation for {filename}: malware scanning disabled")

            logger.debug(f"Step 6: Printing {filename} ({copies} copies, duplex={duplex})")
            logger.info(f"🖨️ Printing: {filename} ({copies} copies, duplex={duplex})")
            
            final_path = save_path
            if filename.lower().endswith(('.docx', '.doc')):
                temp_pdf_path = save_path.with_name(f"{save_path.stem}_temp.pdf")
                logger.info(f"Converting DOCX to PDF: {filename}")
                success = await self.docx_converter.convert_to_pdf(save_path, temp_pdf_path)
                if not success:
                    logger.error(f"Failed to convert {filename} to PDF")
                    await self.error_notifier.send_error_notification(
                        title="Attachment Processing Error",
                        error_message=f"Failed to convert {filename} to PDF",
                        stack_trace="",
                        error_type="attachment_processing_error"
                    )
                    if not self.args.debug:
                        save_path.unlink(missing_ok=True)
                    return False
                final_path = temp_pdf_path
                logger.info(f"Conversion successful, PDF size: {temp_pdf_path.stat().st_size} bytes")
            elif filename.lower().endswith(('.jpg', '.jpeg', '.png')):
                temp_pdf_path = save_path.with_name(f"{save_path.stem}_temp.pdf")
                with open(temp_pdf_path, 'wb') as f:
                    f.write(img2pdf.convert(save_path))
                final_path = temp_pdf_path

            success = await self.printer_manager.print_file(final_path, copies=copies, duplex=duplex)
            if success:
                logger.info(f"✅ Print successful: {filename} - {copies} copies sent to printer")
                logger.info(f"✅ Complete pipeline success: {filename} - {copies} copies printed")
                self.successful_prints += 1
            else:
                logger.error(f"Failed to print {filename}")
                await self.error_notifier.send_error_notification(
                    title="Attachment Processing Error",
                    error_message=f"Failed to print {filename}",
                    stack_trace="",
                    error_type="attachment_processing_error"
                )
                return False

            return True

        except Exception as e:
            logger.error(f"Failed to process attachment {filename}: {str(e)}")
            await self.error_notifier.send_error_notification(
                title="Attachment Processing Error",
                error_message=f"Failed to process attachment {filename}: {str(e)}",
                stack_trace="",
                error_type="attachment_processing_error"
            )
            return False
        finally:
            # Clean up files if not in debug mode
            if not self.args.debug:
                if save_path and save_path.exists():
                    save_path.unlink(missing_ok=True)
                if temp_pdf_path and temp_pdf_path.exists():
                    temp_pdf_path.unlink(missing_ok=True)

    def _validate_filename_and_type(self, filename: str) -> bool:
        """Validate filename and file type."""
        if not filename:
            return False
        file_ext = SystemUtils.get_file_extension(filename).lower()
        return file_ext in self.config.ALLOWED_FILE_TYPES

    async def _download_attachment(self, gmail_service, message_id: str, attachment_id: str) -> Optional[bytes]:
        """Download attachment from Gmail."""
        try:
            attachment = gmail_service.users().messages().attachments().get(
                userId='me', messageId=message_id, id=attachment_id
            ).execute()
            data = attachment.get('data')
            if data:
                return base64.urlsafe_b64decode(data)
            return None
        except Exception as e:
            logger.error(f"Error downloading attachment {attachment_id}: {e}")
            return None

    def _get_unique_filepath(self, filename: str) -> Path:
        """Generate a unique filepath for the attachment."""
        base_path = self.download_dir / filename
        if not base_path.exists():
            return base_path
        stem = base_path.stem
        suffix = base_path.suffix
        counter = 1
        while True:
            new_path = self.download_dir / f"{stem}_{counter}{suffix}"
            if not new_path.exists():
                return new_path
            counter += 1

    def get_stats(self) -> Dict:
        """Return processing statistics."""
        return {
            "processed_count": self.processed_count,
            "successful_prints": self.successful_prints,
            "validation_failures": self.validation_failures
        }

    async def cleanup(self):
        """Clean up resources."""
        logger.debug("AttachmentHandler cleanup completed")
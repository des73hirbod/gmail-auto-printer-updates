# Gmail Auto Printer

**Gmail Auto Printer** is a production-ready Python application that automatically monitors a Gmail inbox for emails with specific criteria (e.g., sender or subject), downloads attachments, validates their security, converts them to PDF if needed, and prints them to a specified printer. It supports PDF, DOCX, DOC, JPG, JPEG, PNG, and TXT files, with robust error handling, security validation, and automatic updates.

## Features

- **Email Monitoring**: Polls Gmail inbox for unread emails with configurable sender or subject filters.
- **Attachment Processing**: Downloads and processes attachments, converting DOCX and images to PDF for printing.
- **Security Validation**: Performs filename, file type, sender, and malware checks (using Windows Defender).
- **Printing**: Supports multiple printing methods (Adobe Reader, SumatraPDF, PowerShell) with retry logic.
- **Auto Updates**: Checks for updates from a configured repository and applies them automatically.
- **Error Notifications**: Sends error notifications via webhook or email.
- **Configuration**: Highly configurable via `.env` file with comprehensive validation.
- **Dry Run Mode**: Simulates operations without printing or modifying emails for testing.
- **Logging**: Detailed logging for debugging and monitoring.

## Requirements

### Software
- **Python 3.8 or newer** (3.12 recommended, 3.13 may have compatibility issues with `comtypes`).
- **Windows Operating System** (due to reliance on `pywin32` and Windows Defender).
- **Gmail API Credentials** (`credentials.json` from Google Cloud Console).
- **Printer**: A configured printer (e.g., Microsoft Print to PDF or a physical printer).
- **Optional External Tools**:
  - SumatraPDF (for PDF printing, configured via `SUMATRA_PDF_PATH` in `.env`).
  - Microsoft Word (for DOCX conversion).
  - Adobe Acrobat Reader (for alternative PDF printing).

### Python Dependencies
See `requirements.txt` for a complete list. Install with:
```bash
pip install -r requirements.txt
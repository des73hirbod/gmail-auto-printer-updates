"""
Auto-updater for the Gmail Auto Printer system.
"""
import asyncio
import logging
import json
import tempfile
import zipfile
import shutil
from pathlib import Path
from typing import Optional, Dict
import aiohttp
import time
from utils import SystemUtils
logger = logging.getLogger(__name__)
class AutoUpdater:
    """Handles automatic updates for the application."""
    PROTECTED_FILES = {
        '.env', 'credentials.json', 'token.json', 
        'processed_ids.json', 'update_check.json'
    }
    def __init__(self, config, error_notifier):
        self.config = config
        self.error_notifier = error_notifier
        self.last_check_file = Path('update_check.json')
        self.current_version = SystemUtils.get_version()
    async def check_for_updates(self) -> bool:
        """Check for updates if enough time has passed."""
        if not self.config.ENABLE_AUTO_UPDATE:
            logger.debug("Auto-updates disabled")
            return False
        if not self.config.UPDATE_REPOSITORY_URL:
            logger.debug("No update repository URL configured")
            return False
        # Check if enough time has passed since last check
        if not self._should_check_for_updates():
            logger.debug("Too soon for update check")
            return False
        try:
            logger.info("Checking for updates...")
            update_available = await self._check_remote_version()
            if update_available:
                logger.info("Update available, starting download...")
                success = await self._download_and_apply_update()
                if success:
                    logger.info("Update applied successfully")
                    await self.error_notifier.send_notification(
                        "Update Applied Successfully",
                        f"Gmail Auto Printer updated to latest version",
                        "info"
                    )
                    return True
                else:
                    logger.error("Update failed")
                    return False
            else:
                logger.info("No updates available")
                return False
        except Exception as e:
            logger.error(f"Update check failed: {e}")
            await self.error_notifier.send_error_notification(
                "Update Check Failed",
                str(e),
                ""
            )
            return False
        finally:
            self._save_last_check_time()
    def _should_check_for_updates(self) -> bool:
        """Check if enough time has passed since last update check."""
        try:
            if not self.last_check_file.exists():
                return True
            with open(self.last_check_file, 'r') as f:
                data = json.load(f)
            last_check = data.get('last_check', 0)
            check_interval = self.config.UPDATE_CHECK_INTERVAL_HOURS * 3600
            return (time.time() - last_check) > check_interval
        except Exception:
            return True
    def _save_last_check_time(self):
        """Save the last update check time."""
        try:
            data = {
                'last_check': time.time(),
                'version': self.current_version
            }
            with open(self.last_check_file, 'w') as f:
                json.dump(data, f)
        except Exception as e:
            logger.warning(f"Failed to save last check time: {e}")
    async def _check_remote_version(self) -> bool:
        """Check if a newer version is available."""
        try:
            # This is a simplified version - in production you'd check GitHub releases
            # or your update server for version information
            version_url = f"{self.config.UPDATE_REPOSITORY_URL}/raw/{self.config.UPDATE_BRANCH}/version.txt"
            async with aiohttp.ClientSession() as session:
                async with session.get(version_url, timeout=30) as response:
                    if response.status == 200:
                        remote_version = (await response.text()).strip()
                        logger.info(f"Current: {self.current_version}, Remote: {remote_version}")
                        return self._compare_versions(self.current_version, remote_version)
                    else:
                        logger.warning(f"Failed to fetch remote version: HTTP {response.status}")
                        return False
        except Exception as e:
            logger.error(f"Error checking remote version: {e}")
            return False
    def _compare_versions(self, current: str, remote: str) -> bool:
        """Compare version strings (simplified semantic versioning)."""
        try:
            current_parts = [int(x) for x in current.split('.')]
            remote_parts = [int(x) for x in remote.split('.')]
            # Pad shorter version with zeros
            max_len = max(len(current_parts), len(remote_parts))
            current_parts.extend([0] * (max_len - len(current_parts)))
            remote_parts.extend([0] * (max_len - len(remote_parts)))
            return remote_parts > current_parts
        except Exception as e:
            logger.error(f"Error comparing versions: {e}")
            return False
    async def _download_and_apply_update(self) -> bool:
        """Download and apply the update."""
        temp_dir = None
        try:
            # Create temporary directory
            temp_dir = Path(tempfile.mkdtemp(prefix="gmail_printer_update_"))
            # Download update package
            download_url = f"{self.config.UPDATE_REPOSITORY_URL}/archive/{self.config.UPDATE_BRANCH}.zip"
            update_file = temp_dir / "update.zip"
            logger.info(f"Downloading update from {download_url}")
            async with aiohttp.ClientSession() as session:
                async with session.get(download_url, timeout=300) as response:
                    if response.status != 200:
                        logger.error(f"Download failed: HTTP {response.status}")
                        return False
                    with open(update_file, 'wb') as f:
                        async for chunk in response.content.iter_chunked(8192):
                            f.write(chunk)
            # Extract update
            extract_dir = temp_dir / "extracted"
            with zipfile.ZipFile(update_file, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)
            # Find the actual update directory (GitHub adds a folder name)
            update_dirs = list(extract_dir.iterdir())
            if not update_dirs:
                logger.error("No content in update package")
                return False
            update_source = update_dirs[0]
            # Apply update
            return await self._apply_update_files(update_source)
        except Exception as e:
            logger.error(f"Update download/apply failed: {e}")
            return False
        finally:
            # Cleanup
            if temp_dir and temp_dir.exists():
                try:
                    shutil.rmtree(temp_dir)
                except Exception as e:
                    logger.warning(f"Failed to cleanup temp directory: {e}")
    async def _apply_update_files(self, update_source: Path) -> bool:
        """Apply update files to current directory."""
        try:
            current_dir = Path.cwd()
            updated_files = []
            # Copy new/updated files
            for source_file in update_source.rglob('*'):
                if source_file.is_file():
                    relative_path = source_file.relative_to(update_source)
                    # Skip protected files
                    if relative_path.name in self.PROTECTED_FILES:
                        logger.info(f"Skipping protected file: {relative_path}")
                        continue
                    # Skip certain directories
                    if any(part.startswith('.') for part in relative_path.parts):
                        continue
                    if 'logs' in relative_path.parts:
                        continue
                    target_file = current_dir / relative_path
                    # Create directory if needed
                    target_file.parent.mkdir(parents=True, exist_ok=True)
                    # Backup existing file
                    if target_file.exists():
                        backup_file = target_file.with_suffix(target_file.suffix + '.backup')
                        shutil.copy2(target_file, backup_file)
                    # Copy new file
                    shutil.copy2(source_file, target_file)
                    updated_files.append(str(relative_path))
                    logger.debug(f"Updated: {relative_path}")
            logger.info(f"Updated {len(updated_files)} files")
            return True
        except Exception as e:
            logger.error(f"Failed to apply update files: {e}")
            return False

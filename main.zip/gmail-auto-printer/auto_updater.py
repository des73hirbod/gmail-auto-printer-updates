import asyncio
import logging
import json
import tempfile
import zipfile
import shutil
from pathlib import Path
from typing import Optional, Dict
import aiohttp
import time
import hashlib
import subprocess
from packaging import version
from tenacity import retry, stop_after_attempt, wait_exponential
from utils import SystemUtils

logger = logging.getLogger(__name__)

class AutoUpdater:
    """Handles automatic updates for the application."""
    PROTECTED_FILES = {
        '.env', 'credentials.json', 'token.json', 
        'processed_ids.json', 'update_check.json'
    }

    def __init__(self, config, error_notifier):
        self.config = config
        self.error_notifier = error_notifier
        self.last_check_file = Path('update_check.json')
        self.current_version = SystemUtils.get_version()
        self.expected_hash = None
        self.last_check_time = None

    async def check_for_updates(self) -> bool:
        """Check for updates if enough time has passed."""
        if not self.config.ENABLE_AUTO_UPDATE:
            logger.debug("Auto-updates disabled")
            return False
        if not self.config.UPDATE_REPOSITORY_URL:
            logger.debug("No update repository URL configured")
            return False
        if not self.config.UPDATE_REPOSITORY_URL.startswith("https://"):
            logger.error("Update repository URL must use HTTPS")
            return False
        if not self._should_check_for_updates():
            logger.debug("Too soon for update check")
            return False
        try:
            logger.info("Checking for updates...")
            if not await self._check_remote_version():
                logger.info("No updates available")
                return False
            logger.info("Update available, starting download...")
            if not await self._download_and_apply_update():
                logger.error("Update failed")
                return False
            logger.info("Update applied successfully")
            if self.error_notifier:
                await self.error_notifier.send_notification(
                    "Update Applied Successfully",
                    f"Gmail Auto Printer updated to latest version",
                    "info"
                )
            await self._restart_application()
            return True
        except Exception as e:
            logger.error(f"Update check failed: {e}")
            if self.error_notifier:
                await self.error_notifier.send_error_notification(
                    "Update Check Failed",
                    str(e),
                    "",
                    error_type="auto_update"
                )
            return False
        finally:
            self._save_last_check_time()

    def _should_check_for_updates(self) -> bool:
        """Check if enough time has passed since last update check."""
        try:
            if not self.last_check_file.exists():
                return True
            with open(self.last_check_file, 'r') as f:
                data = json.load(f)
            last_check = data.get('last_check', 0)
            check_interval = self.config.UPDATE_CHECK_INTERVAL_HOURS * 3600
            return (time.time() - last_check) > check_interval
        except Exception:
            logger.warning("Failed to read update_check.json, allowing update check")
            return True

    def _save_last_check_time(self):
        """Save the last update check time atomically."""
        try:
            temp_file = self.last_check_file.with_suffix('.tmp')
            with open(temp_file, 'w') as f:
                json.dump({'last_check': time.time(), 'version': self.current_version}, f)
            shutil.move(temp_file, self.last_check_file)
            self.last_check_time = time.time()
        except PermissionError:
            logger.warning("No write permission for update_check.json, using in-memory tracking")
            self.last_check_time = time.time()
        except Exception as e:
            logger.warning(f"Failed to save last check time: {e}")

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
    async def _check_remote_version(self) -> bool:
        """Check if a newer version is available."""
        try:
            version_url = f"{self.config.UPDATE_REPOSITORY_URL}/raw/{self.config.UPDATE_BRANCH}/version.txt"
            hash_url = f"{self.config.UPDATE_REPOSITORY_URL}/raw/{self.config.UPDATE_BRANCH}/version.txt.sha256"
            async with aiohttp.ClientSession() as session:
                async with session.get(version_url, timeout=30) as version_response:
                    if version_response.status != 200:
                        logger.warning(f"Failed to fetch version: HTTP {version_response.status}")
                        return False
                    remote_version = (await version_response.text()).strip()
                async with session.get(hash_url, timeout=30) as hash_response:
                    if hash_response.status != 200:
                        logger.warning(f"Failed to fetch version hash: HTTP {hash_response.status}")
                        return False
                    self.expected_hash = (await hash_response.text()).strip()
            logger.info(f"Current: {self.current_version}, Remote: {remote_version}")
            return self._compare_versions(self.current_version, remote_version)
        except Exception as e:
            logger.error(f"Error checking remote version: {e}")
            return False

    def _compare_versions(self, current: str, remote: str) -> bool:
        """Compare version strings using packaging.version."""
        try:
            return version.parse(remote) > version.parse(current)
        except version.InvalidVersion:
            logger.error(f"Invalid version format: current={current}, remote={remote}")
            return False

    async def _download_and_apply_update(self) -> bool:
        """Download and apply the update atomically."""
        temp_dir = None
        backup_dir = None
        stage_dir = None
        try:
            # Check write permissions
            if not self._check_write_permissions(Path.cwd()):
                logger.error("No write permission for application directory")
                return False

            # Create temporary directories
            temp_dir = Path(tempfile.mkdtemp(prefix="gmail_printer_update_"))
            stage_dir = Path(tempfile.mkdtemp(prefix="gmail_printer_stage_"))
            backup_dir = Path(tempfile.mkdtemp(prefix="gmail_printer_backup_"))

            # Download update package
            download_url = f"{self.config.UPDATE_REPOSITORY_URL}/archive/{self.config.UPDATE_BRANCH}.zip"
            update_file = temp_dir / "update.zip"
            logger.info(f"Downloading update from {download_url}")
            total_size = 0
            downloaded = 0
            hasher = hashlib.sha256()
            async with aiohttp.ClientSession() as session:
                async with session.get(download_url, timeout=300) as response:
                    if response.status != 200:
                        logger.error(f"Download failed: HTTP {response.status}")
                        return False
                    total_size = int(response.headers.get('content-length', 0))
                    with open(update_file, 'wb') as f:
                        async for chunk in response.content.iter_chunked(8192):
                            f.write(chunk)
                            hasher.update(chunk)
                            downloaded += len(chunk)
                            if total_size:
                                logger.info(f"Download progress: {downloaded/total_size*100:.1f}%")
                    if hasher.hexdigest() != self.expected_hash:
                        logger.error("Update package hash mismatch")
                        return False

            # Extract update
            extract_dir = temp_dir / "extracted"
            with zipfile.ZipFile(update_file, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)
            update_dirs = list(extract_dir.iterdir())
            if not update_dirs:
                logger.error("No content in update package")
                return False
            update_source = update_dirs[0]

            # Check for locked files
            locked_files = []
            for source_file in update_source.rglob('*'):
                if source_file.is_file():
                    relative_path = source_file.relative_to(update_source)
                    target_file = Path.cwd() / relative_path
                    if target_file.exists() and self._is_file_locked(target_file):
                        locked_files.append(str(target_file))
            if locked_files:
                logger.error(f"Cannot update, files locked: {locked_files}")
                # Stage update for next restart
                shutil.copytree(update_source, stage_dir / "staged_update")
                logger.info("Update staged for next restart")
                return True

            # Backup current directory
            current_dir = Path.cwd()
            shutil.copytree(current_dir, backup_dir, ignore=lambda _, names: list(self.PROTECTED_FILES))

            # Stage update
            for source_file in update_source.rglob('*'):
                if source_file.is_file():
                    relative_path = source_file.relative_to(update_source)
                    if relative_path.name in self.PROTECTED_FILES:
                        logger.info(f"Skipping protected file: {relative_path}")
                        continue
                    if any(part.startswith('.') or part == 'logs' for part in relative_path.parts):
                        continue
                    target_file = stage_dir / relative_path
                    target_file.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source_file, target_file)
                    logger.debug(f"Staged: {relative_path}")

            # Apply update atomically
            shutil.move(current_dir, backup_dir / "previous")
            shutil.move(stage_dir, current_dir)
            logger.info(f"Updated {len(list(current_dir.rglob('*')))} files")
            return True

        except Exception as e:
            logger.error(f"Update download/apply failed: {e}")
            # Rollback if backup exists
            if backup_dir and (backup_dir / "previous").exists():
                logger.info("Restoring previous version")
                shutil.rmtree(Path.cwd(), ignore_errors=True)
                shutil.move(backup_dir / "previous", Path.cwd())
            return False
        finally:
            # Cleanup temporary directories
            for dir_path in [temp_dir, backup_dir, stage_dir]:
                if dir_path and dir_path.exists():
                    try:
                        shutil.rmtree(dir_path)
                    except Exception as e:
                        logger.warning(f"Failed to cleanup {dir_path}: {e}")

    def _check_write_permissions(self, path: Path) -> bool:
        """Check if the application directory is writable."""
        try:
            test_file = path / f".test_{time.time()}.tmp"
            test_file.touch()
            test_file.unlink()
            return True
        except PermissionError:
            logger.error(f"No write permission for {path}")
            return False
        except Exception as e:
            logger.error(f"Permission check failed: {e}")
            return False

    def _is_file_locked(self, file_path: Path) -> bool:
        """Check if a file is locked (e.g., in use)."""
        try:
            with open(file_path, 'a'):
                return False
        except PermissionError:
            return True
        except Exception:
            return False

    async def _restart_application(self):
        """Restart the application using a batch script."""
        try:
            executable = sys.executable if hasattr(sys, '_MEIPASS') else sys.argv[0]
            batch_script = Path.cwd() / "restart.bat"
            with open(batch_script, 'w') as f:
                f.write(f"""
                @echo off
                timeout /t 2
                start "" "{executable}" {" ".join(sys.argv[1:])}
                """)
            subprocess.Popen([str(batch_script)], shell=True)
            logger.info("Initiating restart")
            # Signal main loop to exit
            sys.exit(0)
        except Exception as e:
            logger.error(f"Restart failed: {e}")
            return False

    def _cleanup_old_temp_dirs(self):
        """Cleanup old temporary directories."""
        for temp_dir in Path(tempfile.gettempdir()).glob("gmail_printer_*"):
            try:
                shutil.rmtree(temp_dir)
            except Exception as e:
                logger.warning(f"Failed to cleanup {temp_dir}: {e}")
"""
Production-ready Gmail API client with comprehensive error handling.
FIXED: Added network connectivity checks, improved retry logic, and detailed email logging.
"""
import asyncio
import logging
import os
import socket
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from typing import List, Dict, Optional
import time
from utils import ExponentialBackoff, SystemUtils
from exceptions import NetworkError

logger = logging.getLogger(__name__)

class GmailClient:
    """Production Gmail API client with robust error handling."""
    SCOPES = ['https://www.googleapis.com/auth/gmail.modify']
    CREDENTIALS_FILE = 'credentials.json'
    TOKEN_FILE = 'token.json'

    def __init__(self, config):
        self.config = config
        self.service = None
        self.last_auth_time = 0
        if not config.DRY_RUN:
            self._initialize_service()
        else:
            logger.info("DRY-RUN: Skipping Gmail service initialization")

    def _initialize_service(self):
        """Initialize Gmail service with error handling."""
        try:
            if not os.path.exists(self.CREDENTIALS_FILE):
                raise FileNotFoundError(f"Missing {self.CREDENTIALS_FILE}")
            self.service = self._get_gmail_service()
            logger.info("Gmail service initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Gmail service: {e}")
            raise NetworkError(f"Gmail initialization failed: {e}")

    def _get_gmail_service(self):
        """Get authenticated Gmail service."""
        creds = None
        if os.path.exists(self.TOKEN_FILE):
            try:
                creds = Credentials.from_authorized_user_file(self.TOKEN_FILE, self.SCOPES)
            except Exception as e:
                logger.warning(f"Failed to load existing token: {e}")
                self._cleanup_token_file()
        
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                try:
                    creds.refresh(Request())
                    logger.info("Gmail credentials refreshed")
                except Exception as e:
                    logger.warning(f"Failed to refresh credentials: {e}")
                    self._cleanup_token_file()
                    creds = None
            if not creds:
                logger.info("Starting OAuth flow for Gmail authentication")
                flow = InstalledAppFlow.from_client_secrets_file(
                    self.CREDENTIALS_FILE, self.SCOPES
                )
                creds = flow.run_local_server(port=0)
            self._save_credentials(creds)
        
        try:
            service = build('gmail', 'v1', credentials=creds)
            self.last_auth_time = time.time()
            return service
        except Exception as e:
            raise NetworkError(f"Failed to build Gmail service: {e}")

    def _cleanup_token_file(self):
        """Safely remove token file."""
        try:
            if os.path.exists(self.TOKEN_FILE):
                os.remove(self.TOKEN_FILE)
                logger.info("Removed invalid token file")
        except Exception as e:
            logger.warning(f"Failed to remove token file: {e}")

    def _save_credentials(self, creds):
        """Save credentials to token file."""
        try:
            with open(self.TOKEN_FILE, 'w', encoding='utf-8') as f:
                f.write(creds.to_json())
            logger.debug("Credentials saved successfully")
        except Exception as e:
            logger.error(f"Failed to save credentials: {e}")

    async def get_unread_emails(self) -> List[Dict]:
        """Get unread emails with retry logic and network checks."""
        if self.config.DRY_RUN:
            logger.info("DRY-RUN: Simulating unread emails")
            return [
                {'id': 'mock_email_1', 'threadId': 'thread_1'},
                {'id': 'mock_email_2', 'threadId': 'thread_2'}
            ]
        
        backoff = ExponentialBackoff(initial_delay=1, max_delay=60)
        max_attempts = 5
        for attempt in range(max_attempts):
            try:
                socket.create_connection(("8.8.8.8", 53), timeout=5)
                query_parts = ['is:unread', '-in:trash', '-in:spam']
                if self.config.TARGET_SENDER:
                    query_parts.append(f'from:{self.config.TARGET_SENDER}')
                if self.config.TARGET_SUBJECT:
                    query_parts.append(f'subject:"{self.config.TARGET_SUBJECT}"')
                query = ' '.join(query_parts)
                logger.debug(f"Gmail query: {query}")
                request = self.service.users().messages().list(userId='me', q=query, maxResults=50)
                results = await asyncio.to_thread(request.execute)
                messages = results.get('messages', [])
                logger.info(f"Found {len(messages)} unread emails")
                if messages:
                    logger.debug(f"Message IDs: {[msg['id'] for msg in messages]}")
                return messages
            except (HttpError, socket.gaierror, socket.timeout) as e:
                logger.error(f"Unexpected error fetching emails (attempt {attempt + 1}): {e}")
                if attempt == max_attempts - 1:
                    raise NetworkError(f"Failed to fetch emails after {max_attempts} attempts: {e}")
                await asyncio.sleep(backoff.get_next_delay())
            except Exception as e:
                logger.error(f"Unexpected error fetching emails (attempt {attempt + 1}): {e}")
                if attempt == max_attempts - 1:
                    raise NetworkError(f"Failed to fetch emails after {max_attempts} attempts: {e}")
                await asyncio.sleep(backoff.get_next_delay())
        raise NetworkError("Max retry attempts exceeded")

    async def get_email(self, message_id: str) -> Dict:
        """Get email details with error handling."""
        if self.config.DRY_RUN:
            logger.info(f"DRY-RUN: Simulating email fetch for {message_id}")
            return {
                'id': message_id,
                'payload': {
                    'headers': [
                        {'name': 'Subject', 'value': 'Test Email Subject'},
                        {'name': 'From', 'value': 'test@example.com'},
                        {'name': 'Date', 'value': 'Mon, 1 Jan 2024 12:00:00 +0000'}
                    ],
                    'parts': [
                        {
                            'filename': 'test_document.pdf',
                            'body': {'attachmentId': 'mock_attachment_id'},
                            'mimeType': 'application/pdf'
                        }
                    ]
                }
            }
        try:
            request = self.service.users().messages().get(userId='me', id=message_id, format='full')
            email_data = await asyncio.to_thread(request.execute)
            logger.debug(f"Retrieved email {message_id}")
            return email_data
        except HttpError as e:
            if e.resp.status == 404:
                logger.warning(f"Email {message_id} not found (may have been deleted)")
                return {}
            else:
                logger.error(f"Failed to fetch email {message_id}: {e}")
                raise NetworkError(f"Failed to fetch email: {e}")
        except Exception as e:
            logger.error(f"Unexpected error fetching email {message_id}: {e}")
            raise NetworkError(f"Unexpected error: {e}")

    async def trash_email(self, message_id: str):
        """Move email to trash."""
        if self.config.DRY_RUN:
            logger.info(f"DRY-RUN: Would trash email {message_id}")
            return
        try:
            request = self.service.users().messages().trash(userId='me', id=message_id)
            await asyncio.to_thread(request.execute)
            logger.info(f"Moved email {message_id} to trash")
        except HttpError as e:
            if e.resp.status == 404:
                logger.warning(f"Email {message_id} not found (may already be deleted)")
            else:
                logger.error(f"Failed to trash email {message_id}: {e}")
                raise NetworkError(f"Failed to trash email: {e}")
        except Exception as e:
            logger.error(f"Unexpected error trashing email {message_id}: {e}")
            raise NetworkError(f"Unexpected error: {e}")
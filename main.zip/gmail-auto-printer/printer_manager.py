"""
Production-ready printer manager with improved detection and cross-platform support.
Fixed timeout handling and print verification.
FIXED: Multiple copies issue with SumatraPDF
"""
import os
import logging
import asyncio
import subprocess
import platform
import shutil
import time
from pathlib import Path
from typing import Optional, Dict, List
from config import Config
from docx_to_pdf_converter import DocxToPDFConverter
from exceptions import PrinterError
from utils import SystemUtils

logger = logging.getLogger(__name__)

class PrinterManager:
    """Cross-platform printer manager with comprehensive functionality."""
    
    def __init__(self, config: Config):
        """Initialize printer manager with configuration."""
        self.config = config
        self.platform = platform.system()
        self.duplex_supported = False
        self.printer_available = False
        self.docx_converter = None
        
        # Initialize print statistics
        self.print_stats = {
            'total_prints': 0,
            'successful_prints': 0,
            'failed_prints': 0,
            'retry_attempts': 0
        }
        
        # Initialize DocX converter if needed
        try:
            self.docx_converter = DocxToPDFConverter()
            logger.debug("DocX to PDF converter initialized")
        except Exception as e:
            logger.warning(f"Failed to initialize DocX converter: {e}")
            self.docx_converter = None
        
        # Check printer availability and duplex support
        asyncio.create_task(self._initialize_printer_info())

    async def _initialize_printer_info(self):
        """Initialize printer information and capabilities."""
        try:
            self.printer_available = await self._check_printer_availability()
            if self.printer_available:
                self.duplex_supported = await self._check_duplex_support()
                logger.info(f"Printer '{self.config.PRINTER_NAME}' available, duplex: {self.duplex_supported}")
            else:
                logger.warning(f"Printer '{self.config.PRINTER_NAME}' not available")
        except Exception as e:
            logger.error(f"Failed to initialize printer info: {e}")
            self.printer_available = False
            self.duplex_supported = False

    async def _check_printer_availability(self) -> bool:
        """Check if the configured printer is available."""
        try:
            if self.platform == "Windows":
                cmd = ["powershell", "-Command", "Get-Printer | Select-Object Name, PrinterStatus"]
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
                )
                
                stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=10)
                
                if process.returncode == 0:
                    output = stdout.decode('utf-8', errors='ignore')
                    logger.debug(f"PowerShell found {len(output.splitlines())} printers")
                    return self.config.PRINTER_NAME in output
                else:
                    logger.warning(f"Failed to check printer availability: {stderr.decode()}")
                    return False
            else:
                cmd = ["lpstat", "-p"]
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                
                stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=10)
                
                if process.returncode == 0:
                    output = stdout.decode('utf-8', errors='ignore')
                    return self.config.PRINTER_NAME in output
                else:
                    logger.warning(f"Failed to check printer availability: {stderr.decode()}")
                    return False
                
        except Exception as e:
            logger.error(f"Error checking printer availability: {e}")
            return False

    async def _check_duplex_support(self) -> bool:
        """Check if the printer supports duplex printing."""
        try:
            if self.platform == "Windows":
                cmd = [
                    "powershell", "-Command",
                    f"Get-PrinterProperty -PrinterName '{self.config.PRINTER_NAME}' | Where-Object {{$_.PropertyName -eq 'Config:DuplexUnit'}}"
                ]
                
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
                )
                
                stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=10)
                
                if process.returncode == 0:
                    output = stdout.decode('utf-8', errors='ignore')
                    return 'True' in output or 'Installed' in output
                    
            return False  # Default to no duplex support for non-Windows or on error
            
        except Exception as e:
            logger.debug(f"Could not determine duplex support: {e}")
            return False

    async def print_file(self, file_path: Path, copies: int = 1, duplex: bool = False) -> bool:
        """Print a file with the specified options."""
        self.print_stats['total_prints'] += 1
        
        try:
            if not file_path.exists():
                logger.error(f"File not found: {file_path}")
                self.print_stats['failed_prints'] += 1
                return False
            
            if not self.printer_available:
                logger.error(f"Printer '{self.config.PRINTER_NAME}' not available")
                self.print_stats['failed_prints'] += 1
                return False
            
            # Limit copies to reasonable number
            copies = max(1, min(copies, 10))
            
            # Disable duplex if not supported
            if duplex and not self.duplex_supported:
                logger.warning("Duplex requested but not supported, printing single-sided")
                duplex = False
            
            file_ext = file_path.suffix.lower()
            
            # Handle different file types
            if file_ext == '.pdf':
                success = await self._print_pdf_with_sumatra(file_path, copies, duplex)
            elif file_ext in ['.docx', '.doc']:
                success = await self._print_docx(file_path, copies, duplex)
            elif file_ext in ['.txt', '.log']:
                success = await self._print_text_file(file_path, copies, duplex)
            elif file_ext in ['.jpg', '.jpeg', '.png']:
                success = await self._print_image(file_path, copies, duplex)
            else:
                logger.error(f"Unsupported file type: {file_ext}")
                self.print_stats['failed_prints'] += 1
                return False
            
            if success:
                self.print_stats['successful_prints'] += 1
                logger.info(f"Successfully printed: {file_path.name} ({copies} copies, duplex={duplex})")
            else:
                self.print_stats['failed_prints'] += 1
                logger.error(f"Failed to print: {file_path.name}")
            
            return success
            
        except Exception as e:
            logger.error(f"Error printing file {file_path}: {e}")
            self.print_stats['failed_prints'] += 1
            return False

    async def _print_docx(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """Print DOCX file by converting to PDF first."""
        if not self.docx_converter:
            logger.error("DocX converter not available")
            return False
        
        try:
            # Create a temporary PDF path
            pdf_path = file_path.parent / f"{file_path.stem}_temp.pdf"
            
            # Convert to PDF
            success = await self.docx_converter.convert_to_pdf(file_path, pdf_path)
            if not success or not pdf_path.exists():
                logger.error(f"Failed to convert {file_path.name} to PDF")
                return False
            
            # Print the PDF
            print_success = await self._print_pdf_with_sumatra(pdf_path, copies, duplex)
            
            # Clean up temporary PDF
            SystemUtils.cleanup_file(pdf_path)
            
            return print_success
            
        except Exception as e:
            logger.error(f"Error printing DOCX file {file_path}: {e}")
            return False

    async def _print_text_file(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """Print text file using system print command."""
        try:
            if self.platform == "Windows":
                # Use notepad to print text files on Windows
                cmd = ["notepad", "/p", str(file_path)]
            else:
                # Use lp command on Unix-like systems
                cmd = ["lp", "-d", self.config.PRINTER_NAME, "-n", str(copies)]
                if duplex:
                    cmd.extend(["-o", "sides=two-sided-long-edge"])
                cmd.append(str(file_path))
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=getattr(self.config, 'TIMEOUT_LP_PRINT_SECONDS', 30)
            )
            
            return process.returncode == 0
            
        except Exception as e:
            logger.error(f"Error printing text file {file_path}: {e}")
            return False

    async def _print_image(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """Print image file using system default image viewer."""
        try:
            if self.platform == "Windows":
                # Use Windows Photo Viewer or default image viewer
                cmd = ["rundll32.exe", "shimgvw.dll,ImageView_PrintTo", str(file_path), self.config.PRINTER_NAME]
            else:
                # Convert to PDF and print (requires ImageMagick)
                cmd = ["convert", str(file_path), "pdf:-"]
                # This would need additional handling for Unix systems
                return False  # Not implemented for non-Windows yet
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=getattr(self.config, 'TIMEOUT_LP_PRINT_SECONDS', 30)
            )
            
            return process.returncode == 0
            
        except Exception as e:
            logger.error(f"Error printing image file {file_path}: {e}")
            return False

    def _find_sumatra_pdf(self) -> Optional[Path]:
        """Find SumatraPDF executable with enhanced detection."""
        # Check environment variable or config
        if self.config.SUMATRA_PDF_PATH and self.config.SUMATRA_PDF_PATH.exists():
            return self.config.SUMATRA_PDF_PATH
        
        # Check default installation paths
        default_paths = [
            Path(r"C:\Program Files\SumatraPDF\SumatraPDF.exe"),
            Path(r"C:\Program Files (x86)\SumatraPDF\SumatraPDF.exe"),
            Path(os.path.expanduser(r"~\AppData\Local\SumatraPDF\SumatraPDF.exe"))
        ]
        
        for path in default_paths:
            if path.exists():
                return path
        
        # Check system PATH
        sumatra_exe = shutil.which("SumatraPDF")
        if sumatra_exe:
            return Path(sumatra_exe)
        
        logger.warning("SumatraPDF not found in any known location")
        return None

    async def _print_pdf_with_sumatra(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """
        Print PDF using SumatraPDF with FIXED multiple copies handling.
        
        MAJOR FIX: SumatraPDF's -print-settings copies=N parameter doesn't work reliably.
        Instead, we use PowerShell to send the print job with proper copy settings.
        """
        # Find SumatraPDF executable
        sumatra_path = self._find_sumatra_pdf()
        if not sumatra_path:
            logger.error("SumatraPDF not found")
            return False
        
        for attempt in range(1, self.config.MAX_PRINT_RETRIES + 1):
            self.print_stats['retry_attempts'] += 1
            
            try:
                # FIXED APPROACH: Use PowerShell to print with proper copies support
                if self.platform == "Windows":
                    success = await self._print_pdf_with_powershell(file_path, copies, duplex)
                else:
                    # Fallback to original method for non-Windows
                    success = await self._print_pdf_with_sumatra_fallback(file_path, copies, duplex)
                
                if success:
                    return True
                
            except Exception as e:
                logger.warning(f"Print attempt {attempt} error: {e}")
            
            # Wait before retry
            if attempt < self.config.MAX_PRINT_RETRIES:
                logger.debug(f"Waiting {self.config.PRINT_RETRY_DELAY_SECONDS}s before retry...")
                await asyncio.sleep(self.config.PRINT_RETRY_DELAY_SECONDS)
        
        logger.error(f"Failed to print after {self.config.MAX_PRINT_RETRIES} attempts")
        return False

    async def _print_pdf_with_powershell(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """
        Print PDF using PowerShell with proper copy handling.
        This method ensures that the correct number of copies are actually printed.
        """
        try:
            # Escape paths for PowerShell
            file_escaped = str(file_path).replace("'", "''")
            printer_escaped = self.config.PRINTER_NAME.replace("'", "''")
            
            # Build PowerShell script that properly handles copies
            duplex_setting = "1" if duplex and self.duplex_supported else "0"
            
            script = f'''
            try {{
                $ErrorActionPreference = "Stop"
                
                # Create Adobe Reader or SumatraPDF print job with proper settings
                Add-Type -AssemblyName System.Drawing
                Add-Type -AssemblyName System.Windows.Forms
                
                # Use .NET PrintDocument for reliable printing
                $printDoc = New-Object System.Drawing.Printing.PrintDocument
                $printDoc.PrinterSettings.PrinterName = '{printer_escaped}'
                $printDoc.PrinterSettings.Copies = {copies}
                
                if ({duplex_setting} -eq 1) {{
                    $printDoc.PrinterSettings.Duplex = [System.Drawing.Printing.Duplex]::Vertical
                }}
                
                # Use SumatraPDF to render and print
                $process = Start-Process -FilePath '{str(self._find_sumatra_pdf()).replace("'", "''")}' -ArgumentList '-silent', '-print-to', '{printer_escaped}', '-print-settings', 'noscale', '{file_escaped}' -Wait -PassThru -WindowStyle Hidden
                
                if ($process.ExitCode -eq 0) {{
                    # Verify print job was sent correctly by checking if we need additional copies
                    if ({copies} -gt 1) {{
                        # Send additional copies if needed (SumatraPDF sometimes ignores copies parameter)
                        for ($i = 2; $i -le {copies}; $i++) {{
                            Start-Sleep -Milliseconds 500
                            $additionalProcess = Start-Process -FilePath '{str(self._find_sumatra_pdf()).replace("'", "''")}' -ArgumentList '-silent', '-print-to', '{printer_escaped}', '-print-settings', 'noscale', '{file_escaped}' -Wait -PassThru -WindowStyle Hidden
                            if ($additionalProcess.ExitCode -ne 0) {{
                                Write-Error "Additional copy $i failed"
                                exit 1
                            }}
                        }}
                    }}
                    Write-Output "Print successful: {copies} copies sent"
                    exit 0
                }} else {{
                    Write-Error "SumatraPDF failed with exit code $($process.ExitCode)"
                    exit 1
                }}
            }} catch {{
                Write-Error "Print failed: $($_.Exception.Message)"
                exit 1
            }}
            '''

            # Record start time
            start_time = time.time()
            
            # Execute PowerShell script
            process = await asyncio.create_subprocess_exec(
                "powershell", "-ExecutionPolicy", "Bypass", "-Command", script,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=self.config.TIMEOUT_SUMATRA_PRINT_SECONDS * copies  # Scale timeout with copies
                )
                
                elapsed_time = time.time() - start_time
                
                if stdout:
                    logger.debug(f"PowerShell stdout: {stdout.decode().strip()}")
                if stderr:
                    logger.debug(f"PowerShell stderr: {stderr.decode().strip()}")
                
                if process.returncode == 0:
                    logger.info(f"Print successful: {file_path.name} ({copies} copies, took {elapsed_time:.1f}s)")
                    return True
                else:
                    logger.warning(f"PowerShell print failed with return code {process.returncode}")
                    return False
                
            except asyncio.TimeoutError:
                elapsed_time = time.time() - start_time
                logger.warning(f"PowerShell print timed out after {elapsed_time:.1f}s")
                
                # Try to terminate the process
                try:
                    process.terminate()
                    await asyncio.wait_for(process.wait(), timeout=5)
                except:
                    try:
                        process.kill()
                    except:
                        pass
                
                return False
                
        except Exception as e:
            logger.error(f"PowerShell print error: {e}")
            return False

    async def _print_pdf_with_sumatra_fallback(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """
        Fallback method: Print multiple times if copies parameter doesn't work.
        This ensures the correct number of copies by calling SumatraPDF multiple times.
        """
        sumatra_path = self._find_sumatra_pdf()
        if not sumatra_path:
            return False
        
        try:
            # Build base command for single copy
            settings = ["noscale"]
            if duplex and self.duplex_supported:
                settings.append("duplex")
            
            success_count = 0
            
            # Print the requested number of copies by calling SumatraPDF multiple times
            for copy_num in range(1, copies + 1):
                cmd = [
                    str(sumatra_path),
                    "-silent",
                    "-print-to", self.config.PRINTER_NAME,
                    "-print-settings", ",".join(settings),
                    str(file_path)
                ]
                
                logger.debug(f"Print command (copy {copy_num}/{copies}): {' '.join(cmd[:-1])} [file]")
                
                # Record start time
                start_time = time.time()
                
                # Execute print command
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
                )
                
                try:
                    stdout, stderr = await asyncio.wait_for(
                        process.communicate(),
                        timeout=self.config.TIMEOUT_SUMATRA_PRINT_SECONDS
                    )
                    
                    elapsed_time = time.time() - start_time
                    
                    if process.returncode == 0:
                        success_count += 1
                        logger.debug(f"Copy {copy_num} successful (took {elapsed_time:.1f}s)")
                        
                        # Small delay between copies to avoid overwhelming printer
                        if copy_num < copies:
                            await asyncio.sleep(0.5)
                    else:
                        logger.warning(f"Copy {copy_num} failed with return code {process.returncode}")
                        if stderr:
                            logger.debug(f"SumatraPDF stderr: {stderr.decode().strip()}")
                
                except asyncio.TimeoutError:
                    logger.warning(f"Copy {copy_num} timed out")
                    try:
                        process.terminate()
                        await asyncio.wait_for(process.wait(), timeout=5)
                    except:
                        try:
                            process.kill()
                        except:
                            pass
            
            # Consider successful if at least one copy printed
            if success_count > 0:
                if success_count == copies:
                    logger.info(f"All {copies} copies printed successfully")
                else:
                    logger.warning(f"Only {success_count}/{copies} copies printed successfully")
                return True
            else:
                logger.error(f"No copies printed successfully")
                return False
                
        except Exception as e:
            logger.error(f"Fallback print error: {e}")
            return False

    async def _verify_print_job(self, file_name: str) -> bool:
        """Verify that print job was actually sent to printer (Windows only)."""
        try:
            if self.platform != "Windows":
                return True  # Can't verify on non-Windows
            
            # Check print queue
            cmd = [
                "powershell", "-Command",
                f"Get-PrintJob -PrinterName '{self.config.PRINTER_NAME}' | Where-Object {{$_.DocumentName -like '*{file_name}*'}}"
            ]
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=10)
            
            if process.returncode == 0:
                output = stdout.decode('utf-8', errors='ignore')
                # If we find print jobs, that's good
                return len(output.strip()) > 0
            
            # If we can't check, assume success
            return True
            
        except Exception as e:
            logger.debug(f"Could not verify print job: {e}")
            return True  # Assume success if we can't verify

    async def cleanup(self):
        """Cleanup printer manager resources."""
        try:
            if self.docx_converter:
                await self.docx_converter.cleanup()
            logger.debug("Printer manager cleanup completed")
        except Exception as e:
            logger.error(f"Error during printer manager cleanup: {e}")

    def get_stats(self) -> Dict:
        """Get printer statistics."""
        return self.print_stats.copy()
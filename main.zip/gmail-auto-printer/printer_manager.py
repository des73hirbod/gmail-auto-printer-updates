"""
Printer Manager for Gmail Auto Printer.
Handles printing of PDF, DOCX, and image files with enhanced validation and debugging.
FIXED: Added retry logic for printing, verified temporary PDF existence, and delayed cleanup.
"""
import logging
import asyncio
import subprocess
import tempfile
from pathlib import Path
from typing import Optional
import time

# Try to import PyPDF2, with fallback if not available
try:
    import PyPDF2
    PYPDF2_AVAILABLE = True
except ImportError:
    PYPDF2_AVAILABLE = False
    logging.getLogger(__name__).warning("PyPDF2 not installed. PDF validation disabled.")

from utils import SystemUtils

logger = logging.getLogger(__name__)

class PrinterManager:
    """Manages printing operations for PDF, DOCX, and image files."""
    
    def __init__(self, printer_name: str, sumatra_pdf_path: Optional[Path] = None, debug_mode: bool = True):
        self.printer_name = printer_name
        self.sumatra_pdf_path = sumatra_pdf_path
        self.debug_mode = debug_mode
        self.docx_converter = None  # Will be set externally
        self.stats = {'successful_prints': 0, 'validation_failures': 0, 'print_failures': 0}
        
    async def validate_pdf(self, pdf_path: Path) -> dict:
        """Validate that the PDF contains extractable text if PyPDF2 is available."""
        if not PYPDF2_AVAILABLE:
            logger.warning(f"Skipping PDF validation for {pdf_path.name}: PyPDF2 not installed")
            return {'pages': 0, 'text_length': 0}
        
        try:
            with open(pdf_path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                page_count = len(reader.pages)
                text_content = ""
                for page_num, page in enumerate(reader.pages):
                    try:
                        page_text = page.extract_text() or ""
                        text_content += page_text
                    except Exception as e:
                        logger.debug(f"Could not extract text from page {page_num}: {e}")
                
                logger.info(f"PDF validation: {pdf_path.name} has {page_count} pages, "
                           f"text length: {len(text_content)} characters")
                return {'pages': page_count, 'text_length': len(text_content)}
                
        except Exception as e:
            logger.warning(f"PDF validation failed for {pdf_path.name}: {e}")
            self.stats['validation_failures'] += 1
            return {'pages': 0, 'text_length': 0}

    async def _print_pdf_with_adobe_reader(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """IMPROVED: Print PDF using Adobe Reader command line (best compatibility)."""
        try:
            adobe_paths = [
                r"C:\Program Files\Adobe\Acrobat DC\Acrobat\Acrobat.exe",
                r"C:\Program Files (x86)\Adobe\Acrobat Reader DC\Reader\AcroRd32.exe",
                r"C:\Program Files\Adobe\Acrobat Reader DC\Reader\AcroRd32.exe",
            ]
            
            adobe_path = None
            for path in adobe_paths:
                if Path(path).exists():
                    adobe_path = path
                    break
            
            if not adobe_path:
                logger.debug("Adobe Reader not found, trying next method")
                return False
            
            cmd = [
                adobe_path,
                "/t",
                str(file_path),
                self.printer_name
            ]
            
            if copies > 1:
                logger.warning(f"Adobe Reader printing: will print 1 copy, then send {copies-1} more jobs")
            
            start_time = time.time()
            
            for copy_num in range(copies):
                result = await asyncio.to_thread(
                    subprocess.run,
                    cmd,
                    capture_output=True, text=True, timeout=90,
                    creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
                )
                
                if result.returncode != 0:
                    logger.error(f"Adobe Reader print failed on copy {copy_num + 1}: {result.stderr}")
                    return False
                
                if copy_num < copies - 1:
                    await asyncio.sleep(2)
            
            elapsed_time = time.time() - start_time
            logger.info(f"Adobe Reader print successful: {file_path.name} ({copies} copies, took {elapsed_time:.1f}s)")
            return True

        except Exception as e:
            logger.debug(f"Adobe Reader print error for {file_path.name}: {e}")
            return False

    async def _print_pdf_with_sumatra(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """IMPROVED: Print PDF using SumatraPDF with better error handling."""
        if not self.sumatra_pdf_path or not self.sumatra_pdf_path.exists():
            logger.debug("SumatraPDF not available for printing")
            return False

        try:
            cmd = [
                str(self.sumatra_pdf_path),
                "-print-to", self.printer_name,
                "-print-settings", f"{copies}x,simplex,a4",
                "-silent",
                str(file_path)
            ]

            start_time = time.time()
            result = await asyncio.to_thread(
                subprocess.run,
                cmd,
                capture_output=True, text=True, timeout=90,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )

            elapsed_time = time.time() - start_time
            
            if result.returncode == 0:
                logger.info(f"SumatraPDF print successful: {file_path.name} ({copies} copies, took {elapsed_time:.1f}s)")
                return True
            else:
                logger.error(f"SumatraPDF print failed: stdout='{result.stdout}', stderr='{result.stderr}'")
                return False

        except Exception as e:
            logger.error(f"SumatraPDF print error for {file_path.name}: {e}")
            return False

    async def _print_pdf_with_powershell(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """IMPROVED: Enhanced PowerShell printing with better PDF handling."""
        try:
            pdf_escaped = str(file_path).replace("'", "''")
            printer_escaped = self.printer_name.replace("'", "''")
            
            script = f'''
            $ErrorActionPreference = "Stop"
            $printjob = Start-Process -FilePath '{pdf_escaped}' -Verb PrintTo -ArgumentList '"{printer_escaped}"' -WindowStyle Hidden -PassThru
            Start-Sleep -Seconds 2
            
            if ($printjob -and !$printjob.HasExited) {{
                $printjob.Kill()
            }}
            
            $shell = New-Object -ComObject Shell.Application
            $folder = $shell.Namespace((Get-Item '{pdf_escaped}').DirectoryName)
            $file = $folder.ParseName((Get-Item '{pdf_escaped}').Name)
            $file.InvokeVerb("printto", "{printer_escaped}")
            '''
            
            with tempfile.NamedTemporaryFile(mode='w', suffix='.ps1', delete=False) as temp_script:
                temp_script.write(script)
                temp_script_path = temp_script.name

            cmd = [
                "powershell",
                "-ExecutionPolicy", "Bypass",
                "-File", temp_script_path
            ]
            
            start_time = time.time()
            for copy_num in range(copies):
                result = await asyncio.to_thread(
                    subprocess.run,
                    cmd,
                    capture_output=True, text=True, timeout=90,
                    creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
                )
                
                if result.returncode != 0:
                    logger.error(f"PowerShell print failed on copy {copy_num + 1}: {result.stderr}")
                    SystemUtils.cleanup_file(Path(temp_script_path))
                    return False
                
                if copy_num < copies - 1:
                    await asyncio.sleep(2)
            
            SystemUtils.cleanup_file(Path(temp_script_path))
            elapsed_time = time.time() - start_time
            logger.info(f"PowerShell print successful: {file_path.name} ({copies} copies, took {elapsed_time:.1f}s)")
            return True

        except Exception as e:
            logger.error(f"PowerShell print error for {file_path.name}: {e}")
            if 'temp_script_path' in locals():
                SystemUtils.cleanup_file(Path(temp_script_path))
            return False

    async def _print_pdf(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """Try printing PDF with multiple methods."""
        if duplex:
            logger.warning(f"Duplex requested but {self.printer_name} is simplex only, printing single-sided")
            duplex = False

        methods = [
            (self._print_pdf_with_adobe_reader, "Adobe Reader"),
            (self._print_pdf_with_sumatra, "SumatraPDF"),
            (self._print_pdf_with_powershell, "PowerShell")
        ]

        for print_method, method_name in methods:
            logger.debug(f"Trying print method: {method_name}")
            if await print_method(file_path, copies, duplex):
                logger.info(f"✅ Print successful using {method_name}: {file_path.name}")
                self.stats['successful_prints'] += 1
                return True
        
        logger.error(f"All print methods failed for {file_path.name}")
        self.stats['print_failures'] += 1
        return False

    async def _print_docx(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """Print DOCX file by converting to PDF first."""
        if not self.docx_converter:
            logger.error("DOCX converter not initialized")
            return False

        pdf_path = Path(f"{file_path.parent}/{file_path.stem}_temp.pdf")
        try:
            logger.info(f"Converting DOCX to PDF: {file_path.name}")
            
            conversion_success = await self.docx_converter.convert_to_pdf(file_path, pdf_path)
            if not conversion_success or not pdf_path.exists():
                logger.error(f"Failed to convert {file_path.name} to PDF")
                return False

            logger.info(f"Conversion successful, PDF size: {pdf_path.stat().st_size} bytes")
            
            print_success = await self._print_pdf(pdf_path, copies, duplex)
            
            if print_success:
                logger.info(f"Successfully printed: {file_path.name} ({copies} copies, duplex={duplex})")
            else:
                logger.error(f"Failed to print PDF for {file_path.name}")
            
            if not self.debug_mode:
                SystemUtils.cleanup_file(file_path)
                SystemUtils.cleanup_file(pdf_path)
            else:
                logger.debug(f"Debug mode: Retaining files {file_path} and {pdf_path}")
            
            return print_success

        except Exception as e:
            logger.error(f"Failed to print {file_path.name}: {e}")
            if pdf_path.exists() and not self.debug_mode:
                SystemUtils.cleanup_file(pdf_path)
            return False

    async def print_file(self, file_path: Path, copies: int = 1, duplex: bool = False) -> bool:
        """Public method to print a file based on its extension with retry logic."""
        try:
            file_extension = file_path.suffix.lower()
            copies = max(1, min(copies, 20))  # Limit to reasonable range
            logger.info(f"Print request: {file_path.name} ({file_extension}) - {copies} copies, duplex={duplex}")

            max_retries = 3
            retry_delay = 2  # seconds

            if not file_path.exists():
                logger.error(f"File not found for printing: {file_path}")
                return False

            if file_extension in ['.jpg', '.jpeg', '.png']:
                from PIL import Image
                import img2pdf
                pdf_path = file_path.with_suffix('.pdf')
                try:
                    with Image.open(file_path) as img:
                        img = img.convert('RGB')  # Ensure compatibility with PDF
                        with open(pdf_path, 'wb') as f:
                            f.write(img2pdf.convert(file_path))
                    for attempt in range(max_retries):
                        print_success = await self._print_pdf(pdf_path, copies, duplex)
                        if print_success:
                            if not self.debug_mode:
                                SystemUtils.cleanup_file(pdf_path)
                            return True
                        logger.error(f"Image print attempt {attempt + 1}/{max_retries} failed for {file_path.name}")
                        if attempt < max_retries - 1:
                            await asyncio.sleep(retry_delay)
                    if not self.debug_mode:
                        SystemUtils.cleanup_file(pdf_path)
                    return False
                except Exception as e:
                    logger.error(f"Failed to convert and print {file_path.name}: {e}")
                    if pdf_path.exists() and not self.debug_mode:
                        SystemUtils.cleanup_file(pdf_path)
                    return False
            elif file_extension == '.pdf':
                for attempt in range(max_retries):
                    print_success = await self._print_pdf(file_path, copies, duplex)
                    if print_success:
                        return True
                    logger.error(f"PDF print attempt {attempt + 1}/{max_retries} failed for {file_path.name}")
                    if attempt < max_retries - 1:
                        await asyncio.sleep(retry_delay)
                return False
            elif file_extension in ['.docx', '.doc']:
                for attempt in range(max_retries):
                    print_success = await self._print_docx(file_path, copies, duplex)
                    if print_success:
                        return True
                    logger.error(f"DOCX print attempt {attempt + 1}/{max_retries} failed for {file_path.name}")
                    if attempt < max_retries - 1:
                        await asyncio.sleep(retry_delay)
                return False
            else:
                logger.error(f"Unsupported file type: {file_extension}")
                return False

        except Exception as e:
            logger.error(f"Error printing {file_path.name}: {e}")
            self.stats['print_failures'] += 1
            return False

    async def test_printer_connectivity(self) -> bool:
        """Test if the printer is available and responsive."""
        try:
            cmd = [
                "powershell",
                "-Command",
                f"Get-WmiObject -Class Win32_Printer | Where-Object {{ $_.Name -eq '{self.printer_name}' }} | Select-Object Name, PrinterStatus, WorkOffline"
            ]
            result = await asyncio.to_thread(
                subprocess.run,
                cmd,
                capture_output=True, text=True, timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0 and self.printer_name in result.stdout:
                if "WorkOffline" in result.stdout and "True" in result.stdout:
                    logger.warning(f"Printer '{self.printer_name}' is offline")
                    return False
                logger.info(f"Printer '{self.printer_name}' is online and available")
                return True
            else:
                logger.error(f"Printer '{self.printer_name}' not found or not accessible")
                return False

        except Exception as e:
            logger.error(f"Error checking printer connectivity: {e}")
            return False

    async def print_test_page(self) -> bool:
        """Print a test page to verify printer functionality."""
        try:
            test_content = """
%PDF-1.4
1 0 obj
<<
/Type /Catalog
/Pages 2 0 R
>>
endobj

2 0 obj
<<
/Type /Pages
/Kids [3 0 R]
/Count 1
>>
endobj

3 0 obj
<<
/Type /Page
/Parent 2 0 R
/MediaBox [0 0 612 792]
/Contents 4 0 R
/Resources <<
/Font <<
/F1 5 0 R
>>
>>
>>
endobj

4 0 obj
<<
/Length 85
>>
stream
BT
/F1 24 Tf
100 700 Td
(Gmail Auto Printer Test Page) Tj
100 -50 Td
(If you see this, printing works!) Tj
ET
endstream
endobj

5 0 obj
<<
/Type /Font
/Subtype /Type1
/BaseFont /Helvetica
>>
endobj

xref
0 6
0000000000 65535 f 
0000000010 00000 n 
0000000053 00000 n 
0000000100 00000 n 
0000000242 00000 n 
0000000377 00000 n 
trailer
<<
/Size 6
/Root 1 0 R
>>
startxref
444
%%EOF
"""
            
            test_file = Path(tempfile.gettempdir()) / "gmail_auto_printer_test.pdf"
            test_file.write_text(test_content)
            
            logger.info("Printing test page...")
            success = await self._print_pdf(test_file, 1, False)
            
            if test_file.exists():
                test_file.unlink()
            
            if success:
                logger.info("✅ Test page printed successfully")
            else:
                logger.error("❌ Test page printing failed")
            
            return success

        except Exception as e:
            logger.error(f"Error printing test page: {e}")
            return False

    async def initialize(self):
        """Initialize the printer manager and verify printer availability."""
        try:
            logger.info(f"Initializing printer manager for: {self.printer_name}")
            
            if not await self.test_printer_connectivity():
                logger.error(f"Printer '{self.printer_name}' is not available")
                return False
            
            logger.info(f"✅ Printer '{self.printer_name}' initialized successfully")
            return True

        except Exception as e:
            logger.error(f"Error initializing printer manager: {e}")
            return False

    async def cleanup(self):
        """Clean up resources."""
        try:
            if self.docx_converter:
                await self.docx_converter.cleanup()
            logger.debug("Printer manager cleanup completed")
        except Exception as e:
            logger.error(f"Error during printer manager cleanup: {e}")

    def is_printer_capable_of_duplex(self) -> bool:
        """Check if the printer supports duplex printing."""
        try:
            cmd = [
                "powershell",
                "-Command",
                f"Get-WmiObject -Class Win32_Printer | Where-Object {{ $_.Name -eq '{self.printer_name}' }} | Select-Object Duplex"
            ]
            result = subprocess.run(
                cmd,
                capture_output=True, text=True, timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            return "True" in result.stdout
        except Exception as e:
            logger.error(f"Error checking duplex capability: {e}")
            return False
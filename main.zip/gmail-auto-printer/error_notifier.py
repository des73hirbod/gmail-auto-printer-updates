"""
Error notification system with webhook and email fallback.
"""
import asyncio
import logging
import json
import smtplib
import time
import traceback
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional, Dict
import aiohttp
from utils import SystemUtils

logger = logging.getLogger(__name__)

class ErrorNotifier:
    """Handles error notifications via webhook and email."""
    def __init__(self, config):
        self.config = config
        # Validate required config attributes
        required_attrs = ['EMAIL_ADDRESS', 'ERROR_NOTIFICATION_ENABLED']
        for attr in required_attrs:
            if not hasattr(config, attr):
                raise ValueError(f"Missing required config attribute: {attr}")
        self.last_notification_time = {}
        self.notification_cooldown = 1800  # 30 minutes, aligns with throttled alerts
        # Log warning if notifications enabled but no delivery method configured
        if self.config.ERROR_NOTIFICATION_ENABLED and not (getattr(self.config, 'ERROR_WEBHOOK_URL', None) or getattr(self.config, 'ERROR_EMAIL_RECIPIENT', None)):
            logger.warning("Error notifications enabled but no webhook URL or email recipient specified")

    async def send_error_notification(self, title: str, error_message: str, stack_trace: str = "", error_type: str = "general"):
        """Send error notification with throttling and error type."""
        if not self.config.ERROR_NOTIFICATION_ENABLED:
            logger.debug("Error notifications disabled, skipping notification")
            return
        # Throttle notifications
        if self._is_throttled(title):
            logger.debug(f"Notification throttled: {title} ({error_type})")
            return
        notification_data = self._prepare_notification_data(title, error_message, stack_trace, "error", error_type)
        # Try webhook first, then email fallback
        success = await self._send_webhook_notification(notification_data)
        if not success and getattr(self.config, 'ERROR_EMAIL_RECIPIENT', None):
            success = await self._send_email_notification(notification_data)
        if success:
            self._update_throttle_time(title)
            logger.info(f"Error notification sent: {title} ({error_type})")
        else:
            logger.error(f"Failed to send error notification: {title} ({error_type})")

    async def send_notification(self, title: str, message: str, level: str = "info"):
        """Send general notification."""
        if not self.config.ERROR_NOTIFICATION_ENABLED:
            logger.debug("Notifications disabled, skipping notification")
            return
        notification_data = self._prepare_notification_data(title, message, "", level, "general")
        # Try webhook first, then email fallback
        success = await self._send_webhook_notification(notification_data)
        if not success and getattr(self.config, 'ERROR_EMAIL_RECIPIENT', None):
            success = await self._send_email_notification(notification_data)
        if success:
            logger.info(f"Notification sent: {title}")
        else:
            logger.error(f"Failed to send notification: {title}")

    def _prepare_notification_data(self, title: str, message: str, stack_trace: str, level: str, error_type: str) -> Dict:
        """Prepare notification data with error type."""
        return {
            'title': title,
            'message': message,
            'stack_trace': stack_trace,
            'level': level,
            'error_type': error_type,
            'timestamp': time.time(),
            'hostname': self.config.EMAIL_ADDRESS,
            'version': SystemUtils.get_version(),
            'config_summary': {
                'printer': getattr(self.config, 'PRINTER_NAME', 'Not set'),
                'target_sender': getattr(self.config, 'TARGET_SENDER', 'Not set'),
                'dry_run': getattr(self.config, 'DRY_RUN', False)
            }
        }

    async def _send_webhook_notification(self, data: Dict) -> bool:
        """Send notification via webhook."""
        webhook_url = getattr(self.config, 'ERROR_WEBHOOK_URL', None)
        if not webhook_url:
            logger.debug("No webhook URL configured, skipping webhook notification")
            return False
        try:
            # Format for common webhook services (Slack, Discord, etc.)
            webhook_payload = {
                'text': f"🚨 {data['title']} ({data['error_type']})",
                'attachments': [
                    {
                        'color': 'danger' if data['level'] == 'error' else 'good',
                        'fields': [
                            {'title': 'Message', 'value': data['message'], 'short': False},
                            {'title': 'Hostname', 'value': data['hostname'], 'short': True},
                            {'title': 'Version', 'value': data['version'], 'short': True},
                            {'title': 'Printer', 'value': data['config_summary']['printer'], 'short': True},
                            {'title': 'Error Type', 'value': data['error_type'], 'short': True},
                            {'title': 'Time', 'value': time.ctime(data['timestamp']), 'short': True}
                        ]
                    }
                ]
            }
            if data['stack_trace']:
                webhook_payload['attachments'][0]['fields'].append({
                    'title': 'Stack Trace',
                    'value': f"```{data['stack_trace'][:1000]}```",
                    'short': False
                })
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    webhook_url,
                    json=webhook_payload,
                    timeout=30
                ) as response:
                    if response.status == 200:
                        return True
                    else:
                        logger.warning(f"Webhook failed: HTTP {response.status}")
                        return False
        except Exception as e:
            trace = traceback.format_exc()
            logger.error(f"Webhook notification failed: {e}\n{trace}")
            return False

    async def _send_email_notification(self, data: Dict) -> bool:
        """Send notification via email."""
        try:
            # Create email
            msg = MIMEMultipart()
            msg['From'] = self.config.EMAIL_ADDRESS
            msg['To'] = self.config.ERROR_EMAIL_RECIPIENT
            msg['Subject'] = f"Gmail Auto Printer - {data['title']} ({data['error_type']})"
            # Email body using triple-quoted string
            stack_trace_text = f"Stack Trace:\n{data['stack_trace']}" if data['stack_trace'] else ""
            body = f"""Gmail Auto Printer Notification
Title: {data['title']}
Level: {data['level'].upper()}
Error Type: {data['error_type']}
Time: {time.ctime(data['timestamp'])}
Version: {data['version']}
Hostname: {data['hostname']}
Message:
{data['message']}
Configuration:
- Printer: {data['config_summary']['printer']}
- Target Sender: {data['config_summary']['target_sender']}
- Dry Run: {data['config_summary']['dry_run']}
{stack_trace_text}
"""
            msg.attach(MIMEText(body, 'plain'))
            # Send email
            await asyncio.to_thread(self._send_smtp_email, msg)
            return True
        except Exception as e:
            trace = traceback.format_exc()
            logger.error(f"Email notification failed: {e}\n{trace}")
            return False

    def _send_smtp_email(self, msg):
        """Send email via SMTP (sync)."""
        try:
            with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
                server.login(self.config.EMAIL_ADDRESS, self.config.EMAIL_PASSWORD)
                server.send_message(msg)
        except smtplib.SMTPAuthenticationError:
            logger.error("SMTP authentication failed: Invalid email or password")
            raise
        except smtplib.SMTPConnectError:
            logger.error("SMTP connection failed: Unable to connect to Gmail server")
            raise
        except Exception as e:
            logger.error(f"SMTP email failed: {e}")
            raise

    def _is_throttled(self, title: str) -> bool:
        """Check if notification is throttled."""
        last_time = self.last_notification_time.get(title, 0)
        return (time.time() - last_time) < self.notification_cooldown

    def _update_throttle_time(self, title: str):
        """Update last notification time for throttling."""
        self.last_notification_time[title] = time.time()
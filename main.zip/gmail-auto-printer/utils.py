"""
Utility functions for the Gmail Auto Printer system.
"""
import json
import logging
import re
import os
import asyncio
import subprocess
from pathlib import Path
from typing import Set, Optional, List
import email.header
import time
logger = logging.getLogger(__name__)
class SystemUtils:
    """System utility functions."""
    @staticmethod
    def get_version() -> str:
        """Get application version."""
        try:
            version_file = Path('version.txt')
            if version_file.exists():
                return version_file.read_text().strip()
            return "1.0.0"
        except Exception:
            return "1.0.0"
    @staticmethod
    def sanitize_filename(filename: str) -> str:
        """Sanitize filename for safe file system operations."""
        if not filename:
            return "unnamed_file"
        # Remove or replace dangerous characters
        filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
        filename = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', filename)
        # Remove leading/trailing dots and spaces
        filename = filename.strip('. ')
        # Ensure not empty
        if not filename:
            filename = "unnamed_file"
        # Limit length
        if len(filename) > 200:
            name, ext = os.path.splitext(filename)
            filename = name[:200-len(ext)] + ext
        return filename
    @staticmethod
    def sanitize_log_input(text: str) -> str:
        """Sanitize text for safe logging."""
        if not isinstance(text, str):
            text = str(text)
        # Remove control characters except newlines and tabs
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', '', text)
        # Limit length for logs
        if len(text) > 500:
            text = text[:497] + "..."
        return text
    @staticmethod
    def get_file_extension(filename: str) -> str:
        """Get file extension safely."""
        if not filename:
            return ""
        return Path(filename).suffix.lower().lstrip('.')
    @staticmethod
    def decode_email_header(header: str) -> str:
        """Decode email header with proper encoding handling."""
        try:
            decoded_parts = email.header.decode_header(header)
            decoded_string = ""
            for part, encoding in decoded_parts:
                if isinstance(part, bytes):
                    if encoding:
                        decoded_string += part.decode(encoding)
                    else:
                        decoded_string += part.decode('utf-8', errors='replace')
                else:
                    decoded_string += part
            return decoded_string
        except Exception as e:
            logger.warning(f"Failed to decode email header: {e}")
            return header
    @staticmethod
    def load_processed_ids(file_path: Path) -> Set[str]:
        """Load processed email IDs from file."""
        try:
            if file_path.exists():
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        return set(data)
                    elif isinstance(data, dict) and 'processed_ids' in data:
                        return set(data['processed_ids'])
            return set()
        except Exception as e:
            logger.warning(f"Failed to load processed IDs: {e}")
            return set()
    @staticmethod
    def save_processed_id(file_path: Path, message_id: str):
        """Save processed email ID to file."""
        try:
            processed_ids = SystemUtils.load_processed_ids(file_path)
            processed_ids.add(message_id)
            # Keep only last 1000 IDs to prevent file growth
            if len(processed_ids) > 1000:
                processed_ids = set(list(processed_ids)[-1000:])
            data = {
                'processed_ids': list(processed_ids),
                'last_updated': time.time()
            }
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save processed ID {message_id}: {e}")
    @staticmethod
    def cleanup_file(file_path: Path):
        """Safely cleanup a file."""
        try:
            if file_path.exists():
                file_path.unlink()
                logger.debug(f"Cleaned up file: {file_path}")
        except Exception as e:
            logger.warning(f"Failed to cleanup file {file_path}: {e}")
    @staticmethod
    def cleanup_temp_files(temp_dir: Path):
        """Cleanup temporary files older than 1 hour."""
        try:
            if not temp_dir.exists():
                return
            current_time = time.time()
            for file_path in temp_dir.glob('*'):
                try:
                    if file_path.is_file():
                        file_age = current_time - file_path.stat().st_mtime
                        if file_age > 3600:  # 1 hour
                            file_path.unlink()
                            logger.debug(f"Cleaned up old temp file: {file_path}")
                except Exception as e:
                    logger.warning(f"Failed to cleanup temp file {file_path}: {e}")
        except Exception as e:
            logger.warning(f"Failed to cleanup temp directory {temp_dir}: {e}")
class ExponentialBackoff:
    """Exponential backoff utility for retries."""
    def __init__(self, initial_delay: float = 1.0, max_delay: float = 60.0, backoff_factor: float = 2.0):
        self.initial_delay = initial_delay
        self.max_delay = max_delay
        self.backoff_factor = backoff_factor
        self.current_delay = initial_delay
        self.attempt_count = 0
    def get_next_delay(self) -> float:
        """Get next delay value and increment attempt count."""
        delay = min(self.current_delay, self.max_delay)
        self.current_delay *= self.backoff_factor
        self.attempt_count += 1
        return delay
    def reset(self):
        """Reset backoff to initial state."""
        self.current_delay = self.initial_delay
        self.attempt_count = 0

"""
Comprehensive environment checker for production readiness with better printer detection.
"""
import asyncio
import logging
import os
import platform
import subprocess
import sys
import shutil
import socket
from pathlib import Path
from typing import Dict, List, Tuple

logger = logging.getLogger(__name__)

class EnvironmentChecker:
    """Comprehensive environment checker for production deployment."""
    
    def __init__(self, config):
        self.config = config
        self.check_results = {}

    async def check_all(self) -> bool:
        """Run all environment checks."""
        checks = [
            ("Python Version", self._check_python_version),
            ("Required Directories", self._check_directories),
            ("Gmail Credentials", self._check_gmail_credentials),
            ("Printer Availability", self._check_printer),
            ("SumatraPDF", self._check_sumatra_pdf),
            ("Microsoft Word", self._check_microsoft_word),
            ("Malware Scanner", self._check_malware_scanner),
            ("Disk Space", self._check_disk_space),
            ("Network Connectivity", self._check_network),
            ("File Permissions", self._check_file_permissions)
        ]
        
        all_passed = True
        logger.info("=" * 50)
        logger.info("🔍 Environment Check Starting")
        logger.info("=" * 50)
        
        for check_name, check_func in checks:
            try:
                passed, details = await check_func()
                self.check_results[check_name] = {"passed": passed, "details": details}
                
                status = "✅ PASS" if passed else "❌ FAIL"
                logger.info(f"{status} - {check_name}: {details}")
                
                if not passed:
                    all_passed = False
                    
            except Exception as e:
                self.check_results[check_name] = {"passed": False, "details": f"Check failed: {e}"}
                logger.error(f"❌ ERROR - {check_name}: {e}")
                all_passed = False

        logger.info("=" * 50)
        result_text = "PASSED" if all_passed else "FAILED"
        logger.info(f"🔍 Environment Check Complete - {result_text}")
        logger.info("=" * 50)
        
        # If printer check failed, provide helpful suggestions
        if not self.check_results.get("Printer Availability", {}).get("passed", True):
            self._print_printer_suggestions()
        
        return all_passed

    async def _check_python_version(self) -> Tuple[bool, str]:
        """Check Python version compatibility."""
        version = sys.version_info
        
        if version < (3, 8):
            return False, f"Python {version.major}.{version.minor} too old (need 3.8+)"
        
        if version >= (3, 13):
            return True, f"Python {version.major}.{version.minor} (comtypes compatibility warning)"
        
        return True, f"Python {version.major}.{version.minor} (compatible)"

    async def _check_directories(self) -> Tuple[bool, str]:
        """Check required directories exist and are writable."""
        try:
            directories = [
                self.config.DOWNLOAD_DIR,
                self.config.MALWARE_SCAN_TEMP_DIR,
                Path('logs')
            ]
            
            for directory in directories:
                directory.mkdir(parents=True, exist_ok=True)
                
                # Test write permission
                test_file = directory / 'test_write.tmp'
                test_file.write_text('test')
                test_file.unlink()
            
            return True, f"All directories accessible ({len(directories)} checked)"
            
        except Exception as e:
            return False, f"Directory setup failed: {e}"

    async def _check_gmail_credentials(self) -> Tuple[bool, str]:
        """Check Gmail credentials and API setup."""
        try:
            # Check credentials file
            if not Path('credentials.json').exists():
                return False, "credentials.json not found"
            
            # Validate email format
            email = self.config.EMAIL_ADDRESS
            if '@' not in email or len(email.split('@')) != 2:
                return False, "Invalid email address format"
            
            # Check app password length (should be 16 chars for Gmail)
            password = self.config.EMAIL_PASSWORD
            if len(password.replace(' ', '')) < 10:
                return False, "App password too short (use Gmail app password)"
            
            return True, f"Credentials configured for {email}"
            
        except Exception as e:
            return False, f"Credential check failed: {e}"

    async def _check_printer(self) -> Tuple[bool, str]:
        """Check printer availability with improved detection."""
        if self.config.DRY_RUN:
            return True, "Skipped (dry-run mode)"
        
        try:
            # Get all available printers using multiple methods
            available_printers = await self._get_all_printers()
            
            if not available_printers:
                return False, "No printers found on system"
            
            # Check if target printer exists (case-insensitive)
            target_printer_lower = self.config.PRINTER_NAME.lower()
            matching_printer = None
            
            for printer in available_printers:
                if printer.lower() == target_printer_lower:
                    matching_printer = printer
                    break
            
            if matching_printer:
                # Check printer status
                status = await self._get_printer_status(matching_printer)
                duplex_info = await self._check_printer_duplex(matching_printer)
                
                return True, f"'{matching_printer}' found - Status: {status}{duplex_info}"
            else:
                # Store available printers for suggestions
                self._available_printers = available_printers
                return False, f"Printer '{self.config.PRINTER_NAME}' not found. Found {len(available_printers)} other printers."
                
        except Exception as e:
            return False, f"Printer check failed: {e}"

    async def _get_all_printers(self) -> List[str]:
        """Get all available printers using multiple detection methods."""
        printers = []
        
        # Method 1: PowerShell Get-Printer (preferred)
        try:
            cmd = [
                "powershell", "-Command",
                "Get-Printer | Select-Object -ExpandProperty Name"
            ]
            
            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=15,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0 and result.stdout.strip():
                printers = [p.strip() for p in result.stdout.strip().split('\n') if p.strip()]
                logger.debug(f"PowerShell found {len(printers)} printers")
                if printers:
                    return printers
                    
        except Exception as e:
            logger.debug(f"PowerShell printer detection failed: {e}")
        
        # Method 2: WMI command line
        try:
            cmd = ["wmic", "printer", "get", "name", "/format:value"]
            
            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=15,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if line.startswith('Name=') and '=' in line:
                        printer_name = line.split('=', 1)[1].strip()
                        if printer_name:
                            printers.append(printer_name)
                
                logger.debug(f"WMI found {len(printers)} printers")
                if printers:
                    return printers
                    
        except Exception as e:
            logger.debug(f"WMI printer detection failed: {e}")
        
        # Method 3: PowerShell WMI
        try:
            cmd = [
                "powershell", "-Command",
                "Get-WmiObject -Class Win32_Printer | Select-Object -ExpandProperty Name"
            ]
            
            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=15,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0 and result.stdout.strip():
                printers = [p.strip() for p in result.stdout.strip().split('\n') if p.strip()]
                logger.debug(f"WMI PowerShell found {len(printers)} printers")
                if printers:
                    return printers
                    
        except Exception as e:
            logger.debug(f"WMI PowerShell detection failed: {e}")
        
        return printers

    async def _get_printer_status(self, printer_name: str) -> str:
        """Get printer status."""
        try:
            cmd = [
                "powershell", "-Command",
                f"Get-Printer -Name '{printer_name}' | Select-Object -ExpandProperty PrinterStatus"
            ]
            
            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0 and result.stdout.strip():
                status = result.stdout.strip()
                return "Normal" if status == "0" else status
            else:
                return "Unknown"
                
        except Exception:
            return "Unknown"

    async def _check_printer_duplex(self, printer_name: str) -> str:
        """Check if printer supports duplex."""
        try:
            cmd = [
                "powershell", "-Command",
                f"Get-PrinterProperty -PrinterName '{printer_name}' | Where-Object {{$_.PropertyName -like '*duplex*'}}"
            ]
            
            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0 and result.stdout.strip() and "true" in result.stdout.lower():
                return " (duplex supported)"
            else:
                return " (simplex only)"
                
        except Exception:
            return ""

    async def _check_sumatra_pdf(self) -> Tuple[bool, str]:
        """Check SumatraPDF availability."""
        try:
            # Check configured path first
            if self.config.SUMATRA_PDF_PATH and self.config.SUMATRA_PDF_PATH.exists():
                return True, f"Found at {self.config.SUMATRA_PDF_PATH}"
            
            # Check common locations
            common_paths = [
                Path("SumatraPDF.exe"),
                Path(r"C:\Program Files\SumatraPDF\SumatraPDF.exe"),
                Path(r"C:\Program Files (x86)\SumatraPDF\SumatraPDF.exe"),
            ]
            
            for path in common_paths:
                if path.exists():
                    return True, f"Found at {path}"
            
            # Check if in PATH
            if shutil.which("SumatraPDF"):
                return True, "Found in PATH"
            
            return False, "SumatraPDF not found (PDF printing may fail)"
            
        except Exception as e:
            return False, f"SumatraPDF check failed: {e}"

    async def _check_microsoft_word(self) -> Tuple[bool, str]:
        """Check Microsoft Word availability for DOCX conversion."""
        try:
            # Try to detect Word via COM
            cmd = [
                "powershell", "-Command",
                "try { $word = New-Object -ComObject Word.Application; $word.Quit(); 'Available' } catch { 'Not Available' }"
            ]
            
            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if "Available" in result.stdout:
                return True, "Microsoft Word available for DOCX conversion"
            else:
                return False, "Microsoft Word not available (DOCX conversion limited)"
                
        except Exception as e:
            return False, f"Word check failed: {e}"

    async def _check_malware_scanner(self) -> Tuple[bool, str]:
        """Check malware scanner availability."""
        if self.config.DISABLE_MALWARE_SCAN or not self.config.ENABLE_MALWARE_SCAN:
            return True, "Malware scanning disabled"
        
        try:
            # Check Windows Defender
            cmd = [
                "powershell", "-Command",
                "Get-MpPreference -ErrorAction SilentlyContinue | Select-Object -Property DisableRealtimeMonitoring"
            ]
            
            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0:
                if "False" in result.stdout:
                    return True, "Windows Defender active"
                else:
                    return False, "Windows Defender disabled"
            else:
                return False, "Windows Defender not accessible"
                
        except Exception as e:
            return False, f"Malware scanner check failed: {e}"

    async def _check_disk_space(self) -> Tuple[bool, str]:
        """Check available disk space."""
        try:
            # Check space in current directory
            statvfs = os.statvfs('.') if hasattr(os, 'statvfs') else None
            if statvfs:
                free_bytes = statvfs.f_frsize * statvfs.f_bavail
                free_mb = free_bytes / (1024 * 1024)
            else:
                # Windows alternative
                import shutil
                total, used, free = shutil.disk_usage('.')
                free_mb = free / (1024 * 1024)
            
            if free_mb < 100:  # Less than 100MB
                return False, f"Low disk space: {free_mb:.1f}MB available"
            elif free_mb < 500:  # Less than 500MB
                return True, f"Disk space OK: {free_mb:.1f}MB available (warning)"
            else:
                return True, f"Disk space OK: {free_mb:.1f}MB available"
                
        except Exception as e:
            return False, f"Disk space check failed: {e}"

    async def _check_network(self) -> Tuple[bool, str]:
        """Check network connectivity."""
        try:
            # Test DNS resolution
            socket.setdefaulttimeout(5)
            socket.gethostbyname('gmail.com')
            
            # Test HTTPS connectivity to Gmail
            import ssl
            context = ssl.create_default_context()
            with socket.create_connection(('gmail.com', 443), timeout=5) as sock:
                with context.wrap_socket(sock, server_hostname='gmail.com') as ssock:
                    pass
            
            return True, "Network connectivity OK"
            
        except socket.gaierror:
            return False, "DNS resolution failed"
        except socket.timeout:
            return False, "Network connection timed out"
        except Exception as e:
            return False, f"Network check failed: {e}"
        finally:
            socket.setdefaulttimeout(None)

    async def _check_file_permissions(self) -> Tuple[bool, str]:
        """Check file permissions for critical files."""
        try:
            critical_files = [
                self.config.PROCESSED_IDS_FILE,
                Path('.env'),
                Path('logs')
            ]
            
            issues = []
            for file_path in critical_files:
                if file_path.exists():
                    # Test read access
                    if file_path.is_file():
                        try:
                            file_path.read_text()
                        except PermissionError:
                            issues.append(f"Cannot read {file_path}")
                    
                    # Test write access
                    try:
                        if file_path.is_file():
                            # Test by opening in append mode
                            with open(file_path, 'a') as f:
                                pass
                        else:
                            # Directory - test by creating temp file
                            test_file = file_path / 'test_permissions.tmp'
                            test_file.touch()
                            test_file.unlink()
                    except PermissionError:
                        issues.append(f"Cannot write to {file_path}")
            
            if issues:
                return False, f"Permission issues: {', '.join(issues)}"
            else:
                return True, f"File permissions OK ({len(critical_files)} files checked)"
                
        except Exception as e:
            return False, f"Permission check failed: {e}"

    def _print_printer_suggestions(self):
        """Print helpful printer setup suggestions."""
        if hasattr(self, '_available_printers') and self._available_printers:
            logger.info("")
            logger.info("🖨️  PRINTER SETUP SUGGESTIONS:")
            logger.info("=" * 50)
            logger.info(f"Current setting: PRINTER_NAME={self.config.PRINTER_NAME}")
            logger.info("")
            logger.info("Available printers on your system:")
            
            for i, printer in enumerate(self._available_printers, 1):
                logger.info(f"  {i}. {printer}")
            
            logger.info("")
            logger.info("To fix this issue:")
            logger.info("1. Update your .env file with one of the exact printer names above")
            logger.info("2. Use the exact name including spaces and capitalization")
            logger.info("3. Example: PRINTER_NAME=Microsoft Print to PDF")
            logger.info("")
            logger.info("If 'Microsoft Print to PDF' is not listed, you can add it:")
            logger.info("1. Open Windows Settings > Printers & scanners")
            logger.info("2. Click 'Add printer or scanner'")
            logger.info("3. Click 'The printer that I want isn't listed'")
            logger.info("4. Select 'Add a local printer...'")
            logger.info("5. Choose 'Microsoft Print to PDF' from the list")
            logger.info("=" * 50)
        else:
            logger.info("")
            logger.info("🖨️  NO PRINTERS FOUND:")
            logger.info("=" * 50)
            logger.info("No printers were detected on your system.")
            logger.info("")
            logger.info("To add the Microsoft Print to PDF printer:")
            logger.info("1. Open Windows Settings > Printers & scanners")
            logger.info("2. Click 'Add printer or scanner'")
            logger.info("3. Click 'The printer that I want isn't listed'")
            logger.info("4. Select 'Add a local printer...'")
            logger.info("5. Create a new port > Local Port")
            logger.info("6. Enter any name (e.g., 'FILE:')")
            logger.info("7. Choose 'Microsoft' > 'Microsoft Print To PDF'")
            logger.info("8. Set as default if desired")
            logger.info("=" * 50)

    def get_check_results(self) -> Dict:
        """Get detailed check results."""
        return self.check_results.copy()

    def print_detailed_report(self):
        """Print detailed environment report."""
        logger.info("\n" + "=" * 60)
        logger.info("📋 DETAILED ENVIRONMENT REPORT")
        logger.info("=" * 60)
        
        for check_name, result in self.check_results.items():
            status = "✅ PASS" if result["passed"] else "❌ FAIL"
            logger.info(f"{status} {check_name}")
            logger.info(f"    {result['details']}")
            logger.info("")
        
        # System information
        logger.info("💻 SYSTEM INFORMATION")
        logger.info(f"    OS: {platform.system()} {platform.release()}")
        logger.info(f"    Python: {sys.version}")
        logger.info(f"    Architecture: {platform.architecture()[0]}")
        logger.info("=" * 60)
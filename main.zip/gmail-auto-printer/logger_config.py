"""
Logging configuration for production use.
"""
import logging
import logging.handlers
import sys
from pathlib import Path
def setup_logging(log_level: str = 'INFO') -> None:
    """
    Setup production-ready logging with file rotation.
    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
    """
    log_level = log_level.upper()
    numeric_level = getattr(logging, log_level, logging.INFO)
    # Create logs directory
    logs_dir = Path('logs')
    logs_dir.mkdir(exist_ok=True)
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    # Root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(numeric_level)
    # Clear existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(numeric_level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    # File handler with rotation
    file_handler = logging.handlers.RotatingFileHandler(
        logs_dir / 'gmail_printer.log',
        maxBytes=10*1024*1024,  # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    file_handler.setLevel(numeric_level)
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)
    # Error file handler
    error_handler = logging.handlers.RotatingFileHandler(
        logs_dir / 'gmail_printer_errors.log',
        maxBytes=5*1024*1024,  # 5MB
        backupCount=3,
        encoding='utf-8'
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(formatter)
    root_logger.addHandler(error_handler)
    # Reduce noise from third-party libraries
    logging.getLogger('googleapiclient.discovery_cache').setLevel(logging.WARNING)
    logging.getLogger('google.auth.transport.requests').setLevel(logging.WARNING)
    logging.getLogger('urllib3.connectionpool').setLevel(logging.WARNING)

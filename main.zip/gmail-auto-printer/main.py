#!/usr/bin/env python3
"""
Gmail Auto Printer - Production Ready
Main application entry point with complete error handling and production features.
FIXED: Prevent immediate shutdown on network errors, added DocxConverter initialization.
FIXED: Updated AttachmentHandler initialization to include error_notifier and security_validator.
FIXED: Updated SecurityValidator initialization to include error_notifier.
FIXED: Added EventLog source registration to prevent PowerShell errors.
"""
import asyncio
import argparse
import logging
import sys
import os
import signal
import traceback
import time
import subprocess
from pathlib import Path

from config import Config, ConfigValidationError
from gmail_client import GmailClient
from attachment_handler import AttachmentHandler
from printer_manager import PrinterManager
from docx_converter import DocxConverter
from auto_updater import AutoUpdater
from error_notifier import ErrorNotifier
from environment_checker import EnvironmentChecker
from security_validator import SecurityValidator
from logger_config import setup_logging
from utils import SystemUtils
from constants import APP_VERSION, APP_NAME

logger = logging.getLogger(__name__)

def register_event_source():
    """Register EventLog source if it doesn't exist to prevent PowerShell errors."""
    try:
        # Check if we're on Windows
        if not sys.platform.startswith('win'):
            return
            
        # Check if source exists
        check_cmd = [
            "powershell", "-Command",
            "[System.Diagnostics.EventLog]::SourceExists('GmailAutoPrinter')"
        ]
        result = subprocess.run(check_cmd, capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0 and "False" in result.stdout:
            # Create the source
            create_cmd = [
                "powershell", "-Command",
                "New-EventLog -LogName Application -Source GmailAutoPrinter"
            ]
            create_result = subprocess.run(create_cmd, capture_output=True, text=True, timeout=10)
            
            if create_result.returncode == 0:
                logger.info("✅ EventLog source 'GmailAutoPrinter' created successfully")
            else:
                logger.debug(f"EventLog source creation failed (non-critical): {create_result.stderr}")
        elif result.returncode == 0 and "True" in result.stdout:
            logger.debug("EventLog source 'GmailAutoPrinter' already exists")
        else:
            logger.debug(f"Could not check EventLog source (non-critical): {result.stderr}")
            
    except subprocess.TimeoutExpired:
        logger.debug("EventLog source check timed out (non-critical)")
    except FileNotFoundError:
        logger.debug("PowerShell not found - EventLog source registration skipped")
    except Exception as e:
        logger.debug(f"EventLog source registration skipped (non-critical): {e}")

class GmailAutoPrinter:
    """Main application class for Gmail Auto Printer."""
    
    def __init__(self, config: Config, args):
        self.config = config
        self.args = args
        self.running = True
        self.error_notifier = None
        self.auto_updater = None
        self.gmail_client = None
        self.attachment_handler = None
        self.printer_manager = None
        self.docx_converter = None
        self.security_validator = None

    async def initialize(self):
        """Initialize all components."""
        try:
            logger.info("Initializing Gmail Auto Printer components...")
            
            # Register EventLog source early to prevent errors
            register_event_source()
            
            self.error_notifier = ErrorNotifier(self.config)
            logger.debug("Error notifier initialized")
            
            if self.config.ENABLE_AUTO_UPDATE and not self.args.no_updates:
                self.auto_updater = AutoUpdater(self.config, self.error_notifier)
                logger.debug("Auto updater initialized")
                try:
                    await asyncio.wait_for(self.auto_updater.check_for_updates(), timeout=30)
                except asyncio.TimeoutError:
                    logger.warning("Update check timed out, continuing with startup")
                    await self.error_notifier.send_error_notification(
                        "Auto Update Timeout",
                        "Update check timed out after 30 seconds",
                        traceback.format_exc(),
                        error_type="auto_update"
                    )
                except Exception as e:
                    logger.warning(f"Update check failed: {e}")
                    await self.error_notifier.send_error_notification(
                        "Auto Update Failure",
                        f"Failed to check for updates: {str(e)}",
                        traceback.format_exc(),
                        error_type="auto_update"
                    )
            
            self.gmail_client = GmailClient(self.config)
            logger.debug("Gmail client initialized")
            
            self.docx_converter = DocxConverter()
            try:
                await self.docx_converter.initialize()
                logger.debug("DocxConverter initialized")
            except Exception as e:
                logger.error(f"Failed to initialize DocxConverter: {e}")
                raise
            
            self.printer_manager = PrinterManager(
                printer_name=self.config.PRINTER_NAME,
                sumatra_pdf_path=Path(self.config.SUMATRA_PDF_PATH),
                debug_mode=self.args.debug
            )
            self.printer_manager.docx_converter = self.docx_converter
            logger.debug("Printer manager initialized")
            
            self.security_validator = SecurityValidator(self.config, self.error_notifier)
            logger.debug("Security validator initialized")
            
            self.attachment_handler = AttachmentHandler(
                self.config,
                self.args,
                self.docx_converter,
                self.printer_manager,
                self.error_notifier,
                self.security_validator
            )
            logger.debug("Attachment handler initialized")
            
            logger.info("✅ All components initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize components: {e}")
            if self.error_notifier:
                await self.error_notifier.send_error_notification(
                    "System Initialization Failed",
                    str(e),
                    traceback.format_exc(),
                    error_type="initialization"
                )
            raise

    async def process_emails(self):
        """Main email processing loop with timeout protection."""
        processed_count = 0
        error_count = 0
        last_error_notification = 0
        ERROR_NOTIFICATION_COOLDOWN = 1800
        OPERATION_TIMEOUT = 300

        logger.info("🚀 Starting email processing loop...")

        while self.running:
            try:
                messages = await asyncio.wait_for(
                    self.gmail_client.get_unread_emails(),
                    timeout=OPERATION_TIMEOUT
                )
                if not messages:
                    logger.debug("No unread emails found")
                    if self.args.once:
                        logger.info("Run-once mode: No emails to process, exiting")
                        break
                    await asyncio.sleep(self.config.POLL_INTERVAL_SECONDS)
                    continue

                logger.info(f"📧 Found {len(messages)} unread emails to process")
                processed_ids = SystemUtils.load_processed_ids(self.config.PROCESSED_IDS_FILE)

                for i, message in enumerate(messages, 1):
                    if not self.running:
                        break
                    message_id = message['id']
                    logger.info(f"Processing email {i}/{len(messages)}: {message_id}")
                    if message_id in processed_ids:
                        logger.debug(f"⏭️  Skipping already processed email: {message_id}")
                        continue
                    try:
                        email_data = await asyncio.wait_for(
                            self.gmail_client.get_email(message_id),
                            timeout=60
                        )
                        if not email_data:
                            logger.warning(f"No email data received for {message_id}")
                            error_count += 1
                            continue
                        attachment_count, total_copies = await asyncio.wait_for(
                            self.attachment_handler.process_email(email_data, self.gmail_client.service),
                            timeout=180
                        )
                        if attachment_count > 0:
                            logger.info(f"✅ Successfully processed {attachment_count} attachments from email {message_id}")
                            processed_count += attachment_count
                        else:
                            logger.info(f"📎 No valid attachments found in email {message_id}")
                        if not self.args.dry_run:
                            await asyncio.wait_for(
                                self.gmail_client.trash_email(message_id),
                                timeout=30
                            )
                            SystemUtils.save_processed_id(self.config.PROCESSED_IDS_FILE, message_id)
                            logger.debug(f"Email {message_id} moved to trash and marked as processed")
                        else:
                            logger.info(f"DRY-RUN: Would trash email {message_id}")
                    except asyncio.TimeoutError:
                        logger.error(f"⏰ Operation timeout for email {message_id}")
                        error_count += 1
                        continue
                    except Exception as e:
                        error_count += 1
                        logger.error(f"❌ Failed to process email {message_id}: {e}")
                        current_time = time.time()
                        if current_time - last_error_notification > ERROR_NOTIFICATION_COOLDOWN:
                            if self.error_notifier:
                                await self.error_notifier.send_error_notification(
                                    f"Email Processing Error (ID: {message_id})",
                                    str(e),
                                    traceback.format_exc(),
                                    error_type="email_processing"
                                )
                            last_error_notification = current_time

                stats = self.attachment_handler.get_stats()
                error_count += stats.get('validation_failures', 0)
                if self.args.once:
                    logger.info("Run-once mode: Processing complete, exiting")
                    break
                await asyncio.sleep(self.config.POLL_INTERVAL_SECONDS)

            except (asyncio.TimeoutError, Exception) as e:
                error_count += 1
                logger.error(f"❌ Error in main processing loop: {e}")
                logger.error(traceback.format_exc())
                if self.error_notifier:
                    await self.error_notifier.send_error_notification(
                        "Critical Processing Loop Error",
                        str(e),
                        traceback.format_exc(),
                        error_type="processing_loop"
                    )
                if self.args.once:
                    logger.info("Run-once mode: Error occurred, exiting")
                    break
                logger.info("Waiting 300 seconds before retry...")
                await asyncio.sleep(300)

        logger.info(f"📊 Processing complete. Processed: {processed_count}, Errors: {error_count}")

    async def cleanup(self):
        """Cleanup resources."""
        try:
            logger.info("🧹 Cleaning up resources...")
            if self.printer_manager:
                await self.printer_manager.cleanup()
            if self.attachment_handler:
                await self.attachment_handler.cleanup()
            if self.docx_converter:
                await self.docx_converter.cleanup()
            if self.security_validator:
                await self.security_validator.cleanup()
            logger.info("✅ Cleanup completed successfully")
        except Exception as e:
            logger.error(f"❌ Error during cleanup: {e}")
            if self.error_notifier:
                await self.error_notifier.send_error_notification(
                    "Cleanup Error",
                    str(e),
                    traceback.format_exc(),
                    error_type="cleanup"
                )

    def setup_signal_handlers(self):
        """Setup signal handlers for graceful shutdown."""
        def signal_handler(signum, frame):
            logger.info(f"Received signal {signum}, initiating shutdown...")
            self.running = False
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)


async def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description=f"{APP_NAME} - Production Ready")
    parser.add_argument("--dry-run", action="store_true", help="Simulate actions without making changes")
    parser.add_argument("--once", action="store_true", help="Run once and exit")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    parser.add_argument("--skip-env-check", action="store_true", help="Skip environment validation")
    parser.add_argument("--no-updates", action="store_true", help="Disable auto-updates")
    parser.add_argument("--version", action="version", version=f"{APP_NAME} v{APP_VERSION}")
    
    args = parser.parse_args()
    app = None

    try:
        log_level = 'DEBUG' if args.debug else 'INFO'
        setup_logging(log_level=log_level)
        
        logger.info("=" * 60)
        logger.info(f"🚀 {APP_NAME} v{APP_VERSION} Starting")
        logger.info("=" * 60)
        logger.info(f"Python version: {sys.version}")
        logger.info(f"Arguments: {vars(args)}")

        try:
            config = Config(
                dry_run=args.dry_run,
                run_once=args.once
            )
            logger.info("✅ Configuration loaded successfully")
            
            config_summary = config.get_summary()
            logger.info("📋 Configuration Summary:")
            for key, value in config_summary.items():
                logger.info(f"   {key}: {value}")
            
        except ConfigValidationError as e:
            logger.error(f"❌ Configuration validation failed:")
            for line in str(e).split('\n'):
                if line.strip():
                    logger.error(f"   {line}")
            sys.exit(1)

        error_notifier = ErrorNotifier(config)
        if not args.skip_env_check:
            logger.info("🔍 Running environment checks...")
            env_checker = EnvironmentChecker(config)
            if not await env_checker.check_all():
                logger.error("❌ Environment check failed. Use --skip-env-check to bypass.")
                await error_notifier.send_error_notification(
                    "Environment Check Failure",
                    "Environment check failed. Check logs for details.",
                    traceback.format_exc(),
                    error_type="environment_check"
                )
                sys.exit(1)
            logger.info("✅ Environment checks passed")

        app = GmailAutoPrinter(config, args)
        app.setup_signal_handlers()
        
        try:
            await asyncio.wait_for(app.initialize(), timeout=120)
        except asyncio.TimeoutError:
            logger.error("⏰ Application initialization timed out")
            sys.exit(1)
        
        if args.once:
            try:
                await asyncio.wait_for(app.process_emails(), timeout=600)
            except asyncio.TimeoutError:
                logger.error("⏰ Email processing timed out in run-once mode")
                sys.exit(1)
        else:
            await app.process_emails()
        
        logger.info("=" * 60)
        logger.info(f"✅ {APP_NAME} Shutdown Complete")
        logger.info("=" * 60)

    except KeyboardInterrupt:
        logger.info("⏹️  Application interrupted by user")
        sys.exit(0)

    except Exception as e:
        logger.error(f"💥 Fatal application error: {e}")
        logger.error(traceback.format_exc())
        
        try:
            if app and app.error_notifier:
                await app.error_notifier.send_error_notification(
                    "Fatal Application Error",
                    str(e),
                    traceback.format_exc(),
                    error_type="fatal"
                )
            elif 'error_notifier' in locals():
                await error_notifier.send_error_notification(
                    "Fatal Application Error",
                    str(e),
                    traceback.format_exc(),
                    error_type="fatal"
                )
        except:
            pass
        
        sys.exit(1)

    finally:
        if app:
            await app.cleanup()


if __name__ == '__main__':
    if hasattr(sys, '_MEIPASS'):
        os.chdir(sys._MEIPASS)
    else:
        os.chdir(Path(__file__).parent)
    
    if sys.platform.startswith('win'):
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    
    asyncio.run(main())
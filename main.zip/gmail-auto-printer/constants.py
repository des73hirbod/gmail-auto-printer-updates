"""
Constants used throughout the application.
"""

# Timeouts (seconds)
TIMEOUT_SUMATRA_PRINT_SECONDS = 60
TIMEOUT_LP_PRINT_SECONDS = 30
TIMEOUT_WORD_CONVERSION_SECONDS = 60

# File validation
FILE_HEADERS = {
    'pdf': [
        b'%PDF-',
    ],
    'docx': [
        b'PK\x03\x04',  # ZIP file signature (DOCX is ZIP-based)
    ],
    'doc': [
        b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1',  # OLE file signature
    ],
    'jpg': [
        b'\xff\xd8\xff',
    ],
    'jpeg': [
        b'\xff\xd8\xff',
    ],
    'png': [
        b'\x89PNG\r\n\x1a\n',
    ],
    'txt': [
        # Text files can start with anything, so no specific header check
    ],
    'FILE_HEADER_READ_BYTES': 512
}

# Application constants
APP_VERSION = "2.0.0"
APP_NAME = "Gmail Auto Printer"

# Error notification cooldowns (seconds)
ERROR_NOTIFICATION_COOLDOWN = 1800  # 30 minutes
CRITICAL_ERROR_COOLDOWN = 900       # 15 minutes

# File size limits (MB)
DEFAULT_MAX_ATTACHMENT_SIZE = 50
DEFAULT_MAX_SCAN_SIZE = 100

# Retry settings
DEFAULT_MAX_RETRIES = 3
DEFAULT_RETRY_DELAY = 5

# Polling settings
DEFAULT_POLL_INTERVAL = 30
MIN_POLL_INTERVAL = 10
MAX_POLL_INTERVAL = 3600
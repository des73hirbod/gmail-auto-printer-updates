# --- START OF attachment_handler.py ---
"""
Production-ready attachment handler with comprehensive validation and processing.
UPDATED: Better logging for copy tracking and improved error handling.
"""
import os
import base64
import logging
import asyncio
import traceback
import re
from pathlib import Path
from typing import Dict, Optional, List, Tuple
from googleapiclient.errors import HttpError

from config import Config
from utils import SystemUtils
from printer_manager import PrinterManager
from security_validator import SecurityValidator
from malware_scanner import MalwareScanner
from exceptions import AttachmentValidationError
from error_notifier import ErrorNotifier

logger = logging.getLogger(__name__)

class AttachmentHandler:
    """Handles email attachment processing with comprehensive validation."""
    
    def __init__(self, config: Config, gmail_client, printer_manager: PrinterManager, error_notifier: ErrorNotifier):
        """Initialize attachment handler with dependencies."""
        self.config = config
        self.gmail_client = gmail_client
        self.printer_manager = printer_manager
        self.error_notifier = error_notifier
        
        # Initialize security validator
        self.security_validator = SecurityValidator(config, error_notifier)
        
        # Initialize statistics
        self.stats = {
            'total_processed': 0,
            'successful_prints': 0,
            'validation_failures': 0,
            'print_failures': 0,
            'malware_detections': 0
        }
        
        logger.debug("AttachmentHandler initialized")

    def parse_subject_for_print_settings(self, subject: str, default_copies: int = 1, default_duplex: bool = False) -> Tuple[bool, int, bool]:
        """
        Parse email subject for print instructions.
        Returns (should_print, copies, duplex).
        
        Enhanced parsing to handle various formats:
        - "print 2 copies duplex"
        - "Print 14 copies duplex" 
        - "print two copies"
        - "Print duplex"
        - etc.
        """
        if not subject:
            return False, default_copies, default_duplex
        
        subject_lower = subject.lower()
        
        # Check if "print" is in subject (case-insensitive)
        should_print = "print" in subject_lower
        
        # If TARGET_SUBJECT is set, must match exactly (case-insensitive)
        if hasattr(self.config, 'TARGET_SUBJECT') and self.config.TARGET_SUBJECT:
            should_print = self.config.TARGET_SUBJECT.lower() in subject_lower
        
        if not should_print:
            return False, default_copies, default_duplex
        
        # Enhanced copy count parsing
        copies = default_copies
        
        # Look for patterns like "2 copies", "two copies", "print 2", "14 copies", etc.
        copy_patterns = [
            r"(\d+)\s*cop(?:y|ies)",           # "2 copies", "14 copies", "1 copy"
            r"print\s+(\d+)(?:\s+cop(?:y|ies))?",  # "print 2" or "print 2 copies"
            r"(\bone\b|\btwo\b|\bthree\b|\bfour\b|\bfive\b|\bsix\b|\bseven\b|\beight\b|\bnine\b|\bten\b)\s*cop(?:y|ies)"  # "two copies"
        ]
        
        for pattern in copy_patterns:
            match = re.search(pattern, subject_lower)
            if match:
                captured = match.group(1)
                if captured.isdigit():
                    copies = int(captured)
                    logger.debug(f"Found numeric copies: {copies}")
                    break
                else:
                    # Handle text numbers
                    number_map = {
                        "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
                        "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10
                    }
                    copies = number_map.get(captured, default_copies)
                    logger.debug(f"Found text copies: {captured} -> {copies}")
                    break
        
        # Check for duplex
        duplex = default_duplex
        if "duplex" in subject_lower or "double" in subject_lower or "both sides" in subject_lower:
            duplex = True
        
        # Ensure reasonable limits
        copies = max(1, min(copies, 20))  # Cap at 20 copies for safety
        
        logger.info(f"📋 Parsed subject '{subject}': print={should_print}, copies={copies}, duplex={duplex}")
        
        return should_print, copies, duplex

    async def download_attachments(self, message_id: str, msg: Dict, sender_email: str = None) -> int:
        """Download and process all valid attachments from an email."""
        attachment_count = 0
        payload = msg.get('payload', {})
        
        if not sender_email:
            headers = payload.get('headers', [])
            sender_email = self._extract_sender_email(headers)
        
        subject = self._extract_subject(payload.get('headers', []))
        logger.info(f"📧 Processing email from {sender_email}")
        logger.info(f"   Subject: {subject}")
        
        # Enhanced sender validation
        if not self._validate_sender(sender_email):
            logger.info(f"⏭️ Skipping email {message_id}: sender {sender_email} not allowed")
            return 0
        
        # Parse subject for print settings
        should_print, copies, duplex = self.parse_subject_for_print_settings(
            subject,
            default_copies=self.config.COPIES,
            default_duplex=self.config.ENABLE_DUPLEX
        )
        if not should_print:
            logger.info(f"⏭️ Skipping email {message_id}: 'print' not in subject or doesn't match TARGET_SUBJECT")
            return 0
        
        parts = self._get_email_parts(payload)
        if not parts:
            logger.info(f"📎 No attachments found in email {message_id}")
            return 0
        
        logger.info(f"📎 Found {len(parts)} potential attachments")
        
        for i, part in enumerate(parts, 1):
            filename = part.get('filename', '').strip()
            attachment_id = part.get('body', {}).get('attachmentId')
            mime_type = part.get('mimeType', '')
            
            if not filename or not attachment_id:
                logger.debug(f"Skipping part {i}: no filename or attachment ID")
                continue
            
            logger.info(f"🔄 Processing attachment {i}/{len(parts)}: {filename}")
            logger.info(f"   Will print {copies} copies, duplex={duplex}")
            
            try:
                self.stats['total_processed'] += 1
                
                success = await self._process_single_attachment(
                    message_id, attachment_id, filename, mime_type, sender_email,
                    copies=copies, duplex=duplex  # Pass parsed settings
                )
                
                if success:
                    attachment_count += 1
                    self.stats['successful_prints'] += 1
                    logger.info(f"✅ Successfully processed: {filename} ({copies} copies printed)")
                else:
                    logger.warning(f"❌ Failed to process: {filename}")
                    
            except Exception as e:
                logger.error(f"💥 Error processing attachment {filename}: {e}")
                await self.error_notifier.send_error_notification(
                    title="Attachment Processing Error",
                    error_message=f"Failed to process {filename}: {str(e)}",
                    stack_trace=traceback.format_exc(),
                    error_type="attachment_processing"
                )
                self.stats['validation_failures'] += 1
                continue
        
        if attachment_count > 0:
            total_copies = attachment_count * copies
            logger.info(f"🎉 Successfully processed {attachment_count} attachments from email {message_id}")
            logger.info(f"📄 Total physical copies printed: {total_copies} ({attachment_count} attachments × {copies} copies each)")
        else:
            logger.info(f"⚠️  No attachments could be processed from email {message_id}")
        
        return attachment_count

    def _validate_sender(self, sender_email: str) -> bool:
        """Validate sender email against configured restrictions."""
        if not sender_email or sender_email == 'unknown@unknown.com':
            logger.debug(f"Invalid sender email: {sender_email}")
            return False
        
        # If TARGET_SENDER is set, only allow that sender
        if hasattr(self.config, 'TARGET_SENDER') and self.config.TARGET_SENDER:
            if sender_email.lower() != self.config.TARGET_SENDER.lower():
                logger.debug(f"Sender {sender_email} doesn't match TARGET_SENDER {self.config.TARGET_SENDER}")
                return False
            else:
                logger.debug(f"✅ Sender {sender_email} matches TARGET_SENDER")
                return True
        
        # If ALLOWED_SENDER_DOMAINS is set, validate domain
        if hasattr(self.config, 'ALLOWED_SENDER_DOMAINS') and self.config.ALLOWED_SENDER_DOMAINS:
            sender_domain = sender_email.split('@')[1].lower() if '@' in sender_email else ''
            allowed_domains = [d.lower() for d in self.config.ALLOWED_SENDER_DOMAINS]
            if sender_domain not in allowed_domains:
                logger.debug(f"Sender domain {sender_domain} not in allowed domains: {allowed_domains}")
                return False
            else:
                logger.debug(f"✅ Sender domain {sender_domain} is allowed")
                return True
        
        # If no restrictions are set, allow all senders
        logger.debug(f"✅ No sender restrictions, allowing {sender_email}")
        return True

    async def _process_single_attachment(self, message_id: str, attachment_id: str, 
                                       filename: str, mime_type: str, sender_email: str,
                                       copies: int = 1, duplex: bool = False) -> bool:
        """Process a single attachment through the complete pipeline."""
        file_path = None
        
        try:
            logger.debug(f"Step 1: Validating filename and type for {filename}")
            if not self._validate_filename_and_type(filename, mime_type):
                self.stats['validation_failures'] += 1
                await self.error_notifier.send_error_notification(
                    title="Filename/Type Validation Failure",
                    error_message=f"Invalid filename or type: {filename}",
                    stack_trace="",
                    error_type="validation_failure"
                )
                return False
            
            logger.debug(f"✅ Filename and type validation passed: {filename}")
            
            logger.debug(f"Step 2: Downloading attachment {filename}")
            attachment_data = await self._fetch_attachment_data(message_id, attachment_id, filename)
            if not attachment_data:
                self.stats['validation_failures'] += 1
                return False
            
            size_mb = len(attachment_data) / (1024 * 1024)
            logger.debug(f"Step 3: Size check - {size_mb:.2f}MB")
            if size_mb > self.config.MAX_ATTACHMENT_SIZE_MB:
                logger.warning(f"❌ File too large: {filename} ({size_mb:.2f}MB > {self.config.MAX_ATTACHMENT_SIZE_MB}MB)")
                self.stats['validation_failures'] += 1
                await self.error_notifier.send_error_notification(
                    title="File Size Validation Failure",
                    error_message=f"File too large: {filename} ({size_mb:.2f}MB > {self.config.MAX_ATTACHMENT_SIZE_MB}MB)",
                    stack_trace="",
                    error_type="validation_failure"
                )
                return False
            
            logger.debug(f"Step 4: Saving to disk: {filename}")
            file_path = await self._save_attachment(filename, attachment_data)
            if not file_path:
                self.stats['validation_failures'] += 1
                return False
            
            logger.debug(f"✅ Saved attachment: {file_path}")
            
            logger.debug(f"Step 5: Security validation for {filename}")
            validation_result = await self.security_validator.validate_attachment(
                sender_email, filename, file_path
            )
            
            if not validation_result['is_valid']:
                logger.error(f"🛡️ Security validation failed for {filename}: {validation_result['details']}")
                self.stats['validation_failures'] += 1
                if 'malware' in validation_result['details'].lower():
                    self.stats['malware_detections'] += 1
                return False
            
            logger.debug(f"Step 6: Printing {filename} ({copies} copies, duplex={duplex})")
            print_success = await self._print_attachment(file_path, filename, copies, duplex)
            if not print_success:
                self.stats['print_failures'] += 1
                return False
            
            logger.info(f"✅ Complete pipeline success: {filename} - {copies} copies printed")
            return True
            
        except Exception as e:
            logger.error(f"💥 Error in attachment processing pipeline for {filename}: {e}")
            await self.error_notifier.send_error_notification(
                title="Attachment Processing Pipeline Error",
                error_message=f"Pipeline error for {filename}: {str(e)}",
                stack_trace=traceback.format_exc(),
                error_type="attachment_pipeline"
            )
            self.stats['validation_failures'] += 1
            return False
        finally:
            if file_path and file_path.exists():
                SystemUtils.cleanup_file(file_path)
                logger.debug(f"🧹 Cleaned up temporary file: {file_path}")

    async def _print_attachment(self, file_path: Path, filename: str, copies: int = 1, duplex: bool = False) -> bool:
        """Print the attachment using the printer manager."""
        try:
            if self.config.DRY_RUN:
                logger.info(f"DRY-RUN: Would print {filename} ({copies} copies, duplex={duplex})")
                return True
            
            logger.info(f"🖨️ Printing: {filename} ({copies} copies, duplex={duplex})")
            
            success = await self.printer_manager.print_file(
                file_path,
                copies=copies,
                duplex=duplex
            )
            
            if success:
                logger.info(f"✅ Print successful: {filename} - {copies} copies sent to printer")
            else:
                logger.error(f"❌ Print failed: {filename}")
                await self.error_notifier.send_error_notification(
                    title="Print Failure",
                    error_message=f"Failed to print {filename} ({copies} copies requested)",
                    stack_trace=traceback.format_exc(),
                    error_type="print_failure"
                )
                
            return success
            
        except Exception as e:
            logger.error(f"Error printing {filename}: {e}")
            await self.error_notifier.send_error_notification(
                title="Print Error",
                error_message=f"Error printing {filename}: {str(e)}",
                stack_trace=traceback.format_exc(),
                error_type="print_error"
            )
            return False

    def _extract_sender_email(self, headers: List[Dict]) -> str:
        """Extract sender email from headers."""
        for header in headers:
            if header.get('name', '').lower() == 'from':
                value = header.get('value', '')
                # Extract email from "Name <email@domain.com>" format
                if '<' in value and '>' in value:
                    start = value.find('<') + 1
                    end = value.find('>')
                    return value[start:end]
                return value
        return 'unknown@unknown.com'

    def _extract_subject(self, headers: List[Dict]) -> str:
        """Extract subject from headers."""
        for header in headers:
            if header.get('name', '').lower() == 'subject':
                return header.get('value', '')
        return ''

    def _get_email_parts(self, payload: Dict) -> List[Dict]:
        """Extract email parts that might contain attachments."""
        parts = []
        
        def extract_parts(part):
            if 'parts' in part:
                for subpart in part['parts']:
                    extract_parts(subpart)
            else:
                filename = part.get('filename', '')
                attachment_id = part.get('body', {}).get('attachmentId')
                if filename and attachment_id:
                    parts.append(part)
        
        extract_parts(payload)
        return parts

    def _validate_filename_and_type(self, filename: str, mime_type: str) -> bool:
        """Basic filename and MIME type validation."""
        if not filename or not filename.strip():
            return False
        
        # Check for dangerous characters
        dangerous_chars = ['<', '>', ':', '"', '|', '?', '*', '\0']
        for char in dangerous_chars:
            if char in filename:
                logger.warning(f"Dangerous character '{char}' in filename: {filename}")
                return False
        
        # Check file extension
        if not self.config.ALLOW_ALL_FILE_TYPES:
            file_ext = SystemUtils.get_file_extension(filename)
            if not file_ext or file_ext.lower() not in [ext.lower() for ext in self.config.ALLOWED_FILE_TYPES]:
                logger.warning(f"File type not allowed: {file_ext}")
                return False
        
        return True

    async def _fetch_attachment_data(self, message_id: str, attachment_id: str, filename: str) -> Optional[bytes]:
        """Fetch attachment data from Gmail."""
        try:
            if self.config.DRY_RUN:
                logger.debug(f"DRY-RUN: Would download attachment {filename}")
                return b"dummy_data_for_dry_run"
            
            attachment = await asyncio.to_thread(
                self.gmail_client.service.users().messages().attachments().get,
                userId='me',
                messageId=message_id,
                id=attachment_id
            )
            
            result = await asyncio.to_thread(attachment.execute)
            data = base64.urlsafe_b64decode(result['data'])
            logger.debug(f"Downloaded {len(data)} bytes for {filename}")
            return data
            
        except Exception as e:
            logger.error(f"Failed to download attachment {filename}: {e}")
            return None

    async def _save_attachment(self, filename: str, data: bytes) -> Optional[Path]:
        """Save attachment data to disk."""
        try:
            # Sanitize filename
            safe_filename = SystemUtils.sanitize_filename(filename)
            file_path = self.config.DOWNLOAD_DIR / safe_filename
            
            # Ensure unique filename
            counter = 1
            original_path = file_path
            while file_path.exists():
                stem = original_path.stem
                suffix = original_path.suffix
                file_path = original_path.parent / f"{stem}_{counter}{suffix}"
                counter += 1
            
            # Write file
            await asyncio.to_thread(file_path.write_bytes, data)
            logger.debug(f"Saved attachment to {file_path}")
            return file_path
            
        except Exception as e:
            logger.error(f"Failed to save attachment {filename}: {e}")
            return None

    async def cleanup(self):
        """Cleanup attachment handler resources."""
        try:
            # Cleanup any temporary files
            if hasattr(self.config, 'DOWNLOAD_DIR') and self.config.DOWNLOAD_DIR.exists():
                temp_files = list(self.config.DOWNLOAD_DIR.glob('*'))
                for temp_file in temp_files:
                    try:
                        if temp_file.is_file():
                            temp_file.unlink()
                    except Exception as e:
                        logger.debug(f"Could not cleanup {temp_file}: {e}")
            
            logger.debug("AttachmentHandler cleanup completed")
        except Exception as e:
            logger.error(f"Error during attachment handler cleanup: {e}")

    def get_stats(self) -> Dict:
        """Get attachment processing statistics."""
        return self.stats.copy()
# --- END OF attachment_handler.py ---

# --- START OF auto_updater.py ---
import asyncio
import logging
import json
import tempfile
import zipfile
import shutil
from pathlib import Path
from typing import Optional, Dict
import aiohttp
import time
import hashlib
import subprocess
from packaging import version
from tenacity import retry, stop_after_attempt, wait_exponential
from utils import SystemUtils

logger = logging.getLogger(__name__)

class AutoUpdater:
    """Handles automatic updates for the application."""
    PROTECTED_FILES = {
        '.env', 'credentials.json', 'token.json', 
        'processed_ids.json', 'update_check.json'
    }

    def __init__(self, config, error_notifier):
        self.config = config
        self.error_notifier = error_notifier
        self.last_check_file = Path('update_check.json')
        self.current_version = SystemUtils.get_version()
        self.expected_hash = None
        self.last_check_time = None

    async def check_for_updates(self) -> bool:
        """Check for updates if enough time has passed."""
        if not self.config.ENABLE_AUTO_UPDATE:
            logger.debug("Auto-updates disabled")
            return False
        if not self.config.UPDATE_REPOSITORY_URL:
            logger.debug("No update repository URL configured")
            return False
        if not self.config.UPDATE_REPOSITORY_URL.startswith("https://"):
            logger.error("Update repository URL must use HTTPS")
            return False
        if not self._should_check_for_updates():
            logger.debug("Too soon for update check")
            return False
        try:
            logger.info("Checking for updates...")
            if not await self._check_remote_version():
                logger.info("No updates available")
                return False
            logger.info("Update available, starting download...")
            if not await self._download_and_apply_update():
                logger.error("Update failed")
                return False
            logger.info("Update applied successfully")
            if self.error_notifier:
                await self.error_notifier.send_notification(
                    "Update Applied Successfully",
                    f"Gmail Auto Printer updated to latest version",
                    "info"
                )
            await self._restart_application()
            return True
        except Exception as e:
            logger.error(f"Update check failed: {e}")
            if self.error_notifier:
                await self.error_notifier.send_error_notification(
                    "Update Check Failed",
                    str(e),
                    "",
                    error_type="auto_update"
                )
            return False
        finally:
            self._save_last_check_time()

    def _should_check_for_updates(self) -> bool:
        """Check if enough time has passed since last update check."""
        try:
            if not self.last_check_file.exists():
                return True
            with open(self.last_check_file, 'r') as f:
                data = json.load(f)
            last_check = data.get('last_check', 0)
            check_interval = self.config.UPDATE_CHECK_INTERVAL_HOURS * 3600
            return (time.time() - last_check) > check_interval
        except Exception:
            logger.warning("Failed to read update_check.json, allowing update check")
            return True

    def _save_last_check_time(self):
        """Save the last update check time atomically."""
        try:
            temp_file = self.last_check_file.with_suffix('.tmp')
            with open(temp_file, 'w') as f:
                json.dump({'last_check': time.time(), 'version': self.current_version}, f)
            shutil.move(temp_file, self.last_check_file)
            self.last_check_time = time.time()
        except PermissionError:
            logger.warning("No write permission for update_check.json, using in-memory tracking")
            self.last_check_time = time.time()
        except Exception as e:
            logger.warning(f"Failed to save last check time: {e}")

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
    async def _check_remote_version(self) -> bool:
        """Check if a newer version is available."""
        try:
            version_url = f"{self.config.UPDATE_REPOSITORY_URL}/raw/{self.config.UPDATE_BRANCH}/version.txt"
            hash_url = f"{self.config.UPDATE_REPOSITORY_URL}/raw/{self.config.UPDATE_BRANCH}/version.txt.sha256"
            async with aiohttp.ClientSession() as session:
                async with session.get(version_url, timeout=30) as version_response:
                    if version_response.status != 200:
                        logger.warning(f"Failed to fetch version: HTTP {version_response.status}")
                        return False
                    remote_version = (await version_response.text()).strip()
                async with session.get(hash_url, timeout=30) as hash_response:
                    if hash_response.status != 200:
                        logger.warning(f"Failed to fetch version hash: HTTP {hash_response.status}")
                        return False
                    self.expected_hash = (await hash_response.text()).strip()
            logger.info(f"Current: {self.current_version}, Remote: {remote_version}")
            return self._compare_versions(self.current_version, remote_version)
        except Exception as e:
            logger.error(f"Error checking remote version: {e}")
            return False

    def _compare_versions(self, current: str, remote: str) -> bool:
        """Compare version strings using packaging.version."""
        try:
            return version.parse(remote) > version.parse(current)
        except version.InvalidVersion:
            logger.error(f"Invalid version format: current={current}, remote={remote}")
            return False

    async def _download_and_apply_update(self) -> bool:
        """Download and apply the update atomically."""
        temp_dir = None
        backup_dir = None
        stage_dir = None
        try:
            # Check write permissions
            if not self._check_write_permissions(Path.cwd()):
                logger.error("No write permission for application directory")
                return False

            # Create temporary directories
            temp_dir = Path(tempfile.mkdtemp(prefix="gmail_printer_update_"))
            stage_dir = Path(tempfile.mkdtemp(prefix="gmail_printer_stage_"))
            backup_dir = Path(tempfile.mkdtemp(prefix="gmail_printer_backup_"))

            # Download update package
            download_url = f"{self.config.UPDATE_REPOSITORY_URL}/archive/{self.config.UPDATE_BRANCH}.zip"
            update_file = temp_dir / "update.zip"
            logger.info(f"Downloading update from {download_url}")
            total_size = 0
            downloaded = 0
            hasher = hashlib.sha256()
            async with aiohttp.ClientSession() as session:
                async with session.get(download_url, timeout=300) as response:
                    if response.status != 200:
                        logger.error(f"Download failed: HTTP {response.status}")
                        return False
                    total_size = int(response.headers.get('content-length', 0))
                    with open(update_file, 'wb') as f:
                        async for chunk in response.content.iter_chunked(8192):
                            f.write(chunk)
                            hasher.update(chunk)
                            downloaded += len(chunk)
                            if total_size:
                                logger.info(f"Download progress: {downloaded/total_size*100:.1f}%")
                    if hasher.hexdigest() != self.expected_hash:
                        logger.error("Update package hash mismatch")
                        return False

            # Extract update
            extract_dir = temp_dir / "extracted"
            with zipfile.ZipFile(update_file, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)
            update_dirs = list(extract_dir.iterdir())
            if not update_dirs:
                logger.error("No content in update package")
                return False
            update_source = update_dirs[0]

            # Check for locked files
            locked_files = []
            for source_file in update_source.rglob('*'):
                if source_file.is_file():
                    relative_path = source_file.relative_to(update_source)
                    target_file = Path.cwd() / relative_path
                    if target_file.exists() and self._is_file_locked(target_file):
                        locked_files.append(str(target_file))
            if locked_files:
                logger.error(f"Cannot update, files locked: {locked_files}")
                # Stage update for next restart
                shutil.copytree(update_source, stage_dir / "staged_update")
                logger.info("Update staged for next restart")
                return True

            # Backup current directory
            current_dir = Path.cwd()
            shutil.copytree(current_dir, backup_dir, ignore=lambda _, names: list(self.PROTECTED_FILES))

            # Stage update
            for source_file in update_source.rglob('*'):
                if source_file.is_file():
                    relative_path = source_file.relative_to(update_source)
                    if relative_path.name in self.PROTECTED_FILES:
                        logger.info(f"Skipping protected file: {relative_path}")
                        continue
                    if any(part.startswith('.') or part == 'logs' for part in relative_path.parts):
                        continue
                    target_file = stage_dir / relative_path
                    target_file.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source_file, target_file)
                    logger.debug(f"Staged: {relative_path}")

            # Apply update atomically
            shutil.move(current_dir, backup_dir / "previous")
            shutil.move(stage_dir, current_dir)
            logger.info(f"Updated {len(list(current_dir.rglob('*')))} files")
            return True

        except Exception as e:
            logger.error(f"Update download/apply failed: {e}")
            # Rollback if backup exists
            if backup_dir and (backup_dir / "previous").exists():
                logger.info("Restoring previous version")
                shutil.rmtree(Path.cwd(), ignore_errors=True)
                shutil.move(backup_dir / "previous", Path.cwd())
            return False
        finally:
            # Cleanup temporary directories
            for dir_path in [temp_dir, backup_dir, stage_dir]:
                if dir_path and dir_path.exists():
                    try:
                        shutil.rmtree(dir_path)
                    except Exception as e:
                        logger.warning(f"Failed to cleanup {dir_path}: {e}")

    def _check_write_permissions(self, path: Path) -> bool:
        """Check if the application directory is writable."""
        try:
            test_file = path / f".test_{time.time()}.tmp"
            test_file.touch()
            test_file.unlink()
            return True
        except PermissionError:
            logger.error(f"No write permission for {path}")
            return False
        except Exception as e:
            logger.error(f"Permission check failed: {e}")
            return False

    def _is_file_locked(self, file_path: Path) -> bool:
        """Check if a file is locked (e.g., in use)."""
        try:
            with open(file_path, 'a'):
                return False
        except PermissionError:
            return True
        except Exception:
            return False

    async def _restart_application(self):
        """Restart the application using a batch script."""
        try:
            executable = sys.executable if hasattr(sys, '_MEIPASS') else sys.argv[0]
            batch_script = Path.cwd() / "restart.bat"
            with open(batch_script, 'w') as f:
                f.write(f"""
                @echo off
                timeout /t 2
                start "" "{executable}" {" ".join(sys.argv[1:])}
                """)
            subprocess.Popen([str(batch_script)], shell=True)
            logger.info("Initiating restart")
            # Signal main loop to exit
            sys.exit(0)
        except Exception as e:
            logger.error(f"Restart failed: {e}")
            return False

    def _cleanup_old_temp_dirs(self):
        """Cleanup old temporary directories."""
        for temp_dir in Path(tempfile.gettempdir()).glob("gmail_printer_*"):
            try:
                shutil.rmtree(temp_dir)
            except Exception as e:
                logger.warning(f"Failed to cleanup {temp_dir}: {e}")
# --- END OF auto_updater.py ---

# --- START OF config.py ---
"""
Production-ready configuration management with comprehensive validation.
"""
import os
import sys
import logging
from pathlib import Path
from dotenv import load_dotenv
from typing import List, Optional

logger = logging.getLogger(__name__)

class ConfigValidationError(Exception):
    """Raised when configuration validation fails."""
    pass

class Config:
    """Production configuration class with comprehensive validation."""
    
    def __init__(self, dry_run: bool = False, run_once: bool = False):
        """Initialize configuration with validation."""
        # Load environment variables
        load_dotenv()
        
        # Runtime flags
        self.DRY_RUN = dry_run
        self.RUN_ONCE = run_once
        self.ENABLE_AUTO_UPDATE = os.getenv('ENABLE_AUTO_UPDATE', 'false').lower() == 'true'
        
        # Email settings (REQUIRED)
        self.EMAIL_ADDRESS = self._get_required_env('EMAIL_ADDRESS')
        self.EMAIL_PASSWORD = self._get_required_env('EMAIL_PASSWORD')
        self.IMAP_SERVER = os.getenv('IMAP_SERVER', 'imap.gmail.com')
        self.IMAP_PORT = int(os.getenv('IMAP_PORT', '993'))
        self.MAILBOX = os.getenv('MAILBOX', 'INBOX')
        
        # Target email criteria (at least one required for production)
        self.TARGET_SENDER = os.getenv('TARGET_SENDER', '').strip()
        self.TARGET_SUBJECT = os.getenv('TARGET_SUBJECT', '').strip()
        
        # File handling
        allowed_types = os.getenv('ALLOWED_FILE_TYPES', 'pdf,docx,doc,jpg,jpeg,png,txt')
        self.ALLOWED_FILE_TYPES = [ext.strip().lower() for ext in allowed_types.split(',') if ext.strip()]
        self.MAX_ATTACHMENT_SIZE_MB = float(os.getenv('MAX_ATTACHMENT_SIZE_MB', '50'))
        self.ALLOW_ALL_FILE_TYPES = os.getenv('ALLOW_ALL_FILE_TYPES', 'false').lower() == 'true'
        
        # Printing settings
        self.COPIES = int(os.getenv('COPIES', '1'))
        self.ENABLE_DUPLEX = os.getenv('ENABLE_DUPLEX', 'false').lower() == 'true'
        self.PRINTER_NAME = os.getenv('PRINTER_NAME', 'Microsoft Print to PDF')
        self.MAX_PRINT_RETRIES = int(os.getenv('MAX_PRINT_RETRIES', '3'))
        self.PRINT_RETRY_DELAY_SECONDS = float(os.getenv('PRINT_RETRY_DELAY_SECONDS', '5'))
        
        # System settings
        self.POLL_INTERVAL_SECONDS = int(os.getenv('POLL_INTERVAL_SECONDS', '30'))
        self.LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO').upper()
        
        # Directory settings
        self.DOWNLOAD_DIR = self._create_directory('DOWNLOAD_DIR', 'attachments')
        self.MALWARE_SCAN_TEMP_DIR = self._create_directory('MALWARE_SCAN_TEMP_DIR', 'malware_scan_temp')
        self.PROCESSED_IDS_FILE = Path(os.getenv('PROCESSED_IDS_FILE', 'processed_ids.json')).resolve()
        
        # External tools with better defaults
        sumatra_path = os.getenv('SUMATRA_PDF_PATH', '')
        if sumatra_path:
            self.SUMATRA_PDF_PATH = Path(sumatra_path).resolve()
        else:
            # Common installation paths
            common_paths = [
                Path(r"C:\Program Files\SumatraPDF\SumatraPDF.exe"),
                Path(r"C:\Program Files (x86)\SumatraPDF\SumatraPDF.exe"),
                Path(r"C:\Users") / os.getenv('USERNAME', 'Default') / r"AppData\Local\SumatraPDF\SumatraPDF.exe"
            ]
            self.SUMATRA_PDF_PATH = None
            for path in common_paths:
                if path.exists():
                    self.SUMATRA_PDF_PATH = path
                    break
            if not self.SUMATRA_PDF_PATH:
                self.SUMATRA_PDF_PATH = Path('SumatraPDF.exe')  # Fallback
        
        # Security settings with proper defaults
        self.ENABLE_MALWARE_SCAN = os.getenv('ENABLE_MALWARE_SCAN', 'true').lower() == 'true'
        self.DISABLE_MALWARE_SCAN = os.getenv('DISABLE_MALWARE_SCAN', 'false').lower() == 'true'
        self.MAX_SCAN_FILE_SIZE_MB = float(os.getenv('MAX_SCAN_FILE_SIZE_MB', '100'))
        
        # Timeout settings - ensure all are defined
        self.TIMEOUT_DEFENDER_SCAN_SECONDS = int(os.getenv('TIMEOUT_DEFENDER_SCAN_SECONDS', '30'))
        self.TIMEOUT_CLAMAV_SCAN_SECONDS = int(os.getenv('TIMEOUT_CLAMAV_SCAN_SECONDS', '60'))
        self.TIMEOUT_SUMATRA_PRINT_SECONDS = int(os.getenv('TIMEOUT_SUMATRA_PRINT_SECONDS', '60'))
        self.TIMEOUT_LP_PRINT_SECONDS = int(os.getenv('TIMEOUT_LP_PRINT_SECONDS', '30'))
        self.TIMEOUT_WORD_CONVERSION_SECONDS = int(os.getenv('TIMEOUT_WORD_CONVERSION_SECONDS', '60'))
        
        # Domain validation
        allowed_domains = os.getenv('ALLOWED_SENDER_DOMAINS', '')
        self.ALLOWED_SENDER_DOMAINS = [d.strip().lower() for d in allowed_domains.split(',') if d.strip()] if allowed_domains else []
        self.ENABLE_DNS_VALIDATION = os.getenv('ENABLE_DNS_VALIDATION', 'false').lower() == 'true'
        
        # Auto-updater settings
        self.UPDATE_CHECK_INTERVAL_HOURS = int(os.getenv('UPDATE_CHECK_INTERVAL_HOURS', '24'))
        self.UPDATE_REPOSITORY_URL = os.getenv('UPDATE_REPOSITORY_URL', '').strip()
        self.UPDATE_BRANCH = os.getenv('UPDATE_BRANCH', 'main')
        
        # Error notification settings
        self.ERROR_WEBHOOK_URL = os.getenv('ERROR_WEBHOOK_URL', '').strip()
        self.ERROR_EMAIL_RECIPIENT = os.getenv('ERROR_EMAIL_RECIPIENT', '').strip()
        self.ERROR_NOTIFICATION_ENABLED = os.getenv('ERROR_NOTIFICATION_ENABLED', 'true').lower() == 'true'
        
        # Validate configuration
        self._validate_config()

    def _get_required_env(self, key: str) -> str:
        """Get required environment variable or raise error."""
        value = os.getenv(key, '').strip()
        if not value:
            raise ConfigValidationError(f"Required environment variable {key} is not set")
        return value

    def _create_directory(self, env_key: str, default_name: str) -> Path:
        """Create and return directory path."""
        dir_path = Path(os.getenv(env_key, default_name)).resolve()
        try:
            dir_path.mkdir(parents=True, exist_ok=True)
            return dir_path
        except (OSError, PermissionError) as e:
            raise ConfigValidationError(f"Failed to create directory {dir_path}: {e}")

    def _validate_config(self):
        """Comprehensive configuration validation."""
        errors = []
        
        # Validate email settings
        if '@' not in self.EMAIL_ADDRESS:
            errors.append("EMAIL_ADDRESS must be a valid email address")
        if not self.EMAIL_PASSWORD:
            errors.append("EMAIL_PASSWORD cannot be empty")
        
        # Production requires email filtering (but not for dry-run)
        if not self.DRY_RUN and not self.TARGET_SENDER and not self.TARGET_SUBJECT:
            errors.append("Either TARGET_SENDER or TARGET_SUBJECT must be set for production use")
        
        # Validate numeric settings
        if self.MAX_ATTACHMENT_SIZE_MB <= 0:
            errors.append("MAX_ATTACHMENT_SIZE_MB must be positive")
        if self.COPIES <= 0:
            errors.append("COPIES must be positive")
        if self.POLL_INTERVAL_SECONDS <= 0:
            errors.append("POLL_INTERVAL_SECONDS must be positive")
        if self.MAX_PRINT_RETRIES <= 0:
            errors.append("MAX_PRINT_RETRIES must be positive")
            
        # Validate timeout settings
        timeout_settings = [
            ('TIMEOUT_DEFENDER_SCAN_SECONDS', self.TIMEOUT_DEFENDER_SCAN_SECONDS),
            ('TIMEOUT_CLAMAV_SCAN_SECONDS', self.TIMEOUT_CLAMAV_SCAN_SECONDS),
            ('TIMEOUT_SUMATRA_PRINT_SECONDS', self.TIMEOUT_SUMATRA_PRINT_SECONDS),
            ('TIMEOUT_LP_PRINT_SECONDS', self.TIMEOUT_LP_PRINT_SECONDS),
            ('TIMEOUT_WORD_CONVERSION_SECONDS', self.TIMEOUT_WORD_CONVERSION_SECONDS)
        ]
        
        for setting_name, setting_value in timeout_settings:
            if setting_value <= 0:
                errors.append(f"{setting_name} must be positive")
        
        # Validate file types
        if not self.ALLOWED_FILE_TYPES and not self.ALLOW_ALL_FILE_TYPES:
            errors.append("Either ALLOWED_FILE_TYPES must be specified or ALLOW_ALL_FILE_TYPES must be true")
        
        # Validate log level
        valid_log_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
        if self.LOG_LEVEL not in valid_log_levels:
            errors.append(f"LOG_LEVEL must be one of: {valid_log_levels}")
        
        # Check malware scan settings
        if self.DISABLE_MALWARE_SCAN and self.ENABLE_MALWARE_SCAN:
            logger.warning("Both ENABLE_MALWARE_SCAN and DISABLE_MALWARE_SCAN are true; disabling malware scanning")
            self.ENABLE_MALWARE_SCAN = False
        
        # Validate error notification settings
        if self.ERROR_NOTIFICATION_ENABLED:
            if not self.ERROR_WEBHOOK_URL and not self.ERROR_EMAIL_RECIPIENT:
                logger.warning("Error notifications enabled but no webhook URL or email recipient specified")
        
        # Report validation errors
        if errors:
            error_message = "Configuration validation failed:\n" + "\n".join(f"  - {error}" for error in errors)
            raise ConfigValidationError(error_message)
        
        logger.info("Configuration validation passed")

    def get_summary(self) -> dict:
        """Get configuration summary for logging."""
        return {
            'email_address': self.EMAIL_ADDRESS,
            'target_sender': self.TARGET_SENDER or 'Not set',
            'target_subject': self.TARGET_SUBJECT or 'Not set',
            'printer_name': self.PRINTER_NAME,
            'allowed_file_types': self.ALLOWED_FILE_TYPES,
            'max_attachment_size_mb': self.MAX_ATTACHMENT_SIZE_MB,
            'copies': self.COPIES,
            'duplex_enabled': self.ENABLE_DUPLEX,
            'malware_scan_enabled': self.ENABLE_MALWARE_SCAN and not self.DISABLE_MALWARE_SCAN,
            'auto_update_enabled': self.ENABLE_AUTO_UPDATE,
            'dry_run': self.DRY_RUN,
            'run_once': self.RUN_ONCE,
            'sumatra_pdf_path': str(self.SUMATRA_PDF_PATH) if self.SUMATRA_PDF_PATH else 'Not found'
        }
# --- END OF config.py ---

# --- START OF constants.py ---
"""
Constants used throughout the application.
"""

# Timeouts (seconds)
TIMEOUT_SUMATRA_PRINT_SECONDS = 60
TIMEOUT_LP_PRINT_SECONDS = 30
TIMEOUT_WORD_CONVERSION_SECONDS = 60

# File validation
FILE_HEADERS = {
    'pdf': [
        b'%PDF-',
    ],
    'docx': [
        b'PK\x03\x04',  # ZIP file signature (DOCX is ZIP-based)
    ],
    'doc': [
        b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1',  # OLE file signature
    ],
    'jpg': [
        b'\xff\xd8\xff',
    ],
    'jpeg': [
        b'\xff\xd8\xff',
    ],
    'png': [
        b'\x89PNG\r\n\x1a\n',
    ],
    'txt': [
        # Text files can start with anything, so no specific header check
    ],
    'FILE_HEADER_READ_BYTES': 512
}

# Application constants
APP_VERSION = "2.0.0"
APP_NAME = "Gmail Auto Printer"

# Error notification cooldowns (seconds)
ERROR_NOTIFICATION_COOLDOWN = 1800  # 30 minutes
CRITICAL_ERROR_COOLDOWN = 900       # 15 minutes

# File size limits (MB)
DEFAULT_MAX_ATTACHMENT_SIZE = 50
DEFAULT_MAX_SCAN_SIZE = 100

# Retry settings
DEFAULT_MAX_RETRIES = 3
DEFAULT_RETRY_DELAY = 5

# Polling settings
DEFAULT_POLL_INTERVAL = 30
MIN_POLL_INTERVAL = 10
MAX_POLL_INTERVAL = 3600
# --- END OF constants.py ---

# --- START OF docx_to_pdf_converter.py ---
"""
DOCX to PDF converter with multiple fallback options for maximum compatibility.
Fixed COM threading issues and improved error handling.
"""
import logging
import asyncio
import sys
import subprocess
import threading
from pathlib import Path
from typing import Optional

# Try to import comtypes - handle compatibility issues
COMTYPES_AVAILABLE = False
WORD_CONVERSION_AVAILABLE = False

try:
    # Check Python version compatibility
    if sys.version_info >= (3, 13):
        logger = logging.getLogger(__name__)
        logger.warning("Python 3.13+ detected - comtypes may have compatibility issues")
        logger.info("Will use alternative conversion methods")
    else:
        import comtypes.client
        import comtypes
        from comtypes import COMError
        COMTYPES_AVAILABLE = True
        WORD_CONVERSION_AVAILABLE = True
except ImportError as e:
    logger = logging.getLogger(__name__)
    logger.warning(f"comtypes not available: {e}")
    logger.info("Will use alternative conversion methods")
    COMError = Exception
except Exception as e:
    logger = logging.getLogger(__name__)
    logger.warning(f"comtypes initialization failed: {e}")
    COMError = Exception

logger = logging.getLogger(__name__)

class DocxToPDFConverter:
    """Converts DOCX files to PDF using multiple fallback methods."""
    
    def __init__(self):
        self.conversion_methods = [
            ("PowerShell", self._convert_with_powershell),  # Move PowerShell first - more reliable
            ("Microsoft Word COM", self._convert_with_word_com),
            ("LibreOffice", self._convert_with_libreoffice),
            ("Copy as is", self._copy_as_fallback)
        ]

    async def convert_to_pdf(self, docx_path: Path, pdf_path: Path) -> bool:
        """Convert DOCX file to PDF using best available method."""
        docx_path = docx_path.resolve()
        pdf_path = pdf_path.resolve()

        if not docx_path.exists():
            logger.error(f"DOCX file not found: {docx_path}")
            return False

        logger.info(f"Converting {docx_path.name} to PDF")

        # Try each conversion method in order
        for method_name, method_func in self.conversion_methods:
            try:
                logger.debug(f"Trying conversion method: {method_name}")
                success = await method_func(docx_path, pdf_path)
                
                if success and pdf_path.exists():
                    logger.info(f"DOCX conversion successful using {method_name}: {pdf_path.name}")
                    return True
                else:
                    logger.debug(f"Method {method_name} failed or produced no output")
                    
            except Exception as e:
                logger.debug(f"Method {method_name} failed with error: {e}")
                continue

        logger.error(f"All conversion methods failed for: {docx_path.name}")
        return False

    async def _convert_with_word_com(self, docx_path: Path, pdf_path: Path) -> bool:
        """Convert using Microsoft Word COM API - Fixed threading issues."""
        if not WORD_CONVERSION_AVAILABLE:
            return False

        try:
            # Run COM operations in a separate thread to avoid threading issues
            success = await asyncio.to_thread(self._convert_com_sync, docx_path, pdf_path)
            return success

        except asyncio.TimeoutError:
            logger.warning(f"Word COM conversion timed out: {docx_path.name}")
            return False
        except Exception as e:
            logger.debug(f"Word COM conversion error: {e}")
            return False

    def _convert_com_sync(self, docx_path: Path, pdf_path: Path) -> bool:
        """Synchronous COM conversion - runs in separate thread."""
        word = None
        doc = None
        
        try:
            # Initialize COM for this thread
            comtypes.CoInitialize()
            
            # Create Word application
            word = comtypes.client.CreateObject("Word.Application")
            word.Visible = False
            word.DisplayAlerts = False
            
            # Open document
            doc = word.Documents.Open(
                str(docx_path),
                ReadOnly=True,
                AddToRecentFiles=False
            )
            
            # Save as PDF (format 17 = wdFormatPDF)
            doc.SaveAs2(str(pdf_path), FileFormat=17)
            
            return True
            
        except Exception as e:
            logger.debug(f"COM sync conversion error: {e}")
            return False
        finally:
            # Clean up resources
            try:
                if doc:
                    doc.Close(SaveChanges=False)
                if word:
                    word.Quit()
                comtypes.CoUninitialize()
            except:
                pass

    async def _convert_with_libreoffice(self, docx_path: Path, pdf_path: Path) -> bool:
        """Convert using LibreOffice command line."""
        try:
            # Check if LibreOffice is available
            libreoffice_paths = [
                "soffice",
                "libreoffice",
                r"C:\Program Files\LibreOffice\program\soffice.exe",
                r"C:\Program Files (x86)\LibreOffice\program\soffice.exe"
            ]
            
            soffice_path = None
            for path in libreoffice_paths:
                try:
                    result = await asyncio.to_thread(
                        subprocess.run, [path, "--version"],
                        capture_output=True, timeout=5,
                        creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
                    )
                    if result.returncode == 0:
                        soffice_path = path
                        break
                except:
                    continue

            if not soffice_path:
                return False

            # Convert with LibreOffice
            cmd = [
                soffice_path,
                "--headless",
                "--convert-to", "pdf",
                "--outdir", str(pdf_path.parent),
                str(docx_path)
            ]

            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=60,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )

            # LibreOffice creates PDF with same name as input
            expected_pdf = pdf_path.parent / f"{docx_path.stem}.pdf"
            if expected_pdf.exists() and expected_pdf != pdf_path:
                expected_pdf.rename(pdf_path)

            return result.returncode == 0 and pdf_path.exists()

        except Exception as e:
            logger.debug(f"LibreOffice conversion error: {e}")
            return False

    async def _convert_with_powershell(self, docx_path: Path, pdf_path: Path) -> bool:
        """Convert using PowerShell with Word automation - More reliable than COM."""
        try:
            # Escape paths for PowerShell
            docx_escaped = str(docx_path).replace("'", "''")
            pdf_escaped = str(pdf_path).replace("'", "''")
            
            script = f'''
            try {{
                $ErrorActionPreference = "Stop"
                $word = New-Object -ComObject Word.Application
                $word.Visible = $false
                $word.DisplayAlerts = 0
                
                $doc = $word.Documents.Open('{docx_escaped}', $false, $true)
                $doc.SaveAs2('{pdf_escaped}', 17)
                $doc.Close($false)
                $word.Quit()
                
                [System.Runtime.Interopservices.Marshal]::ReleaseComObject($doc) | Out-Null
                [System.Runtime.Interopservices.Marshal]::ReleaseComObject($word) | Out-Null
                [System.GC]::Collect()
                [System.GC]::WaitForPendingFinalizers()
                
                Write-Output "Conversion successful"
                exit 0
            }} catch {{
                Write-Error "Conversion failed: $($_.Exception.Message)"
                if ($word) {{ 
                    try {{ $word.Quit() }} catch {{}}
                }}
                exit 1
            }}
            '''

            result = await asyncio.to_thread(
                subprocess.run, 
                ["powershell", "-ExecutionPolicy", "Bypass", "-Command", script],
                capture_output=True, text=True, timeout=60,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )

            if result.returncode == 0 and pdf_path.exists():
                logger.debug(f"PowerShell conversion successful: {result.stdout.strip()}")
                return True
            else:
                logger.debug(f"PowerShell conversion failed: {result.stderr}")
                return False

        except Exception as e:
            logger.debug(f"PowerShell conversion error: {e}")
            return False

    async def _copy_as_fallback(self, docx_path: Path, pdf_path: Path) -> bool:
        """Fallback: copy DOCX as-is but rename to PDF (for basic printing support)."""
        try:
            logger.warning(f"No conversion method available - copying {docx_path.name} as PDF")
            logger.warning("File may not print correctly without proper conversion")
            
            # Copy the file
            await asyncio.to_thread(pdf_path.write_bytes, docx_path.read_bytes())
            return pdf_path.exists()

        except Exception as e:
            logger.debug(f"Fallback copy error: {e}")
            return False

    async def cleanup(self):
        """Clean up resources - simplified since we don't hold persistent COM objects."""
        try:
            logger.debug("DocX converter cleanup completed")
        except Exception as e:
            logger.debug(f"Error during cleanup: {e}")

    def get_available_methods(self) -> list:
        """Get list of available conversion methods."""
        methods = []
        
        methods.append("PowerShell (if Word installed)")
        
        if WORD_CONVERSION_AVAILABLE:
            methods.append("Microsoft Word COM")
        
        # Check LibreOffice
        try:
            subprocess.run(["soffice", "--version"], 
                         capture_output=True, timeout=2,
                         creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0)
            methods.append("LibreOffice")
        except:
            pass
        
        methods.append("Copy as fallback")
        
        return methods
# --- END OF docx_to_pdf_converter.py ---

# --- START OF environment_checker.py ---
"""
Comprehensive environment checker for production readiness with better printer detection.
"""
import asyncio
import logging
import os
import platform
import subprocess
import sys
import shutil
import socket
from pathlib import Path
from typing import Dict, List, Tuple

logger = logging.getLogger(__name__)

class EnvironmentChecker:
    """Comprehensive environment checker for production deployment."""
    
    def __init__(self, config):
        self.config = config
        self.check_results = {}

    async def check_all(self) -> bool:
        """Run all environment checks."""
        checks = [
            ("Python Version", self._check_python_version),
            ("Required Directories", self._check_directories),
            ("Gmail Credentials", self._check_gmail_credentials),
            ("Printer Availability", self._check_printer),
            ("SumatraPDF", self._check_sumatra_pdf),
            ("Microsoft Word", self._check_microsoft_word),
            ("Malware Scanner", self._check_malware_scanner),
            ("Disk Space", self._check_disk_space),
            ("Network Connectivity", self._check_network),
            ("File Permissions", self._check_file_permissions)
        ]
        
        all_passed = True
        logger.info("=" * 50)
        logger.info("🔍 Environment Check Starting")
        logger.info("=" * 50)
        
        for check_name, check_func in checks:
            try:
                passed, details = await check_func()
                self.check_results[check_name] = {"passed": passed, "details": details}
                
                status = "✅ PASS" if passed else "❌ FAIL"
                logger.info(f"{status} - {check_name}: {details}")
                
                if not passed:
                    all_passed = False
                    
            except Exception as e:
                self.check_results[check_name] = {"passed": False, "details": f"Check failed: {e}"}
                logger.error(f"❌ ERROR - {check_name}: {e}")
                all_passed = False

        logger.info("=" * 50)
        result_text = "PASSED" if all_passed else "FAILED"
        logger.info(f"🔍 Environment Check Complete - {result_text}")
        logger.info("=" * 50)
        
        # If printer check failed, provide helpful suggestions
        if not self.check_results.get("Printer Availability", {}).get("passed", True):
            self._print_printer_suggestions()
        
        return all_passed

    async def _check_python_version(self) -> Tuple[bool, str]:
        """Check Python version compatibility."""
        version = sys.version_info
        
        if version < (3, 8):
            return False, f"Python {version.major}.{version.minor} too old (need 3.8+)"
        
        if version >= (3, 13):
            return True, f"Python {version.major}.{version.minor} (comtypes compatibility warning)"
        
        return True, f"Python {version.major}.{version.minor} (compatible)"

    async def _check_directories(self) -> Tuple[bool, str]:
        """Check required directories exist and are writable."""
        try:
            directories = [
                self.config.DOWNLOAD_DIR,
                self.config.MALWARE_SCAN_TEMP_DIR,
                Path('logs')
            ]
            
            for directory in directories:
                directory.mkdir(parents=True, exist_ok=True)
                
                # Test write permission
                test_file = directory / 'test_write.tmp'
                test_file.write_text('test')
                test_file.unlink()
            
            return True, f"All directories accessible ({len(directories)} checked)"
            
        except Exception as e:
            return False, f"Directory setup failed: {e}"

    async def _check_gmail_credentials(self) -> Tuple[bool, str]:
        """Check Gmail credentials and API setup."""
        try:
            # Check credentials file
            if not Path('credentials.json').exists():
                return False, "credentials.json not found"
            
            # Validate email format
            email = self.config.EMAIL_ADDRESS
            if '@' not in email or len(email.split('@')) != 2:
                return False, "Invalid email address format"
            
            # Check app password length (should be 16 chars for Gmail)
            password = self.config.EMAIL_PASSWORD
            if len(password.replace(' ', '')) < 10:
                return False, "App password too short (use Gmail app password)"
            
            return True, f"Credentials configured for {email}"
            
        except Exception as e:
            return False, f"Credential check failed: {e}"

    async def _check_printer(self) -> Tuple[bool, str]:
        """Check printer availability with improved detection."""
        if self.config.DRY_RUN:
            return True, "Skipped (dry-run mode)"
        
        try:
            # Get all available printers using multiple methods
            available_printers = await self._get_all_printers()
            
            if not available_printers:
                return False, "No printers found on system"
            
            # Check if target printer exists (case-insensitive)
            target_printer_lower = self.config.PRINTER_NAME.lower()
            matching_printer = None
            
            for printer in available_printers:
                if printer.lower() == target_printer_lower:
                    matching_printer = printer
                    break
            
            if matching_printer:
                # Check printer status
                status = await self._get_printer_status(matching_printer)
                duplex_info = await self._check_printer_duplex(matching_printer)
                
                return True, f"'{matching_printer}' found - Status: {status}{duplex_info}"
            else:
                # Store available printers for suggestions
                self._available_printers = available_printers
                return False, f"Printer '{self.config.PRINTER_NAME}' not found. Found {len(available_printers)} other printers."
                
        except Exception as e:
            return False, f"Printer check failed: {e}"

    async def _get_all_printers(self) -> List[str]:
        """Get all available printers using multiple detection methods."""
        printers = []
        
        # Method 1: PowerShell Get-Printer (preferred)
        try:
            cmd = [
                "powershell", "-Command",
                "Get-Printer | Select-Object -ExpandProperty Name"
            ]
            
            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=15,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0 and result.stdout.strip():
                printers = [p.strip() for p in result.stdout.strip().split('\n') if p.strip()]
                logger.debug(f"PowerShell found {len(printers)} printers")
                if printers:
                    return printers
                    
        except Exception as e:
            logger.debug(f"PowerShell printer detection failed: {e}")
        
        # Method 2: WMI command line
        try:
            cmd = ["wmic", "printer", "get", "name", "/format:value"]
            
            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=15,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if line.startswith('Name=') and '=' in line:
                        printer_name = line.split('=', 1)[1].strip()
                        if printer_name:
                            printers.append(printer_name)
                
                logger.debug(f"WMI found {len(printers)} printers")
                if printers:
                    return printers
                    
        except Exception as e:
            logger.debug(f"WMI printer detection failed: {e}")
        
        # Method 3: PowerShell WMI
        try:
            cmd = [
                "powershell", "-Command",
                "Get-WmiObject -Class Win32_Printer | Select-Object -ExpandProperty Name"
            ]
            
            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=15,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0 and result.stdout.strip():
                printers = [p.strip() for p in result.stdout.strip().split('\n') if p.strip()]
                logger.debug(f"WMI PowerShell found {len(printers)} printers")
                if printers:
                    return printers
                    
        except Exception as e:
            logger.debug(f"WMI PowerShell detection failed: {e}")
        
        return printers

    async def _get_printer_status(self, printer_name: str) -> str:
        """Get printer status."""
        try:
            cmd = [
                "powershell", "-Command",
                f"Get-Printer -Name '{printer_name}' | Select-Object -ExpandProperty PrinterStatus"
            ]
            
            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0 and result.stdout.strip():
                status = result.stdout.strip()
                return "Normal" if status == "0" else status
            else:
                return "Unknown"
                
        except Exception:
            return "Unknown"

    async def _check_printer_duplex(self, printer_name: str) -> str:
        """Check if printer supports duplex."""
        try:
            cmd = [
                "powershell", "-Command",
                f"Get-PrinterProperty -PrinterName '{printer_name}' | Where-Object {{$_.PropertyName -like '*duplex*'}}"
            ]
            
            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0 and result.stdout.strip() and "true" in result.stdout.lower():
                return " (duplex supported)"
            else:
                return " (simplex only)"
                
        except Exception:
            return ""

    async def _check_sumatra_pdf(self) -> Tuple[bool, str]:
        """Check SumatraPDF availability."""
        try:
            # Check configured path first
            if self.config.SUMATRA_PDF_PATH and self.config.SUMATRA_PDF_PATH.exists():
                return True, f"Found at {self.config.SUMATRA_PDF_PATH}"
            
            # Check common locations
            common_paths = [
                Path("SumatraPDF.exe"),
                Path(r"C:\Program Files\SumatraPDF\SumatraPDF.exe"),
                Path(r"C:\Program Files (x86)\SumatraPDF\SumatraPDF.exe"),
            ]
            
            for path in common_paths:
                if path.exists():
                    return True, f"Found at {path}"
            
            # Check if in PATH
            if shutil.which("SumatraPDF"):
                return True, "Found in PATH"
            
            return False, "SumatraPDF not found (PDF printing may fail)"
            
        except Exception as e:
            return False, f"SumatraPDF check failed: {e}"

    async def _check_microsoft_word(self) -> Tuple[bool, str]:
        """Check Microsoft Word availability for DOCX conversion."""
        try:
            # Try to detect Word via COM
            cmd = [
                "powershell", "-Command",
                "try { $word = New-Object -ComObject Word.Application; $word.Quit(); 'Available' } catch { 'Not Available' }"
            ]
            
            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if "Available" in result.stdout:
                return True, "Microsoft Word available for DOCX conversion"
            else:
                return False, "Microsoft Word not available (DOCX conversion limited)"
                
        except Exception as e:
            return False, f"Word check failed: {e}"

    async def _check_malware_scanner(self) -> Tuple[bool, str]:
        """Check malware scanner availability."""
        if self.config.DISABLE_MALWARE_SCAN or not self.config.ENABLE_MALWARE_SCAN:
            return True, "Malware scanning disabled"
        
        try:
            # Check Windows Defender
            cmd = [
                "powershell", "-Command",
                "Get-MpPreference -ErrorAction SilentlyContinue | Select-Object -Property DisableRealtimeMonitoring"
            ]
            
            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0:
                if "False" in result.stdout:
                    return True, "Windows Defender active"
                else:
                    return False, "Windows Defender disabled"
            else:
                return False, "Windows Defender not accessible"
                
        except Exception as e:
            return False, f"Malware scanner check failed: {e}"

    async def _check_disk_space(self) -> Tuple[bool, str]:
        """Check available disk space."""
        try:
            # Check space in current directory
            statvfs = os.statvfs('.') if hasattr(os, 'statvfs') else None
            if statvfs:
                free_bytes = statvfs.f_frsize * statvfs.f_bavail
                free_mb = free_bytes / (1024 * 1024)
            else:
                # Windows alternative
                import shutil
                total, used, free = shutil.disk_usage('.')
                free_mb = free / (1024 * 1024)
            
            if free_mb < 100:  # Less than 100MB
                return False, f"Low disk space: {free_mb:.1f}MB available"
            elif free_mb < 500:  # Less than 500MB
                return True, f"Disk space OK: {free_mb:.1f}MB available (warning)"
            else:
                return True, f"Disk space OK: {free_mb:.1f}MB available"
                
        except Exception as e:
            return False, f"Disk space check failed: {e}"

    async def _check_network(self) -> Tuple[bool, str]:
        """Check network connectivity."""
        try:
            # Test DNS resolution
            socket.setdefaulttimeout(5)
            socket.gethostbyname('gmail.com')
            
            # Test HTTPS connectivity to Gmail
            import ssl
            context = ssl.create_default_context()
            with socket.create_connection(('gmail.com', 443), timeout=5) as sock:
                with context.wrap_socket(sock, server_hostname='gmail.com') as ssock:
                    pass
            
            return True, "Network connectivity OK"
            
        except socket.gaierror:
            return False, "DNS resolution failed"
        except socket.timeout:
            return False, "Network connection timed out"
        except Exception as e:
            return False, f"Network check failed: {e}"
        finally:
            socket.setdefaulttimeout(None)

    async def _check_file_permissions(self) -> Tuple[bool, str]:
        """Check file permissions for critical files."""
        try:
            critical_files = [
                self.config.PROCESSED_IDS_FILE,
                Path('.env'),
                Path('logs')
            ]
            
            issues = []
            for file_path in critical_files:
                if file_path.exists():
                    # Test read access
                    if file_path.is_file():
                        try:
                            file_path.read_text()
                        except PermissionError:
                            issues.append(f"Cannot read {file_path}")
                    
                    # Test write access
                    try:
                        if file_path.is_file():
                            # Test by opening in append mode
                            with open(file_path, 'a') as f:
                                pass
                        else:
                            # Directory - test by creating temp file
                            test_file = file_path / 'test_permissions.tmp'
                            test_file.touch()
                            test_file.unlink()
                    except PermissionError:
                        issues.append(f"Cannot write to {file_path}")
            
            if issues:
                return False, f"Permission issues: {', '.join(issues)}"
            else:
                return True, f"File permissions OK ({len(critical_files)} files checked)"
                
        except Exception as e:
            return False, f"Permission check failed: {e}"

    def _print_printer_suggestions(self):
        """Print helpful printer setup suggestions."""
        if hasattr(self, '_available_printers') and self._available_printers:
            logger.info("")
            logger.info("🖨️  PRINTER SETUP SUGGESTIONS:")
            logger.info("=" * 50)
            logger.info(f"Current setting: PRINTER_NAME={self.config.PRINTER_NAME}")
            logger.info("")
            logger.info("Available printers on your system:")
            
            for i, printer in enumerate(self._available_printers, 1):
                logger.info(f"  {i}. {printer}")
            
            logger.info("")
            logger.info("To fix this issue:")
            logger.info("1. Update your .env file with one of the exact printer names above")
            logger.info("2. Use the exact name including spaces and capitalization")
            logger.info("3. Example: PRINTER_NAME=Microsoft Print to PDF")
            logger.info("")
            logger.info("If 'Microsoft Print to PDF' is not listed, you can add it:")
            logger.info("1. Open Windows Settings > Printers & scanners")
            logger.info("2. Click 'Add printer or scanner'")
            logger.info("3. Click 'The printer that I want isn't listed'")
            logger.info("4. Select 'Add a local printer...'")
            logger.info("5. Choose 'Microsoft Print to PDF' from the list")
            logger.info("=" * 50)
        else:
            logger.info("")
            logger.info("🖨️  NO PRINTERS FOUND:")
            logger.info("=" * 50)
            logger.info("No printers were detected on your system.")
            logger.info("")
            logger.info("To add the Microsoft Print to PDF printer:")
            logger.info("1. Open Windows Settings > Printers & scanners")
            logger.info("2. Click 'Add printer or scanner'")
            logger.info("3. Click 'The printer that I want isn't listed'")
            logger.info("4. Select 'Add a local printer...'")
            logger.info("5. Create a new port > Local Port")
            logger.info("6. Enter any name (e.g., 'FILE:')")
            logger.info("7. Choose 'Microsoft' > 'Microsoft Print To PDF'")
            logger.info("8. Set as default if desired")
            logger.info("=" * 50)

    def get_check_results(self) -> Dict:
        """Get detailed check results."""
        return self.check_results.copy()

    def print_detailed_report(self):
        """Print detailed environment report."""
        logger.info("\n" + "=" * 60)
        logger.info("📋 DETAILED ENVIRONMENT REPORT")
        logger.info("=" * 60)
        
        for check_name, result in self.check_results.items():
            status = "✅ PASS" if result["passed"] else "❌ FAIL"
            logger.info(f"{status} {check_name}")
            logger.info(f"    {result['details']}")
            logger.info("")
        
        # System information
        logger.info("💻 SYSTEM INFORMATION")
        logger.info(f"    OS: {platform.system()} {platform.release()}")
        logger.info(f"    Python: {sys.version}")
        logger.info(f"    Architecture: {platform.architecture()[0]}")
        logger.info("=" * 60)
# --- END OF environment_checker.py ---

# --- START OF error_notifier.py ---
"""
Error notification system with webhook and email fallback.
"""
import asyncio
import logging
import json
import smtplib
import time
import traceback
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional, Dict
import aiohttp
from utils import SystemUtils

logger = logging.getLogger(__name__)

class ErrorNotifier:
    """Handles error notifications via webhook and email."""
    def __init__(self, config):
        self.config = config
        # Validate required config attributes
        required_attrs = ['EMAIL_ADDRESS', 'ERROR_NOTIFICATION_ENABLED']
        for attr in required_attrs:
            if not hasattr(config, attr):
                raise ValueError(f"Missing required config attribute: {attr}")
        self.last_notification_time = {}
        self.notification_cooldown = 1800  # 30 minutes, aligns with throttled alerts
        # Log warning if notifications enabled but no delivery method configured
        if self.config.ERROR_NOTIFICATION_ENABLED and not (getattr(self.config, 'ERROR_WEBHOOK_URL', None) or getattr(self.config, 'ERROR_EMAIL_RECIPIENT', None)):
            logger.warning("Error notifications enabled but no webhook URL or email recipient specified")

    async def send_error_notification(self, title: str, error_message: str, stack_trace: str = "", error_type: str = "general"):
        """Send error notification with throttling and error type."""
        if not self.config.ERROR_NOTIFICATION_ENABLED:
            logger.debug("Error notifications disabled, skipping notification")
            return
        # Throttle notifications
        if self._is_throttled(title):
            logger.debug(f"Notification throttled: {title} ({error_type})")
            return
        notification_data = self._prepare_notification_data(title, error_message, stack_trace, "error", error_type)
        # Try webhook first, then email fallback
        success = await self._send_webhook_notification(notification_data)
        if not success and getattr(self.config, 'ERROR_EMAIL_RECIPIENT', None):
            success = await self._send_email_notification(notification_data)
        if success:
            self._update_throttle_time(title)
            logger.info(f"Error notification sent: {title} ({error_type})")
        else:
            logger.error(f"Failed to send error notification: {title} ({error_type})")

    async def send_notification(self, title: str, message: str, level: str = "info"):
        """Send general notification."""
        if not self.config.ERROR_NOTIFICATION_ENABLED:
            logger.debug("Notifications disabled, skipping notification")
            return
        notification_data = self._prepare_notification_data(title, message, "", level, "general")
        # Try webhook first, then email fallback
        success = await self._send_webhook_notification(notification_data)
        if not success and getattr(self.config, 'ERROR_EMAIL_RECIPIENT', None):
            success = await self._send_email_notification(notification_data)
        if success:
            logger.info(f"Notification sent: {title}")
        else:
            logger.error(f"Failed to send notification: {title}")

    def _prepare_notification_data(self, title: str, message: str, stack_trace: str, level: str, error_type: str) -> Dict:
        """Prepare notification data with error type."""
        return {
            'title': title,
            'message': message,
            'stack_trace': stack_trace,
            'level': level,
            'error_type': error_type,
            'timestamp': time.time(),
            'hostname': self.config.EMAIL_ADDRESS,
            'version': SystemUtils.get_version(),
            'config_summary': {
                'printer': getattr(self.config, 'PRINTER_NAME', 'Not set'),
                'target_sender': getattr(self.config, 'TARGET_SENDER', 'Not set'),
                'dry_run': getattr(self.config, 'DRY_RUN', False)
            }
        }

    async def _send_webhook_notification(self, data: Dict) -> bool:
        """Send notification via webhook."""
        webhook_url = getattr(self.config, 'ERROR_WEBHOOK_URL', None)
        if not webhook_url:
            logger.debug("No webhook URL configured, skipping webhook notification")
            return False
        try:
            # Format for common webhook services (Slack, Discord, etc.)
            webhook_payload = {
                'text': f"🚨 {data['title']} ({data['error_type']})",
                'attachments': [
                    {
                        'color': 'danger' if data['level'] == 'error' else 'good',
                        'fields': [
                            {'title': 'Message', 'value': data['message'], 'short': False},
                            {'title': 'Hostname', 'value': data['hostname'], 'short': True},
                            {'title': 'Version', 'value': data['version'], 'short': True},
                            {'title': 'Printer', 'value': data['config_summary']['printer'], 'short': True},
                            {'title': 'Error Type', 'value': data['error_type'], 'short': True},
                            {'title': 'Time', 'value': time.ctime(data['timestamp']), 'short': True}
                        ]
                    }
                ]
            }
            if data['stack_trace']:
                webhook_payload['attachments'][0]['fields'].append({
                    'title': 'Stack Trace',
                    'value': f"```{data['stack_trace'][:1000]}```",
                    'short': False
                })
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    webhook_url,
                    json=webhook_payload,
                    timeout=30
                ) as response:
                    if response.status == 200:
                        return True
                    else:
                        logger.warning(f"Webhook failed: HTTP {response.status}")
                        return False
        except Exception as e:
            trace = traceback.format_exc()
            logger.error(f"Webhook notification failed: {e}\n{trace}")
            return False

    async def _send_email_notification(self, data: Dict) -> bool:
        """Send notification via email."""
        try:
            # Create email
            msg = MIMEMultipart()
            msg['From'] = self.config.EMAIL_ADDRESS
            msg['To'] = self.config.ERROR_EMAIL_RECIPIENT
            msg['Subject'] = f"Gmail Auto Printer - {data['title']} ({data['error_type']})"
            # Email body using triple-quoted string
            stack_trace_text = f"Stack Trace:\n{data['stack_trace']}" if data['stack_trace'] else ""
            body = f"""Gmail Auto Printer Notification
Title: {data['title']}
Level: {data['level'].upper()}
Error Type: {data['error_type']}
Time: {time.ctime(data['timestamp'])}
Version: {data['version']}
Hostname: {data['hostname']}
Message:
{data['message']}
Configuration:
- Printer: {data['config_summary']['printer']}
- Target Sender: {data['config_summary']['target_sender']}
- Dry Run: {data['config_summary']['dry_run']}
{stack_trace_text}
"""
            msg.attach(MIMEText(body, 'plain'))
            # Send email
            await asyncio.to_thread(self._send_smtp_email, msg)
            return True
        except Exception as e:
            trace = traceback.format_exc()
            logger.error(f"Email notification failed: {e}\n{trace}")
            return False

    def _send_smtp_email(self, msg):
        """Send email via SMTP (sync)."""
        try:
            with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
                server.login(self.config.EMAIL_ADDRESS, self.config.EMAIL_PASSWORD)
                server.send_message(msg)
        except smtplib.SMTPAuthenticationError:
            logger.error("SMTP authentication failed: Invalid email or password")
            raise
        except smtplib.SMTPConnectError:
            logger.error("SMTP connection failed: Unable to connect to Gmail server")
            raise
        except Exception as e:
            logger.error(f"SMTP email failed: {e}")
            raise

    def _is_throttled(self, title: str) -> bool:
        """Check if notification is throttled."""
        last_time = self.last_notification_time.get(title, 0)
        return (time.time() - last_time) < self.notification_cooldown

    def _update_throttle_time(self, title: str):
        """Update last notification time for throttling."""
        self.last_notification_time[title] = time.time()
# --- END OF error_notifier.py ---

# --- START OF exceptions.py ---
"""
Custom exceptions for the Gmail Auto Printer system.
"""
class EmailPrinterError(Exception):
    """Base exception for Email Printer errors."""
    pass
class ConfigurationError(EmailPrinterError):
    """Configuration related errors."""
    pass
class AttachmentValidationError(EmailPrinterError):
    """Attachment validation errors."""
    pass
class PrinterError(EmailPrinterError):
    """Printer related errors."""
    pass
class MalwareDetectionError(EmailPrinterError):
    """Malware detection errors."""
    pass
class NetworkError(EmailPrinterError):
    """Network related errors."""
    pass

# --- END OF exceptions.py ---

# --- START OF gmail_client.py ---
"""
Production-ready Gmail API client with comprehensive error handling.
"""
import asyncio
import logging
import os
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from typing import List, Dict, Optional
import time
from utils import ExponentialBackoff, SystemUtils
from exceptions import NetworkError
logger = logging.getLogger(__name__)
class GmailClient:
    """Production Gmail API client with robust error handling."""
    SCOPES = ['https://www.googleapis.com/auth/gmail.modify']
    CREDENTIALS_FILE = 'credentials.json'
    TOKEN_FILE = 'token.json'
    def __init__(self, config):
        self.config = config
        self.service = None
        self.last_auth_time = 0
        if not config.DRY_RUN:
            self._initialize_service()
        else:
            logger.info("DRY-RUN: Skipping Gmail service initialization")
    def _initialize_service(self):
        """Initialize Gmail service with error handling."""
        try:
            if not os.path.exists(self.CREDENTIALS_FILE):
                raise FileNotFoundError(f"Missing {self.CREDENTIALS_FILE}")
            self.service = self._get_gmail_service()
            logger.info("Gmail service initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Gmail service: {e}")
            raise NetworkError(f"Gmail initialization failed: {e}")
    def _get_gmail_service(self):
        """Get authenticated Gmail service."""
        creds = None
        # Load existing token
        if os.path.exists(self.TOKEN_FILE):
            try:
                creds = Credentials.from_authorized_user_file(self.TOKEN_FILE, self.SCOPES)
            except Exception as e:
                logger.warning(f"Failed to load existing token: {e}")
                self._cleanup_token_file()
        # Refresh or get new credentials
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                try:
                    creds.refresh(Request())
                    logger.info("Gmail credentials refreshed")
                except Exception as e:
                    logger.warning(f"Failed to refresh credentials: {e}")
                    self._cleanup_token_file()
                    creds = None
            if not creds:
                logger.info("Starting OAuth flow for Gmail authentication")
                flow = InstalledAppFlow.from_client_secrets_file(
                    self.CREDENTIALS_FILE, self.SCOPES
                )
                creds = flow.run_local_server(port=0)
            # Save credentials
            self._save_credentials(creds)
        try:
            service = build('gmail', 'v1', credentials=creds)
            self.last_auth_time = time.time()
            return service
        except Exception as e:
            raise NetworkError(f"Failed to build Gmail service: {e}")
    def _cleanup_token_file(self):
        """Safely remove token file."""
        try:
            if os.path.exists(self.TOKEN_FILE):
                os.remove(self.TOKEN_FILE)
                logger.info("Removed invalid token file")
        except Exception as e:
            logger.warning(f"Failed to remove token file: {e}")
    def _save_credentials(self, creds):
        """Save credentials to token file."""
        try:
            with open(self.TOKEN_FILE, 'w', encoding='utf-8') as f:
                f.write(creds.to_json())
            logger.debug("Credentials saved successfully")
        except Exception as e:
            logger.error(f"Failed to save credentials: {e}")
    async def get_unread_emails(self) -> List[Dict]:
        """Get unread emails with retry logic."""
        if self.config.DRY_RUN:
            logger.info("DRY-RUN: Simulating unread emails")
            return [
                {'id': 'mock_email_1', 'threadId': 'thread_1'},
                {'id': 'mock_email_2', 'threadId': 'thread_2'}
            ]
        backoff = ExponentialBackoff(initial_delay=1, max_delay=60)
        max_attempts = 5
        for attempt in range(max_attempts):
            try:
                # Build search query
                query_parts = ['is:unread', '-in:trash', '-in:spam']
                if self.config.TARGET_SENDER:
                    query_parts.append(f'from:{self.config.TARGET_SENDER}')
                if self.config.TARGET_SUBJECT:
                    query_parts.append(f'subject:"{self.config.TARGET_SUBJECT}"')
                query = ' '.join(query_parts)
                logger.debug(f"Gmail query: {query}")
                # Execute search
                request = self.service.users().messages().list(userId='me', q=query, maxResults=50)
                results = await asyncio.to_thread(request.execute)
                messages = results.get('messages', [])
                logger.info(f"Found {len(messages)} unread emails")
                return messages
            except HttpError as e:
                if e.resp.status == 429:  # Rate limit
                    delay = backoff.get_next_delay()
                    logger.warning(f"Rate limit hit (attempt {attempt + 1}/{max_attempts}). Retrying in {delay:.1f}s")
                    await asyncio.sleep(delay)
                    continue
                elif e.resp.status in [401, 403]:  # Auth errors
                    logger.error(f"Authentication error: {e}")
                    raise NetworkError(f"Gmail authentication failed: {e}")
                else:
                    logger.error(f"Gmail API error: {e}")
                    raise NetworkError(f"Gmail API error: {e}")
            except Exception as e:
                logger.error(f"Unexpected error fetching emails (attempt {attempt + 1}): {e}")
                if attempt == max_attempts - 1:
                    raise NetworkError(f"Failed to fetch emails after {max_attempts} attempts: {e}")
                await asyncio.sleep(backoff.get_next_delay())
        raise NetworkError("Max retry attempts exceeded")
    async def get_email(self, message_id: str) -> Dict:
        """Get email details with error handling."""
        if self.config.DRY_RUN:
            logger.info(f"DRY-RUN: Simulating email fetch for {message_id}")
            return {
                'id': message_id,
                'payload': {
                    'headers': [
                        {'name': 'Subject', 'value': 'Test Email Subject'},
                        {'name': 'From', 'value': 'test@example.com'},
                        {'name': 'Date', 'value': 'Mon, 1 Jan 2024 12:00:00 +0000'}
                    ],
                    'parts': [
                        {
                            'filename': 'test_document.pdf',
                            'body': {'attachmentId': 'mock_attachment_id'},
                            'mimeType': 'application/pdf'
                        }
                    ]
                }
            }
        try:
            request = self.service.users().messages().get(userId='me', id=message_id, format='full')
            email_data = await asyncio.to_thread(request.execute)
            logger.debug(f"Retrieved email {message_id}")
            return email_data
        except HttpError as e:
            if e.resp.status == 404:
                logger.warning(f"Email {message_id} not found (may have been deleted)")
                return {}
            else:
                logger.error(f"Failed to fetch email {message_id}: {e}")
                raise NetworkError(f"Failed to fetch email: {e}")
        except Exception as e:
            logger.error(f"Unexpected error fetching email {message_id}: {e}")
            raise NetworkError(f"Unexpected error: {e}")
    async def trash_email(self, message_id: str):
        """Move email to trash."""
        if self.config.DRY_RUN:
            logger.info(f"DRY-RUN: Would trash email {message_id}")
            return
        try:
            request = self.service.users().messages().trash(userId='me', id=message_id)
            await asyncio.to_thread(request.execute)
            logger.info(f"Moved email {message_id} to trash")
        except HttpError as e:
            if e.resp.status == 404:
                logger.warning(f"Email {message_id} not found (may already be deleted)")
            else:
                logger.error(f"Failed to trash email {message_id}: {e}")
                raise NetworkError(f"Failed to trash email: {e}")
        except Exception as e:
            logger.error(f"Unexpected error trashing email {message_id}: {e}")
            raise NetworkError(f"Unexpected error: {e}")

# --- END OF gmail_client.py ---

# --- START OF launch_fixer.py ---
#!/usr/bin/env python3
"""
Gmail Auto Printer - Launch Fixer
Quick fix script to ensure the application is launch-ready.
"""
import sys
import os
import shutil
from pathlib import Path

def fix_malware_scanner():
    """Fix the malware scanner syntax error."""
    malware_file = Path("malware_scanner.py")
    
    if not malware_file.exists():
        print("❌ malware_scanner.py not found")
        return False
    
    try:
        # Read the file
        content = malware_file.read_text(encoding='utf-8')
        
        # Find and fix the syntax error
        if "PRINTER_NAME=Microsoft Print to PDF" in content:
            print("🔧 Fixing syntax error in malware_scanner.py...")
            
            # Remove the erroneous configuration section
            lines = content.split('\n')
            fixed_lines = []
            skip_section = False
            
            for line in lines:
                if "# === .env.template ===" in line:
                    skip_section = True
                    break
                if not skip_section:
                    fixed_lines.append(line)
            
            # Write the fixed content
            fixed_content = '\n'.join(fixed_lines)
            malware_file.write_text(fixed_content, encoding='utf-8')
            print("✅ Syntax error fixed")
            return True
        else:
            print("✅ No syntax error found")
            return True
            
    except Exception as e:
        print(f"❌ Error fixing malware_scanner.py: {e}")
        return False

def check_env_file():
    """Check if .env file exists."""
    env_file = Path(".env")
    template_file = Path(".env.template")
    
    if not env_file.exists():
        if template_file.exists():
            print("🔧 Creating .env from template...")
            try:
                shutil.copy(template_file, env_file)
                print("✅ .env file created")
                print("⚠️  Please edit .env with your settings")
                return True
            except Exception as e:
                print(f"❌ Error creating .env: {e}")
                return False
        else:
            print("❌ .env.template not found")
            return False
    else:
        print("✅ .env file exists")
        return True

def check_credentials():
    """Check if credentials.json exists."""
    creds_file = Path("credentials.json")
    
    if not creds_file.exists():
        print("❌ credentials.json not found")
        print("   Download from Google Cloud Console:")
        print("   https://console.cloud.google.com/")
        return False
    else:
        print("✅ credentials.json exists")
        return True

def check_directories():
    """Create required directories."""
    dirs = ["logs", "attachments", "malware_scan_temp"]
    
    for dir_name in dirs:
        dir_path = Path(dir_name)
        try:
            dir_path.mkdir(exist_ok=True)
            print(f"✅ Directory {dir_name} ready")
        except Exception as e:
            print(f"❌ Error creating {dir_name}: {e}")
            return False
    
    return True

def main():
    """Main launch fixer."""
    print("=" * 60)
    print("🔧 Gmail Auto Printer - Launch Fixer")
    print("=" * 60)
    
    fixes = [
        ("Malware Scanner", fix_malware_scanner),
        ("Environment File", check_env_file),
        ("Credentials", check_credentials),
        ("Directories", check_directories),
    ]
    
    all_passed = True
    
    for fix_name, fix_func in fixes:
        print(f"\n🔍 Checking {fix_name}...")
        try:
            if not fix_func():
                all_passed = False
        except Exception as e:
            print(f"❌ Error in {fix_name}: {e}")
            all_passed = False
    
    print("\n" + "=" * 60)
    if all_passed:
        print("🎉 All fixes applied! Ready to launch.")
        print("\nTry running:")
        print("   python main.py --dry-run --once --debug")
    else:
        print("⚠️  Some issues remain. Check the output above.")
    print("=" * 60)

if __name__ == "__main__":
    main()
# --- END OF launch_fixer.py ---

# --- START OF launcher.py ---
#!/usr/bin/env python3
"""
Gmail Auto Printer Launcher
Safe wrapper that handles Python version compatibility and missing dependencies.
"""
import sys
import os
import subprocess
from pathlib import Path

def check_python_version():
    """Check if Python version is compatible."""
    version = sys.version_info
    if version < (3, 8):
        print(f"❌ Error: Python {version.major}.{version.minor} is too old.")
        print("   Gmail Auto Printer requires Python 3.8 or newer.")
        print("   Please upgrade Python and try again.")
        return False
    
    if version >= (3, 13):
        print(f"⚠️  Warning: Python {version.major}.{version.minor} detected.")
        print("   Some features (DOCX conversion) may have compatibility issues.")
        print("   Consider using Python 3.11 or 3.12 for best compatibility.")
    
    return True

def check_required_files():
    """Check if required files exist."""
    required_files = [
        'main.py',
        'config.py',
        'gmail_client.py',
        'printer_manager.py',
        'attachment_handler.py',
    ]
    
    missing_files = []
    for file in required_files:
        if not Path(file).exists():
            missing_files.append(file)
    
    if missing_files:
        print("❌ Error: Missing required files:")
        for file in missing_files:
            print(f"   - {file}")
        return False
    
    return True

def check_credentials():
    """Check if credentials are configured."""
    if not Path('.env').exists():
        print("❌ Error: .env file not found.")
        print("   Please copy .env.template to .env and configure your settings.")
        return False
    
    if not Path('credentials.json').exists():
        print("❌ Error: credentials.json not found.")
        print("   Please download your Gmail API credentials from Google Cloud Console.")
        return False
    
    return True

def install_requirements():
    """Install required packages."""
    try:
        print("📦 Installing required packages...")
        result = subprocess.run([
            sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'
        ], check=True, capture_output=True, text=True)
        print("✅ Requirements installed successfully.")
        return True
    except subprocess.CalledProcessError as e:
        print("❌ Error installing requirements:")
        print(e.stderr)
        print("\nTry running manually:")
        print(f"   {sys.executable} -m pip install -r requirements.txt")
        return False
    except FileNotFoundError:
        print("❌ Error: pip not found. Please install pip first.")
        return False

def run_application(args):
    """Run the main application."""
    try:
        cmd = [sys.executable, 'main.py'] + args
        print(f"🚀 Starting Gmail Auto Printer...")
        print(f"   Command: {' '.join(cmd)}")
        
        # Run the application
        result = subprocess.run(cmd)
        return result.returncode
    
    except KeyboardInterrupt:
        print("\n⏹️  Application stopped by user.")
        return 0
    except Exception as e:
        print(f"❌ Error running application: {e}")
        return 1

def main():
    """Main launcher function."""
    print("=" * 50)
    print("🖨️  Gmail Auto Printer Launcher v2.0.0")
    print("=" * 50)
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Check required files
    if not check_required_files():
        sys.exit(1)
    
    # Check credentials
    if not check_credentials():
        sys.exit(1)
    
    # Install requirements if needed
    if Path('requirements.txt').exists():
        try:
            import google.auth
            print("✅ Requirements already installed.")
        except ImportError:
            if not install_requirements():
                sys.exit(1)
    
    # Run application
    args = sys.argv[1:]  # Pass all command line arguments
    exit_code = run_application(args)
    
    print("=" * 50)
    if exit_code == 0:
        print("✅ Gmail Auto Printer completed successfully.")
    else:
        print(f"❌ Gmail Auto Printer exited with code {exit_code}.")
    print("=" * 50)
    
    sys.exit(exit_code)

if __name__ == '__main__':
    main()
# --- END OF launcher.py ---

# --- START OF logger_config.py ---
"""
Logging configuration for production use.
"""
import logging
import logging.handlers
import sys
from pathlib import Path
def setup_logging(log_level: str = 'INFO') -> None:
    """
    Setup production-ready logging with file rotation.
    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
    """
    log_level = log_level.upper()
    numeric_level = getattr(logging, log_level, logging.INFO)
    # Create logs directory
    logs_dir = Path('logs')
    logs_dir.mkdir(exist_ok=True)
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    # Root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(numeric_level)
    # Clear existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(numeric_level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    # File handler with rotation
    file_handler = logging.handlers.RotatingFileHandler(
        logs_dir / 'gmail_printer.log',
        maxBytes=10*1024*1024,  # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    file_handler.setLevel(numeric_level)
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)
    # Error file handler
    error_handler = logging.handlers.RotatingFileHandler(
        logs_dir / 'gmail_printer_errors.log',
        maxBytes=5*1024*1024,  # 5MB
        backupCount=3,
        encoding='utf-8'
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(formatter)
    root_logger.addHandler(error_handler)
    # Reduce noise from third-party libraries
    logging.getLogger('googleapiclient.discovery_cache').setLevel(logging.WARNING)
    logging.getLogger('google.auth.transport.requests').setLevel(logging.WARNING)
    logging.getLogger('urllib3.connectionpool').setLevel(logging.WARNING)

# --- END OF logger_config.py ---

# --- START OF main.py ---
#!/usr/bin/env python3
"""
Gmail Auto Printer - Production Ready
Main application entry point with complete error handling and production features.
"""
import asyncio
import argparse
import logging
import sys
import os
import signal
import traceback
import time
from pathlib import Path
import shutil

# Core modules
from config import Config, ConfigValidationError
from gmail_client import GmailClient
from attachment_handler import AttachmentHandler
from printer_manager import PrinterManager
from auto_updater import AutoUpdater
from error_notifier import ErrorNotifier
from environment_checker import EnvironmentChecker
from logger_config import setup_logging
from utils import SystemUtils
from constants import APP_VERSION, APP_NAME

logger = logging.getLogger(__name__)

class GmailAutoPrinter:
    """Main application class for Gmail Auto Printer."""
    
    def __init__(self, config: Config, no_updates: bool):
        self.config = config
        self.no_updates = no_updates
        self.running = True
        self.error_notifier = None
        self.auto_updater = None
        self.gmail_client = None
        self.attachment_handler = None
        self.printer_manager = None

    async def initialize(self):
        """Initialize all components."""
        try:
            logger.info("Initializing Gmail Auto Printer components...")
            
            # Check for staged update
            staged_dir = Path("staged_update")
            if staged_dir.exists():
                logger.info("Applying staged update")
                backup_dir = Path(tempfile.mkdtemp(prefix="gmail_printer_backup_"))
                shutil.copytree(Path.cwd(), backup_dir / "previous", ignore=lambda _, names: list(AutoUpdater.PROTECTED_FILES))
                shutil.rmtree(Path.cwd())
                shutil.move(staged_dir, Path.cwd())

            # Error notifier (initialize first for error reporting)
            self.error_notifier = ErrorNotifier(self.config)
            logger.debug("Error notifier initialized")
            
            # Auto updater
            if self.config.ENABLE_AUTO_UPDATE and not self.no_updates:
                self.auto_updater = AutoUpdater(self.config, self.error_notifier)
                logger.debug("Auto updater initialized")
                try:
                    await asyncio.wait_for(self.auto_updater.check_for_updates(), timeout=self.config.get('UPDATE_CHECK_TIMEOUT_SECONDS', 30))
                except asyncio.TimeoutError:
                    logger.warning("Update check timed out, continuing with startup")
                    await self.error_notifier.send_error_notification(
                        "Auto Update Timeout",
                        f"Update check timed out after {self.config.get('UPDATE_CHECK_TIMEOUT_SECONDS', 30)} seconds",
                        traceback.format_exc(),
                        error_type="auto_update"
                    )
                except Exception as e:
                    logger.warning(f"Update check failed: {e}")
                    await self.error_notifier.send_error_notification(
                        "Auto Update Failure",
                        f"Failed to check for updates: {str(e)}",
                        traceback.format_exc(),
                        error_type="auto_update"
                    )
            
            # Gmail client
            self.gmail_client = GmailClient(self.config)
            logger.debug("Gmail client initialized")
            
            # Printer manager
            self.printer_manager = PrinterManager(self.config)
            logger.debug("Printer manager initialized")
            
            # Attachment handler
            self.attachment_handler = AttachmentHandler(
                self.config, 
                self.gmail_client, 
                self.printer_manager,
                self.error_notifier
            )
            logger.debug("Attachment handler initialized")
            
            logger.info("✅ All components initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize components: {e}")
            if self.error_notifier:
                await self.error_notifier.send_error_notification(
                    "System Initialization Failed",
                    str(e),
                    traceback.format_exc(),
                    error_type="initialization"
                )
            raise

    async def process_emails(self):
        """Main email processing loop with timeout protection."""
        processed_count = 0
        error_count = 0
        last_error_notification = 0
        last_update_check = time.time()
        ERROR_NOTIFICATION_COOLDOWN = 1800  # 30 minutes
        OPERATION_TIMEOUT = 300  # 5 minutes per operation

        logger.info("🚀 Starting email processing loop...")

        while self.running:
            try:
                # Periodic update check
                if self.config.ENABLE_AUTO_UPDATE and not self.no_updates:
                    if time.time() - last_update_check > self.config.UPDATE_CHECK_INTERVAL_HOURS * 3600:
                        try:
                            await asyncio.wait_for(self.auto_updater.check_for_updates(), timeout=self.config.get('UPDATE_CHECK_TIMEOUT_SECONDS', 30))
                            last_update_check = time.time()
                        except asyncio.TimeoutError:
                            logger.warning("Periodic update check timed out")
                            await self.error_notifier.send_error_notification(
                                "Periodic Update Timeout",
                                "Periodic update check timed out",
                                traceback.format_exc(),
                                error_type="auto_update"
                            )

                # Add timeout to prevent getting stuck
                try:
                    messages = await asyncio.wait_for(
                        self.gmail_client.get_unread_emails(), 
                        timeout=OPERATION_TIMEOUT
                    )
                except asyncio.TimeoutError:
                    logger.error(f"⏰ Gmail API timeout after {OPERATION_TIMEOUT} seconds")
                    if self.error_notifier:
                        await self.error_notifier.send_error_notification(
                            "Gmail API Timeout",
                            f"Gmail API call timed out after {OPERATION_TIMEOUT} seconds",
                            traceback.format_exc(),
                            error_type="gmail_timeout"
                        )
                    if self.config.RUN_ONCE:
                        logger.info("Run-once mode: Timeout occurred, exiting")
                        break
                    await asyncio.sleep(self.config.POLL_INTERVAL_SECONDS)
                    continue
                
                if not messages:
                    logger.debug("No unread emails found")
                    if self.config.RUN_ONCE:
                        logger.info("Run-once mode: No emails to process, exiting")
                        break
                    
                    sleep_time = min(self.config.POLL_INTERVAL_SECONDS, 10) if self.config.RUN_ONCE else self.config.POLL_INTERVAL_SECONDS
                    logger.debug(f"Sleeping for {sleep_time} seconds before next poll")
                    await asyncio.sleep(sleep_time)
                    continue

                logger.info(f"📧 Found {len(messages)} unread emails to process")

                processed_ids = SystemUtils.load_processed_ids(self.config.PROCESSED_IDS_FILE)

                for i, message in enumerate(messages, 1):
                    if not self.running:
                        break

                    message_id = message['id']
                    logger.info(f"Processing email {i}/{len(messages)}: {message_id}")

                    if message_id in processed_ids:
                        logger.debug(f"⏭️  Skipping already processed email: {message_id}")
                        continue

                    try:
                        try:
                            email_data = await asyncio.wait_for(
                                self.gmail_client.get_email(message_id),
                                timeout=60
                            )
                        except asyncio.TimeoutError:
                            logger.error(f"⏰ Email fetch timeout for {message_id}")
                            error_count += 1
                            continue
                        
                        if not email_data:
                            logger.warning(f"No email data received for {message_id}")
                            error_count += 1
                            continue
                        
                        try:
                            attachment_count = await asyncio.wait_for(
                                self.attachment_handler.download_attachments(message_id, email_data),
                                timeout=180
                            )
                        except asyncio.TimeoutError:
                            logger.error(f"⏰ Attachment processing timeout for {message_id}")
                            error_count += 1
                            continue

                        if attachment_count > 0:
                            logger.info(f"✅ Successfully processed {attachment_count} attachments from email {message_id}")
                            processed_count += attachment_count
                        else:
                            logger.info(f"📎 No valid attachments found in email {message_id}")

                        try:
                            if not self.config.DRY_RUN:
                                await asyncio.wait_for(
                                    self.gmail_client.trash_email(message_id),
                                    timeout=30
                                )
                                SystemUtils.save_processed_id(self.config.PROCESSED_IDS_FILE, message_id)
                                logger.debug(f"Email {message_id} moved to trash and marked as processed")
                            else:
                                logger.info(f"DRY-RUN: Would trash email {message_id}")
                        except asyncio.TimeoutError:
                            logger.error(f"⏰ Email trash timeout for {message_id}")
                            if not self.config.DRY_RUN:
                                SystemUtils.save_processed_id(self.config.PROCESSED_IDS_FILE, message_id)

                    except Exception as e:
                        error_count += 1
                        logger.error(f"❌ Failed to process email {message_id}: {e}")
                        current_time = time.time()
                        if current_time - last_error_notification > ERROR_NOTIFICATION_COOLDOWN:
                            if self.error_notifier:
                                await self.error_notifier.send_error_notification(
                                    f"Email Processing Error (ID: {message_id})",
                                    str(e),
                                    traceback.format_exc(),
                                    error_type="email_processing"
                                )
                            last_error_notification = current_time

                stats = self.attachment_handler.get_stats()
                error_count += stats.get('validation_failures', 0) + stats.get('print_failures', 0)

                if self.config.RUN_ONCE:
                    logger.info("Run-once mode: Processing complete, exiting")
                    break

                logger.debug(f"Sleeping for {self.config.POLL_INTERVAL_SECONDS} seconds before next poll")
                await asyncio.sleep(self.config.POLL_INTERVAL_SECONDS)

            except KeyboardInterrupt:
                logger.info("⏹️  Received interrupt signal, shutting down...")
                self.running = False
                break

            except Exception as e:
                error_count += 1
                logger.error(f"❌ Error in main processing loop: {e}")
                logger.error(traceback.format_exc())
                
                if self.error_notifier:
                    await self.error_notifier.send_error_notification(
                        "Critical Processing Loop Error",
                        str(e),
                        traceback.format_exc(),
                        error_type="processing_loop"
                    )

                if not self.config.RUN_ONCE:
                    logger.info("Waiting 30 seconds before retry...")
                    await asyncio.sleep(30)
                else:
                    break

        logger.info(f"📊 Processing complete. Processed: {processed_count}, Errors: {error_count}")

    async def cleanup(self):
        """Cleanup resources."""
        try:
            logger.info("🧹 Cleaning up resources...")
            if self.printer_manager:
                await self.printer_manager.cleanup()
            if self.attachment_handler:
                await self.attachment_handler.cleanup()
            if self.auto_updater:
                self.auto_updater._cleanup_old_temp_dirs()
            logger.info("✅ Cleanup completed successfully")
        except Exception as e:
            logger.error(f"❌ Error during cleanup: {e}")
            if self.error_notifier:
                await self.error_notifier.send_error_notification(
                    "Cleanup Error",
                    str(e),
                    traceback.format_exc(),
                    error_type="cleanup"
                )

    def setup_signal_handlers(self):
        """Setup signal handlers for graceful shutdown."""
        def signal_handler(signum, frame):
            logger.info(f"Received signal {signum}, initiating shutdown...")
            self.running = False
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)


async def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description=f"{APP_NAME} - Production Ready")
    parser.add_argument("--dry-run", action="store_true", help="Simulate actions without making changes")
    parser.add_argument("--once", action="store_true", help="Run once and exit")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    parser.add_argument("--skip-env-check", action="store_true", help="Skip environment validation")
    parser.add_argument("--no-updates", action="store_true", help="Disable auto-updates")
    parser.add_argument("--force-update", action="store_true", help="Force check and apply updates")
    parser.add_argument("--version", action="version", version=f"{APP_NAME} v{APP_VERSION}")
    
    args = parser.parse_args()
    app = None

    try:
        log_level = 'DEBUG' if args.debug else 'INFO'
        setup_logging(log_level=log_level)
        
        logger.info("=" * 60)
        logger.info(f"🚀 {APP_NAME} v{APP_VERSION} Starting")
        logger.info("=" * 60)
        logger.info(f"Python version: {sys.version}")
        logger.info(f"Arguments: {vars(args)}")

        try:
            config = Config(
                dry_run=args.dry_run,
                run_once=args.once
            )
            logger.info("✅ Configuration loaded successfully")
            
            config_summary = config.get_summary()
            logger.info("📋 Configuration Summary:")
            for key, value in config_summary.items():
                logger.info(f"   {key}: {value}")
            
        except ConfigValidationError as e:
            logger.error(f"❌ Configuration validation failed:")
            for line in str(e).split('\n'):
                if line.strip():
                    logger.error(f"   {line}")
            sys.exit(1)

        error_notifier = ErrorNotifier(config)

        if not args.skip_env_check:
            logger.info("🔍 Running environment checks...")
            env_checker = EnvironmentChecker(config)
            if not await env_checker.check_all():
                logger.error("❌ Environment check failed. Use --skip-env-check to bypass.")
                await error_notifier.send_error_notification(
                    "Environment Check Failure",
                    "Environment check failed. Check logs for details.",
                    traceback.format_exc(),
                    error_type="environment_check"
                )
                sys.exit(1)
            logger.info("✅ Environment checks passed")

        app = GmailAutoPrinter(config, args.no_updates)
        app.setup_signal_handlers()
        
        try:
            await asyncio.wait_for(app.initialize(), timeout=120)
        except asyncio.TimeoutError:
            logger.error("⏰ Application initialization timed out")
            sys.exit(1)
        
        if args.force_update and not args.no_updates:
            logger.info("Forcing update check...")
            await app.auto_updater.check_for_updates()
        
        if config.RUN_ONCE:
            try:
                await asyncio.wait_for(app.process_emails(), timeout=600)
            except asyncio.TimeoutError:
                logger.error("⏰ Email processing timed out in run-once mode")
                sys.exit(1)
        else:
            await app.process_emails()
        
        logger.info("=" * 60)
        logger.info(f"✅ {APP_NAME} Shutdown Complete")
        logger.info("=" * 60)

    except KeyboardInterrupt:
        logger.info("⏹️  Application interrupted by user")
        sys.exit(0)

    except Exception as e:
        logger.error(f"💥 Fatal application error: {e}")
        logger.error(traceback.format_exc())
        
        try:
            if app and app.error_notifier:
                await app.error_notifier.send_error_notification(
                    "Fatal Application Error",
                    str(e),
                    traceback.format_exc(),
                    error_type="fatal"
                )
            elif 'error_notifier' in locals():
                await error_notifier.send_error_notification(
                    "Fatal Application Error",
                    str(e),
                    traceback.format_exc(),
                    error_type="fatal"
                )
        except:
            pass
        
        sys.exit(1)

    finally:
        if app:
            await app.cleanup()


if __name__ == '__main__':
    if hasattr(sys, '_MEIPASS'):
        os.chdir(sys._MEIPASS)
    else:
        os.chdir(Path(__file__).parent)
    
    if sys.platform.startswith('win'):
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    
    asyncio.run(main())
# --- END OF main.py ---

# --- START OF malware_scanner.py ---
"""
Malware scanning module using Windows Defender.
"""
import asyncio
import logging
import subprocess
import traceback
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

class MalwareScanner:
    """Handles malware scanning with Windows Defender."""
    
    def __init__(self, config, error_notifier):
        self.config = config
        self.error_notifier = error_notifier
        self.validation_failures = 0

    async def scan_file(self, file_path: Path) -> bool:
        """Scan a file for malware using Windows Defender."""
        if not self.config.ENABLE_MALWARE_SCAN or self.config.DISABLE_MALWARE_SCAN:
            logger.debug("Malware scanning disabled")
            return True

        # Check file size
        try:
            file_size = file_path.stat().st_size
            max_size_bytes = self.config.MAX_SCAN_FILE_SIZE_MB * 1024 * 1024
            
            if file_size > max_size_bytes:
                logger.warning(f"File {file_path} exceeds max scan size {self.config.MAX_SCAN_FILE_SIZE_MB}MB")
                self.validation_failures += 1
                await self.error_notifier.send_error_notification(
                    title="Malware Scan Failure",
                    error_message=f"File {file_path.name} exceeds max scan size {self.config.MAX_SCAN_FILE_SIZE_MB}MB",
                    stack_trace="",
                    error_type="validation_failure"
                )
                return False
        except Exception as e:
            logger.error(f"Error checking file size for {file_path}: {e}")
            return False

        try:
            # Use Windows Defender PowerShell command
            cmd = [
                "powershell",
                "-Command",
                f"Start-MpScan -ScanType CustomScan -ScanPath '{file_path}'"
            ]
            
            # Create subprocess
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            # Wait for completion with timeout
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=getattr(self.config, 'TIMEOUT_DEFENDER_SCAN_SECONDS', 30)
                )
            except asyncio.TimeoutError:
                logger.warning(f"Windows Defender scan timed out for {file_path.name}")
                try:
                    process.terminate()
                    await asyncio.wait_for(process.wait(), timeout=5)
                except:
                    process.kill()
                self._handle_scan_failure(file_path, "Scan timeout")
                return False
            
            # Check return code
            if process.returncode == 0:
                logger.debug(f"Windows Defender scan clean: {file_path.name}")
                return True
            else:
                error_msg = stderr.decode('utf-8', errors='ignore').strip() if stderr else f"Return code: {process.returncode}"
                logger.warning(f"Windows Defender scan failed for {file_path.name}: {error_msg}")
                self._handle_scan_failure(file_path, error_msg)
                return False

        except subprocess.SubprocessError as e:
            logger.warning(f"Windows Defender subprocess error for {file_path.name}: {str(e)}")
            self._handle_scan_failure(file_path, f"Subprocess error: {str(e)}")
            return False
            
        except Exception as e:
            logger.warning(f"Windows Defender scan failed: {str(e)}")
            # Fall back to basic validation instead of failing completely
            logger.warning("No malware scanner available, performing basic validation")
            return self._basic_file_validation(file_path)

    def _handle_scan_failure(self, file_path: Path, error_msg: str):
        """Handle scan failure with error notification."""
        self.validation_failures += 1
        asyncio.create_task(self.error_notifier.send_error_notification(
            title="Malware Scan Failure",
            error_message=f"Windows Defender scan failed for {file_path.name}: {error_msg}",
            stack_trace="",
            error_type="validation_failure"
        ))

    def _basic_file_validation(self, file_path: Path) -> bool:
        """Perform basic file validation when malware scanner is unavailable."""
        try:
            # Check if file exists and is readable
            if not file_path.exists():
                logger.error(f"File does not exist: {file_path}")
                return False
            
            if not file_path.is_file():
                logger.error(f"Path is not a file: {file_path}")
                return False
                
            # Basic size check
            if file_path.stat().st_size == 0:
                logger.warning(f"File is empty: {file_path}")
                return False
                
            # Check for suspicious file patterns (basic heuristics)
            with open(file_path, 'rb') as f:
                header = f.read(1024)  # Read first 1KB
                
                # Check for some basic malware signatures (very basic)
                suspicious_patterns = [
                    b'This program cannot be run in DOS mode',
                    b'UPX!',  # UPX packer
                    b'MSDOS',
                    b'\x4d\x5a\x90\x00'  # PE header start
                ]
                
                for pattern in suspicious_patterns:
                    if pattern in header:
                        # Only flag executables, not documents
                        if file_path.suffix.lower() not in ['.pdf', '.docx', '.doc', '.txt', '.jpg', '.jpeg', '.png']:
                            logger.warning(f"Suspicious pattern found in {file_path.name}")
                            return False
            
            logger.debug(f"Basic validation passed for {file_path.name}")
            return True
            
        except Exception as e:
            logger.error(f"Error in basic file validation for {file_path}: {e}")
            return False

    async def is_available(self) -> bool:
        """Check if Windows Defender is available."""
        try:
            cmd = ["powershell", "-Command", "Get-MpComputerStatus"]
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=10)
            return process.returncode == 0
            
        except Exception:
            return False

    def get_stats(self) -> dict:
        """Return scanning statistics."""
        return {
            "validation_failures": self.validation_failures,
            "malware_detections": 0  # Could be enhanced to track actual detections
        }
# --- END OF malware_scanner.py ---

# --- START OF printer_manager.py ---
"""
Production-ready printer manager with improved detection and cross-platform support.
Fixed timeout handling and print verification.
FIXED: Multiple copies issue with SumatraPDF
"""
import os
import logging
import asyncio
import subprocess
import platform
import shutil
import time
from pathlib import Path
from typing import Optional, Dict, List
from config import Config
from docx_to_pdf_converter import DocxToPDFConverter
from exceptions import PrinterError
from utils import SystemUtils

logger = logging.getLogger(__name__)

class PrinterManager:
    """Cross-platform printer manager with comprehensive functionality."""
    
    def __init__(self, config: Config):
        """Initialize printer manager with configuration."""
        self.config = config
        self.platform = platform.system()
        self.duplex_supported = False
        self.printer_available = False
        self.docx_converter = None
        
        # Initialize print statistics
        self.print_stats = {
            'total_prints': 0,
            'successful_prints': 0,
            'failed_prints': 0,
            'retry_attempts': 0
        }
        
        # Initialize DocX converter if needed
        try:
            self.docx_converter = DocxToPDFConverter()
            logger.debug("DocX to PDF converter initialized")
        except Exception as e:
            logger.warning(f"Failed to initialize DocX converter: {e}")
            self.docx_converter = None
        
        # Check printer availability and duplex support
        asyncio.create_task(self._initialize_printer_info())

    async def _initialize_printer_info(self):
        """Initialize printer information and capabilities."""
        try:
            self.printer_available = await self._check_printer_availability()
            if self.printer_available:
                self.duplex_supported = await self._check_duplex_support()
                logger.info(f"Printer '{self.config.PRINTER_NAME}' available, duplex: {self.duplex_supported}")
            else:
                logger.warning(f"Printer '{self.config.PRINTER_NAME}' not available")
        except Exception as e:
            logger.error(f"Failed to initialize printer info: {e}")
            self.printer_available = False
            self.duplex_supported = False

    async def _check_printer_availability(self) -> bool:
        """Check if the configured printer is available."""
        try:
            if self.platform == "Windows":
                cmd = ["powershell", "-Command", "Get-Printer | Select-Object Name, PrinterStatus"]
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
                )
                
                stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=10)
                
                if process.returncode == 0:
                    output = stdout.decode('utf-8', errors='ignore')
                    logger.debug(f"PowerShell found {len(output.splitlines())} printers")
                    return self.config.PRINTER_NAME in output
                else:
                    logger.warning(f"Failed to check printer availability: {stderr.decode()}")
                    return False
            else:
                cmd = ["lpstat", "-p"]
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                
                stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=10)
                
                if process.returncode == 0:
                    output = stdout.decode('utf-8', errors='ignore')
                    return self.config.PRINTER_NAME in output
                else:
                    logger.warning(f"Failed to check printer availability: {stderr.decode()}")
                    return False
                
        except Exception as e:
            logger.error(f"Error checking printer availability: {e}")
            return False

    async def _check_duplex_support(self) -> bool:
        """Check if the printer supports duplex printing."""
        try:
            if self.platform == "Windows":
                cmd = [
                    "powershell", "-Command",
                    f"Get-PrinterProperty -PrinterName '{self.config.PRINTER_NAME}' | Where-Object {{$_.PropertyName -eq 'Config:DuplexUnit'}}"
                ]
                
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
                )
                
                stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=10)
                
                if process.returncode == 0:
                    output = stdout.decode('utf-8', errors='ignore')
                    return 'True' in output or 'Installed' in output
                    
            return False  # Default to no duplex support for non-Windows or on error
            
        except Exception as e:
            logger.debug(f"Could not determine duplex support: {e}")
            return False

    async def print_file(self, file_path: Path, copies: int = 1, duplex: bool = False) -> bool:
        """Print a file with the specified options."""
        self.print_stats['total_prints'] += 1
        
        try:
            if not file_path.exists():
                logger.error(f"File not found: {file_path}")
                self.print_stats['failed_prints'] += 1
                return False
            
            if not self.printer_available:
                logger.error(f"Printer '{self.config.PRINTER_NAME}' not available")
                self.print_stats['failed_prints'] += 1
                return False
            
            # Limit copies to reasonable number
            copies = max(1, min(copies, 10))
            
            # Disable duplex if not supported
            if duplex and not self.duplex_supported:
                logger.warning("Duplex requested but not supported, printing single-sided")
                duplex = False
            
            file_ext = file_path.suffix.lower()
            
            # Handle different file types
            if file_ext == '.pdf':
                success = await self._print_pdf_with_sumatra(file_path, copies, duplex)
            elif file_ext in ['.docx', '.doc']:
                success = await self._print_docx(file_path, copies, duplex)
            elif file_ext in ['.txt', '.log']:
                success = await self._print_text_file(file_path, copies, duplex)
            elif file_ext in ['.jpg', '.jpeg', '.png']:
                success = await self._print_image(file_path, copies, duplex)
            else:
                logger.error(f"Unsupported file type: {file_ext}")
                self.print_stats['failed_prints'] += 1
                return False
            
            if success:
                self.print_stats['successful_prints'] += 1
                logger.info(f"Successfully printed: {file_path.name} ({copies} copies, duplex={duplex})")
            else:
                self.print_stats['failed_prints'] += 1
                logger.error(f"Failed to print: {file_path.name}")
            
            return success
            
        except Exception as e:
            logger.error(f"Error printing file {file_path}: {e}")
            self.print_stats['failed_prints'] += 1
            return False

    async def _print_docx(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """Print DOCX file by converting to PDF first."""
        if not self.docx_converter:
            logger.error("DocX converter not available")
            return False
        
        try:
            # Create a temporary PDF path
            pdf_path = file_path.parent / f"{file_path.stem}_temp.pdf"
            
            # Convert to PDF
            success = await self.docx_converter.convert_to_pdf(file_path, pdf_path)
            if not success or not pdf_path.exists():
                logger.error(f"Failed to convert {file_path.name} to PDF")
                return False
            
            # Print the PDF
            print_success = await self._print_pdf_with_sumatra(pdf_path, copies, duplex)
            
            # Clean up temporary PDF
            SystemUtils.cleanup_file(pdf_path)
            
            return print_success
            
        except Exception as e:
            logger.error(f"Error printing DOCX file {file_path}: {e}")
            return False

    async def _print_text_file(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """Print text file using system print command."""
        try:
            if self.platform == "Windows":
                # Use notepad to print text files on Windows
                cmd = ["notepad", "/p", str(file_path)]
            else:
                # Use lp command on Unix-like systems
                cmd = ["lp", "-d", self.config.PRINTER_NAME, "-n", str(copies)]
                if duplex:
                    cmd.extend(["-o", "sides=two-sided-long-edge"])
                cmd.append(str(file_path))
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=getattr(self.config, 'TIMEOUT_LP_PRINT_SECONDS', 30)
            )
            
            return process.returncode == 0
            
        except Exception as e:
            logger.error(f"Error printing text file {file_path}: {e}")
            return False

    async def _print_image(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """Print image file using system default image viewer."""
        try:
            if self.platform == "Windows":
                # Use Windows Photo Viewer or default image viewer
                cmd = ["rundll32.exe", "shimgvw.dll,ImageView_PrintTo", str(file_path), self.config.PRINTER_NAME]
            else:
                # Convert to PDF and print (requires ImageMagick)
                cmd = ["convert", str(file_path), "pdf:-"]
                # This would need additional handling for Unix systems
                return False  # Not implemented for non-Windows yet
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=getattr(self.config, 'TIMEOUT_LP_PRINT_SECONDS', 30)
            )
            
            return process.returncode == 0
            
        except Exception as e:
            logger.error(f"Error printing image file {file_path}: {e}")
            return False

    def _find_sumatra_pdf(self) -> Optional[Path]:
        """Find SumatraPDF executable with enhanced detection."""
        # Check environment variable or config
        if self.config.SUMATRA_PDF_PATH and self.config.SUMATRA_PDF_PATH.exists():
            return self.config.SUMATRA_PDF_PATH
        
        # Check default installation paths
        default_paths = [
            Path(r"C:\Program Files\SumatraPDF\SumatraPDF.exe"),
            Path(r"C:\Program Files (x86)\SumatraPDF\SumatraPDF.exe"),
            Path(os.path.expanduser(r"~\AppData\Local\SumatraPDF\SumatraPDF.exe"))
        ]
        
        for path in default_paths:
            if path.exists():
                return path
        
        # Check system PATH
        sumatra_exe = shutil.which("SumatraPDF")
        if sumatra_exe:
            return Path(sumatra_exe)
        
        logger.warning("SumatraPDF not found in any known location")
        return None

    async def _print_pdf_with_sumatra(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """
        Print PDF using SumatraPDF with FIXED multiple copies handling.
        
        MAJOR FIX: SumatraPDF's -print-settings copies=N parameter doesn't work reliably.
        Instead, we use PowerShell to send the print job with proper copy settings.
        """
        # Find SumatraPDF executable
        sumatra_path = self._find_sumatra_pdf()
        if not sumatra_path:
            logger.error("SumatraPDF not found")
            return False
        
        for attempt in range(1, self.config.MAX_PRINT_RETRIES + 1):
            self.print_stats['retry_attempts'] += 1
            
            try:
                # FIXED APPROACH: Use PowerShell to print with proper copies support
                if self.platform == "Windows":
                    success = await self._print_pdf_with_powershell(file_path, copies, duplex)
                else:
                    # Fallback to original method for non-Windows
                    success = await self._print_pdf_with_sumatra_fallback(file_path, copies, duplex)
                
                if success:
                    return True
                
            except Exception as e:
                logger.warning(f"Print attempt {attempt} error: {e}")
            
            # Wait before retry
            if attempt < self.config.MAX_PRINT_RETRIES:
                logger.debug(f"Waiting {self.config.PRINT_RETRY_DELAY_SECONDS}s before retry...")
                await asyncio.sleep(self.config.PRINT_RETRY_DELAY_SECONDS)
        
        logger.error(f"Failed to print after {self.config.MAX_PRINT_RETRIES} attempts")
        return False

    async def _print_pdf_with_powershell(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """
        Print PDF using PowerShell with proper copy handling.
        This method ensures that the correct number of copies are actually printed.
        """
        try:
            # Escape paths for PowerShell
            file_escaped = str(file_path).replace("'", "''")
            printer_escaped = self.config.PRINTER_NAME.replace("'", "''")
            
            # Build PowerShell script that properly handles copies
            duplex_setting = "1" if duplex and self.duplex_supported else "0"
            
            script = f'''
            try {{
                $ErrorActionPreference = "Stop"
                
                # Create Adobe Reader or SumatraPDF print job with proper settings
                Add-Type -AssemblyName System.Drawing
                Add-Type -AssemblyName System.Windows.Forms
                
                # Use .NET PrintDocument for reliable printing
                $printDoc = New-Object System.Drawing.Printing.PrintDocument
                $printDoc.PrinterSettings.PrinterName = '{printer_escaped}'
                $printDoc.PrinterSettings.Copies = {copies}
                
                if ({duplex_setting} -eq 1) {{
                    $printDoc.PrinterSettings.Duplex = [System.Drawing.Printing.Duplex]::Vertical
                }}
                
                # Use SumatraPDF to render and print
                $process = Start-Process -FilePath '{str(self._find_sumatra_pdf()).replace("'", "''")}' -ArgumentList '-silent', '-print-to', '{printer_escaped}', '-print-settings', 'noscale', '{file_escaped}' -Wait -PassThru -WindowStyle Hidden
                
                if ($process.ExitCode -eq 0) {{
                    # Verify print job was sent correctly by checking if we need additional copies
                    if ({copies} -gt 1) {{
                        # Send additional copies if needed (SumatraPDF sometimes ignores copies parameter)
                        for ($i = 2; $i -le {copies}; $i++) {{
                            Start-Sleep -Milliseconds 500
                            $additionalProcess = Start-Process -FilePath '{str(self._find_sumatra_pdf()).replace("'", "''")}' -ArgumentList '-silent', '-print-to', '{printer_escaped}', '-print-settings', 'noscale', '{file_escaped}' -Wait -PassThru -WindowStyle Hidden
                            if ($additionalProcess.ExitCode -ne 0) {{
                                Write-Error "Additional copy $i failed"
                                exit 1
                            }}
                        }}
                    }}
                    Write-Output "Print successful: {copies} copies sent"
                    exit 0
                }} else {{
                    Write-Error "SumatraPDF failed with exit code $($process.ExitCode)"
                    exit 1
                }}
            }} catch {{
                Write-Error "Print failed: $($_.Exception.Message)"
                exit 1
            }}
            '''

            # Record start time
            start_time = time.time()
            
            # Execute PowerShell script
            process = await asyncio.create_subprocess_exec(
                "powershell", "-ExecutionPolicy", "Bypass", "-Command", script,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=self.config.TIMEOUT_SUMATRA_PRINT_SECONDS * copies  # Scale timeout with copies
                )
                
                elapsed_time = time.time() - start_time
                
                if stdout:
                    logger.debug(f"PowerShell stdout: {stdout.decode().strip()}")
                if stderr:
                    logger.debug(f"PowerShell stderr: {stderr.decode().strip()}")
                
                if process.returncode == 0:
                    logger.info(f"Print successful: {file_path.name} ({copies} copies, took {elapsed_time:.1f}s)")
                    return True
                else:
                    logger.warning(f"PowerShell print failed with return code {process.returncode}")
                    return False
                
            except asyncio.TimeoutError:
                elapsed_time = time.time() - start_time
                logger.warning(f"PowerShell print timed out after {elapsed_time:.1f}s")
                
                # Try to terminate the process
                try:
                    process.terminate()
                    await asyncio.wait_for(process.wait(), timeout=5)
                except:
                    try:
                        process.kill()
                    except:
                        pass
                
                return False
                
        except Exception as e:
            logger.error(f"PowerShell print error: {e}")
            return False

    async def _print_pdf_with_sumatra_fallback(self, file_path: Path, copies: int, duplex: bool) -> bool:
        """
        Fallback method: Print multiple times if copies parameter doesn't work.
        This ensures the correct number of copies by calling SumatraPDF multiple times.
        """
        sumatra_path = self._find_sumatra_pdf()
        if not sumatra_path:
            return False
        
        try:
            # Build base command for single copy
            settings = ["noscale"]
            if duplex and self.duplex_supported:
                settings.append("duplex")
            
            success_count = 0
            
            # Print the requested number of copies by calling SumatraPDF multiple times
            for copy_num in range(1, copies + 1):
                cmd = [
                    str(sumatra_path),
                    "-silent",
                    "-print-to", self.config.PRINTER_NAME,
                    "-print-settings", ",".join(settings),
                    str(file_path)
                ]
                
                logger.debug(f"Print command (copy {copy_num}/{copies}): {' '.join(cmd[:-1])} [file]")
                
                # Record start time
                start_time = time.time()
                
                # Execute print command
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
                )
                
                try:
                    stdout, stderr = await asyncio.wait_for(
                        process.communicate(),
                        timeout=self.config.TIMEOUT_SUMATRA_PRINT_SECONDS
                    )
                    
                    elapsed_time = time.time() - start_time
                    
                    if process.returncode == 0:
                        success_count += 1
                        logger.debug(f"Copy {copy_num} successful (took {elapsed_time:.1f}s)")
                        
                        # Small delay between copies to avoid overwhelming printer
                        if copy_num < copies:
                            await asyncio.sleep(0.5)
                    else:
                        logger.warning(f"Copy {copy_num} failed with return code {process.returncode}")
                        if stderr:
                            logger.debug(f"SumatraPDF stderr: {stderr.decode().strip()}")
                
                except asyncio.TimeoutError:
                    logger.warning(f"Copy {copy_num} timed out")
                    try:
                        process.terminate()
                        await asyncio.wait_for(process.wait(), timeout=5)
                    except:
                        try:
                            process.kill()
                        except:
                            pass
            
            # Consider successful if at least one copy printed
            if success_count > 0:
                if success_count == copies:
                    logger.info(f"All {copies} copies printed successfully")
                else:
                    logger.warning(f"Only {success_count}/{copies} copies printed successfully")
                return True
            else:
                logger.error(f"No copies printed successfully")
                return False
                
        except Exception as e:
            logger.error(f"Fallback print error: {e}")
            return False

    async def _verify_print_job(self, file_name: str) -> bool:
        """Verify that print job was actually sent to printer (Windows only)."""
        try:
            if self.platform != "Windows":
                return True  # Can't verify on non-Windows
            
            # Check print queue
            cmd = [
                "powershell", "-Command",
                f"Get-PrintJob -PrinterName '{self.config.PRINTER_NAME}' | Where-Object {{$_.DocumentName -like '*{file_name}*'}}"
            ]
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=10)
            
            if process.returncode == 0:
                output = stdout.decode('utf-8', errors='ignore')
                # If we find print jobs, that's good
                return len(output.strip()) > 0
            
            # If we can't check, assume success
            return True
            
        except Exception as e:
            logger.debug(f"Could not verify print job: {e}")
            return True  # Assume success if we can't verify

    async def cleanup(self):
        """Cleanup printer manager resources."""
        try:
            if self.docx_converter:
                await self.docx_converter.cleanup()
            logger.debug("Printer manager cleanup completed")
        except Exception as e:
            logger.error(f"Error during printer manager cleanup: {e}")

    def get_stats(self) -> Dict:
        """Get printer statistics."""
        return self.print_stats.copy()
# --- END OF printer_manager.py ---

# --- START OF printer_setup.py ---
#!/usr/bin/env python3
"""
Printer Setup Utility for Gmail Auto Printer
Helps detect and configure printers for the application.
"""
import subprocess
import sys
import os
from pathlib import Path
from typing import List, Dict, Optional

def get_available_printers() -> List[Dict[str, str]]:
    """Get all available printers with detailed information."""
    printers = []
    
    # Method 1: PowerShell with detailed info
    try:
        cmd = [
            "powershell", "-Command",
            "Get-Printer | Select-Object Name, PrinterStatus, DriverName, PortName | ConvertTo-Json"
        ]
        
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=15,
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
        )
        
        if result.returncode == 0 and result.stdout.strip():
            import json
            try:
                data = json.loads(result.stdout)
                if isinstance(data, dict):
                    data = [data]  # Single printer
                
                for printer in data:
                    printers.append({
                        'name': printer.get('Name', 'Unknown'),
                        'status': printer.get('PrinterStatus', 'Unknown'),
                        'driver': printer.get('DriverName', 'Unknown'),
                        'port': printer.get('PortName', 'Unknown')
                    })
            except json.JSONDecodeError:
                # Fallback to simple list
                names = [p.strip() for p in result.stdout.strip().split('\n') if p.strip()]
                printers = [{'name': name, 'status': 'Unknown', 'driver': 'Unknown', 'port': 'Unknown'} for name in names]
    
    except Exception as e:
        print(f"PowerShell detection failed: {e}")
    
    # Fallback method if PowerShell failed
    if not printers:
        try:
            cmd = ["wmic", "printer", "get", "name", "/format:value"]
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=15,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if line.startswith('Name=') and '=' in line:
                        printer_name = line.split('=', 1)[1].strip()
                        if printer_name:
                            printers.append({
                                'name': printer_name,
                                'status': 'Unknown',
                                'driver': 'Unknown',
                                'port': 'Unknown'
                            })
        except Exception as e:
            print(f"WMI fallback failed: {e}")
    
    return printers

def test_printer(printer_name: str) -> Dict[str, str]:
    """Test if a printer is working and get its capabilities."""
    results = {
        'accessible': False,
        'status': 'Unknown',
        'duplex_support': 'Unknown',
        'error': None
    }
    
    try:
        # Check printer status
        cmd = [
            "powershell", "-Command",
            f"Get-Printer -Name '{printer_name}' -ErrorAction SilentlyContinue | Select-Object PrinterStatus"
        ]
        
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=10,
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
        )
        
        if result.returncode == 0:
            results['accessible'] = True
            status = result.stdout.strip()
            if '0' in status:
                results['status'] = 'Normal'
            else:
                results['status'] = status or 'Unknown'
        
        # Check duplex support
        cmd = [
            "powershell", "-Command",
            f"Get-PrinterProperty -PrinterName '{printer_name}' -ErrorAction SilentlyContinue | Where-Object {{$_.PropertyName -like '*duplex*'}}"
        ]
        
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=10,
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
        )
        
        if result.returncode == 0 and result.stdout.strip():
            results['duplex_support'] = 'Yes' if 'true' in result.stdout.lower() else 'No'
        else:
            results['duplex_support'] = 'No'
            
    except Exception as e:
        results['error'] = str(e)
    
    return results

def get_current_config() -> Dict[str, str]:
    """Get current printer configuration from .env file."""
    config = {
        'PRINTER_NAME': None,
        'ENABLE_DUPLEX': None,
        'found_env': False
    }
    
    env_file = Path('.env')
    if env_file.exists():
        config['found_env'] = True
        try:
            with open(env_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line.startswith('PRINTER_NAME='):
                        config['PRINTER_NAME'] = line.split('=', 1)[1].strip()
                    elif line.startswith('ENABLE_DUPLEX='):
                        config['ENABLE_DUPLEX'] = line.split('=', 1)[1].strip()
        except Exception as e:
            print(f"Error reading .env file: {e}")
    
    return config

def update_env_file(printer_name: str):
    """Update the .env file with the selected printer."""
    env_file = Path('.env')
    
    if not env_file.exists():
        print("❌ .env file not found. Please copy .env.template to .env first.")
        return False
    
    try:
        # Read current content
        lines = []
        with open(env_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # Update PRINTER_NAME line
        updated = False
        for i, line in enumerate(lines):
            if line.strip().startswith('PRINTER_NAME='):
                lines[i] = f'PRINTER_NAME={printer_name}\n'
                updated = True
                break
        
        # If not found, add it
        if not updated:
            lines.append(f'PRINTER_NAME={printer_name}\n')
        
        # Write back
        with open(env_file, 'w', encoding='utf-8') as f:
            f.writelines(lines)
        
        print(f"✅ Updated .env file with PRINTER_NAME={printer_name}")
        return True
        
    except Exception as e:
        print(f"❌ Error updating .env file: {e}")
        return False

def install_print_to_pdf():
    """Guide user through installing Microsoft Print to PDF."""
    print("\n📖 HOW TO INSTALL MICROSOFT PRINT TO PDF:")
    print("=" * 50)
    print("1. Open Windows Settings (Win + I)")
    print("2. Go to 'Devices' > 'Printers & scanners'")
    print("3. Click 'Add a printer or scanner'")
    print("4. Wait for scan, then click 'The printer that I want isn't listed'")
    print("5. Select 'Add a local printer or network printer...'")
    print("6. Choose 'Use an existing port' > 'FILE: (Print to File)'")
    print("7. In manufacturer list, select 'Microsoft'")
    print("8. In printer list, select 'Microsoft Print To PDF'")
    print("9. Click 'Next' and follow remaining prompts")
    print("10. Optionally set as default printer")
    print("=" * 50)
    print("After installation, run this script again to verify!")

def main():
    print("🖨️  Gmail Auto Printer - Printer Setup Utility")
    print("=" * 50)
    
    # Get current configuration
    config = get_current_config()
    
    if config['found_env']:
        print(f"📋 Current configuration:")
        print(f"   PRINTER_NAME: {config['PRINTER_NAME'] or 'Not set'}")
        print(f"   ENABLE_DUPLEX: {config['ENABLE_DUPLEX'] or 'Not set'}")
    else:
        print("⚠️  No .env file found. Please copy .env.template to .env first.")
        return
    
    print("\n🔍 Scanning for available printers...")
    printers = get_available_printers()
    
    if not printers:
        print("❌ No printers found on your system!")
        print("\nPossible solutions:")
        print("1. Install Microsoft Print to PDF (recommended)")
        print("2. Install any physical printer")
        print("3. Check Windows printer settings")
        
        choice = input("\nWould you like installation instructions for Microsoft Print to PDF? (y/n): ").lower()
        if choice == 'y':
            install_print_to_pdf()
        return
    
    print(f"\n✅ Found {len(printers)} printer(s):")
    print("-" * 50)
    
    for i, printer in enumerate(printers, 1):
        print(f"{i}. {printer['name']}")
        print(f"   Status: {printer['status']}")
        print(f"   Driver: {printer['driver']}")
        print(f"   Port: {printer['port']}")
        
        # Test the printer
        test_results = test_printer(printer['name'])
        if test_results['accessible']:
            print(f"   ✅ Accessible - Status: {test_results['status']}")
            print(f"   Duplex Support: {test_results['duplex_support']}")
        else:
            print(f"   ❌ Not accessible: {test_results.get('error', 'Unknown error')}")
        print()
    
    # Check current configuration
    if config['PRINTER_NAME']:
        current_printer = config['PRINTER_NAME']
        printer_names = [p['name'] for p in printers]
        
        if current_printer in printer_names:
            print(f"✅ Your current printer '{current_printer}' was found!")
            test_results = test_printer(current_printer)
            if test_results['accessible']:
                print("✅ Printer is accessible and should work.")
                print("\nYour printer setup appears to be correct!")
                return
            else:
                print(f"❌ Printer is not accessible: {test_results.get('error', 'Unknown error')}")
        else:
            print(f"❌ Your current printer '{current_printer}' was NOT found!")
    
    # Let user select a printer
    print("\nSelect a printer to use:")
    print("0. Exit without changes")
    
    while True:
        try:
            choice = input(f"Enter choice (0-{len(printers)}): ").strip()
            
            if choice == '0':
                print("No changes made.")
                return
            
            choice_num = int(choice)
            if 1 <= choice_num <= len(printers):
                selected_printer = printers[choice_num - 1]
                break
            else:
                print(f"Please enter a number between 0 and {len(printers)}")
                
        except ValueError:
            print("Please enter a valid number")
    
    # Test selected printer
    print(f"\n🧪 Testing printer: {selected_printer['name']}")
    test_results = test_printer(selected_printer['name'])
    
    if test_results['accessible']:
        print("✅ Printer test successful!")
        print(f"   Status: {test_results['status']}")
        print(f"   Duplex Support: {test_results['duplex_support']}")
        
        # Update .env file
        if update_env_file(selected_printer['name']):
            print("\n🎉 Printer setup complete!")
            print("You can now run the Gmail Auto Printer without printer errors.")
            print("\nNext steps:")
            print("1. Test with: python main.py --dry-run --debug --once")
            print("2. Run production: python main.py --once")
        
    else:
        print(f"❌ Printer test failed: {test_results.get('error', 'Unknown error')}")
        print("This printer may not work properly with the application.")
        
        choice = input("Do you still want to use this printer? (y/n): ").lower()
        if choice == 'y':
            update_env_file(selected_printer['name'])

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nSetup cancelled.")
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        print("Please check your Windows printer settings and try again.")
# --- END OF printer_setup.py ---

# --- START OF quick_start.py ---
#!/usr/bin/env python3
"""
Gmail Auto Printer - Quick Start Launcher
Interactive setup and testing utility for new users.
"""
import subprocess
import sys
import os
from pathlib import Path

def check_python_version():
    """Check if Python version is compatible."""
    version = sys.version_info
    if version < (3, 8):
        print(f"❌ Python {version.major}.{version.minor} is too old. Please use Python 3.8 or newer.")
        return False
    elif version >= (3, 13):
        print(f"⚠️  Python {version.major}.{version.minor} detected. May have comtypes compatibility issues.")
    else:
        print(f"✅ Python {version.major}.{version.minor} - Compatible")
    return True

def check_files():
    """Check if required files exist."""
    required_files = [
        'main.py', 'config.py', 'gmail_client.py', 'printer_manager.py',
        'attachment_handler.py', 'requirements.txt'
    ]
    
    missing_files = []
    for file in required_files:
        if not Path(file).exists():
            missing_files.append(file)
    
    if missing_files:
        print(f"❌ Missing required files: {', '.join(missing_files)}")
        return False
    
    print("✅ All required files found")
    return True

def check_env_file():
    """Check .env file setup."""
    env_file = Path('.env')
    template_file = Path('.env.template')
    
    if not env_file.exists():
        if template_file.exists():
            print("⚠️  .env file not found, but .env.template exists")
            choice = input("Copy .env.template to .env? (y/n): ").lower()
            if choice == 'y':
                try:
                    template_file.read_text()  # Test read
                    env_file.write_text(template_file.read_text())
                    print("✅ Created .env from template")
                    return True
                except Exception as e:
                    print(f"❌ Failed to copy template: {e}")
                    return False
            else:
                print("❌ .env file is required")
                return False
        else:
            print("❌ Neither .env nor .env.template found")
            return False
    else:
        print("✅ .env file found")
        return True

def check_credentials():
    """Check Gmail API credentials."""
    creds_file = Path('credentials.json')
    
    if not creds_file.exists():
        print("❌ credentials.json not found")
        print("\nTo get Gmail API credentials:")
        print("1. Go to https://console.cloud.google.com/")
        print("2. Create a new project or select existing")
        print("3. Enable Gmail API")
        print("4. Create OAuth 2.0 credentials (Desktop Application)")
        print("5. Download JSON file and rename to 'credentials.json'")
        return False
    
    print("✅ credentials.json found")
    return True

def install_dependencies():
    """Install required Python packages."""
    print("\n📦 Installing dependencies...")
    try:
        subprocess.run([
            sys.executable, "-m", "pip", "install", "-r", "requirements.txt"
        ], check=True, capture_output=True)
        print("✅ Dependencies installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies: {e}")
        return False

def run_printer_setup():
    """Run the printer setup utility."""
    print("\n🖨️  Running printer setup...")
    try:
        subprocess.run([sys.executable, "printer_setup.py"], check=False)
        return True
    except Exception as e:
        print(f"❌ Printer setup failed: {e}")
        return False

def run_quick_test():
    """Run a quick system test."""
    print("\n🧪 Running quick system test...")
    try:
        result = subprocess.run([
            sys.executable, "main.py", "--dry-run", "--debug", "--once", "--skip-env-check"
        ], capture_output=True, text=True, timeout=60)
        
        if result.returncode == 0:
            print("✅ Quick test passed!")
            return True
        else:
            print(f"❌ Quick test failed with return code {result.returncode}")
            if result.stderr:
                print(f"Error: {result.stderr}")
            return False
            
    except subprocess.TimeoutExpired:
        print("❌ Quick test timed out")
        return False
    except Exception as e:
        print(f"❌ Quick test error: {e}")
        return False

def run_environment_check():
    """Run full environment check."""
    print("\n🔍 Running environment check...")
    try:
        result = subprocess.run([
            sys.executable, "main.py", "--dry-run", "--debug", "--once"
        ], capture_output=True, text=True, timeout=120)
        
        if result.returncode == 0:
            print("✅ Environment check passed!")
            return True
        else:
            print(f"⚠️  Environment check had issues (return code {result.returncode})")
            print("This is normal if printer setup is needed.")
            return False
            
    except subprocess.TimeoutExpired:
        print("❌ Environment check timed out")
        return False
    except Exception as e:
        print(f"❌ Environment check error: {e}")
        return False

def show_next_steps():
    """Show next steps for the user."""
    print("\n🎉 SETUP COMPLETE!")
    print("=" * 50)
    print("Next steps:")
    print("1. Test with dry run:")
    print("   python main.py --dry-run --debug --once")
    print("")
    print("2. Test with real printing (one email):")
    print("   python main.py --debug --once")
    print("")
    print("3. Run continuously (production mode):")
    print("   python main.py")
    print("")
    print("📧 Send a test email to yourself with:")
    print(f"   Subject: Print Request")
    print(f"   Attachment: Any PDF file")
    print("=" * 50)

def main():
    """Main setup flow."""
    print("🚀 Gmail Auto Printer - Quick Start Setup")
    print("=" * 50)
    
    # Step 1: Check Python version
    print("Step 1: Checking Python version...")
    if not check_python_version():
        return False
    
    # Step 2: Check required files
    print("\nStep 2: Checking required files...")
    if not check_files():
        return False
    
    # Step 3: Setup .env file
    print("\nStep 3: Checking configuration...")
    if not check_env_file():
        return False
    
    # Step 4: Check credentials
    print("\nStep 4: Checking Gmail credentials...")
    if not check_credentials():
        print("\n❌ Setup cannot continue without Gmail API credentials.")
        print("Please follow the instructions above to get credentials.json")
        return False
    
    # Step 5: Install dependencies
    print("\nStep 5: Installing dependencies...")
    deps_choice = input("Install Python dependencies? (y/n): ").lower()
    if deps_choice == 'y':
        if not install_dependencies():
            print("⚠️  Continuing without installing dependencies...")
    
    # Step 6: Printer setup
    print("\nStep 6: Printer setup...")
    printer_choice = input("Run printer setup utility? (y/n): ").lower()
    if printer_choice == 'y':
        run_printer_setup()
    
    # Step 7: Quick test
    print("\nStep 7: Quick system test...")
    test_choice = input("Run quick system test? (y/n): ").lower()
    if test_choice == 'y':
        if run_quick_test():
            show_next_steps()
    return True

if __name__ == "__main__":
    try:
        success = main()
        if not success:
            print("\n❌ Setup incomplete. Please resolve the issues above.")
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n⏹️  Setup cancelled by user.")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Unexpected error during setup: {e}")
        sys.exit(1)next_steps()
            return True
        else:
            print("❌ Quick test failed. Please check the configuration.")
    
    # Step 8: Environment check
    print("\nStep 8: Full environment check...")
    env_choice = input("Run full environment check? (y/n): ").lower()
    if env_choice == 'y':
        run_environment_check()
    
    print("\n📋 Setup Summary:")
    print("- Configuration files: Ready")
    print("- Gmail credentials: Ready")
    print("- Dependencies: Check manually if needed")
    print("- Printer: May need configuration")
    
    show_
# --- END OF quick_start.py ---

# --- START OF security_validator.py ---
"""
Security validation for email attachments with comprehensive checks.
"""
import re
import socket
import logging
from pathlib import Path
from typing import Dict, Tuple
from dataclasses import dataclass

from config import Config
from malware_scanner import MalwareScanner
from constants import FILE_HEADERS
from utils import SystemUtils

logger = logging.getLogger(__name__)

@dataclass
class ValidationResult:
    """Result of security validation."""
    is_valid: bool
    details: str

class SecurityValidator:
    """Comprehensive security validator for email attachments."""
    
    DANGEROUS_PATTERNS = {
        '..', './', '.\\', '../', '..\\',
        '/', '\\', ':', '|', '<', '>', '"', '*', '?'
    }
    
    RESERVED_NAMES = {
        'CON', 'PRN', 'AUX', 'NUL', 'CLOCK$',
        'COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7', 'COM8', 'COM9',
        'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9'
    }
    
    EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    
    def __init__(self, config: Config, error_notifier):
        self.config = config
        self.error_notifier = error_notifier
        self.malware_scanner = MalwareScanner(config, error_notifier)
        
        self.validation_stats = {
            'total_validations': 0,
            'sender_rejections': 0,
            'filename_rejections': 0,
            'filetype_rejections': 0,
            'malware_detections': 0
        }

    async def validate_attachment(self, sender_email: str, filename: str, file_path: Path) -> Dict:
        """Validate attachment through all security checks."""
        self.validation_stats['total_validations'] += 1
        
        try:
            logger.debug(f"🔍 Security validation starting for: {filename}")
            
            # Step 1: Validate sender
            if not self._validate_sender(sender_email):
                self.validation_stats['sender_rejections'] += 1
                await self.error_notifier.send_error_notification(
                    title="Sender Validation Failure",
                    error_message=f"Invalid sender email: {sender_email}",
                    stack_trace="",
                    error_type="validation_failure"
                )
                return ValidationResult(False, "Invalid sender email").__dict__
            
            # Step 2: Validate filename
            if not self._validate_filename(filename):
                self.validation_stats['filename_rejections'] += 1
                await self.error_notifier.send_error_notification(
                    title="Filename Validation Failure",
                    error_message=f"Invalid filename: {filename}",
                    stack_trace="",
                    error_type="validation_failure"
                )
                return ValidationResult(False, "Invalid filename").__dict__
            
            # Step 3: Validate file type and headers
            if not await self._validate_file_type(filename, file_path):
                self.validation_stats['filetype_rejections'] += 1
                await self.error_notifier.send_error_notification(
                    title="File Type Validation Failure",
                    error_message=f"Invalid file type or headers: {filename}",
                    stack_trace="",
                    error_type="validation_failure"
                )
                return ValidationResult(False, "Invalid file type or headers").__dict__
            
            # Step 4: Malware scan
            if self.config.ENABLE_MALWARE_SCAN and not self.config.DISABLE_MALWARE_SCAN:
                if not await self.malware_scanner.scan_file(file_path):
                    self.validation_stats['malware_detections'] += 1
                    return ValidationResult(False, "Malware scan failed").__dict__
            
            logger.debug(f"✅ Security validation passed: {SystemUtils.sanitize_log_input(filename)}")
            return ValidationResult(True, "All security checks passed").__dict__
            
        except Exception as e:
            logger.error(f"Security validation error for {SystemUtils.sanitize_log_input(filename)}: {e}")
            await self.error_notifier.send_error_notification(
                title="Security Validation Error",
                error_message=f"Security validation error for {filename}: {str(e)}",
                stack_trace="",
                error_type="validation_failure"
            )
            return ValidationResult(False, f"Validation error: {str(e)}").__dict__

    def _validate_sender(self, sender_email: str) -> bool:
        """Validate email sender with security checks."""
        try:
            if not sender_email or not isinstance(sender_email, str):
                return False
            
            sender_email = sender_email.strip()
            
            email_match = re.search(r'<([^>]+)>', sender_email)
            if email_match:
                actual_email = email_match.group(1).strip()
                display_name = sender_email.split('<')[0].strip()
                
                if any(char in display_name for char in ['<', '>', '\n', '\r', '\0']):
                    logger.warning(f"Suspicious display name: {SystemUtils.sanitize_log_input(display_name)}")
                    return False
            else:
                actual_email = sender_email
            
            if not self.EMAIL_REGEX.match(actual_email):
                logger.warning(f"Invalid email format: {SystemUtils.sanitize_log_input(actual_email)}")
                return False
            
            if len(actual_email) > 254:
                logger.warning(f"Email address too long: {len(actual_email)} chars")
                return False
            
            if '..' in actual_email or actual_email.startswith('.') or actual_email.endswith('.'):
                logger.warning(f"Suspicious email pattern: {SystemUtils.sanitize_log_input(actual_email)}")
                return False
            
            domain = actual_email.split('@')[-1].lower()
            
            if self.config.ENABLE_DNS_VALIDATION:
                if not self._validate_domain_dns(domain):
                    return False
            
            if self.config.ALLOWED_SENDER_DOMAINS:
                domain_allowed = any(
                    domain == allowed_domain or domain.endswith('.' + allowed_domain)
                    for allowed_domain in self.config.ALLOWED_SENDER_DOMAINS
                )
                if not domain_allowed:
                    logger.info(f"Email from non-whitelisted domain: {domain}")
                    return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error validating sender {SystemUtils.sanitize_log_input(sender_email)}: {e}")
            return False

    def _validate_domain_dns(self, domain: str) -> bool:
        """Validate domain via DNS lookup."""
        try:
            socket.setdefaulttimeout(3)
            socket.gethostbyname(domain)
            logger.debug(f"DNS validation passed: {domain}")
            return True
        except (socket.gaierror, socket.timeout):
            logger.warning(f"DNS validation failed: {domain}")
            return False
        finally:
            socket.setdefaulttimeout(None)

    def _validate_filename(self, filename: str) -> bool:
        """Comprehensive filename validation."""
        if not isinstance(filename, str) or not filename.strip():
            return False
        
        try:
            decoded_filename = SystemUtils.decode_email_header(filename).strip()
            
            if '\0' in decoded_filename:
                logger.warning(f"Filename contains null byte: {SystemUtils.sanitize_log_input(filename)}")
                return False
            
            control_chars = [c for c in decoded_filename if ord(c) < 32 or (127 <= ord(c) <= 159)]
            if control_chars:
                logger.warning(f"Filename contains control characters")
                return False
            
            for pattern in self.DANGEROUS_PATTERNS:
                if pattern in decoded_filename:
                    logger.warning(f"Filename contains dangerous pattern: {pattern}")
                    return False
            
            if len(decoded_filename.encode('utf-8')) > 255:
                logger.warning(f"Filename too long: {len(decoded_filename)} chars")
                return False
            
            name_without_ext = decoded_filename.upper()
            if '.' in name_without_ext:
                name_without_ext = name_without_ext.rsplit('.', 1)[0]
            
            if name_without_ext in self.RESERVED_NAMES:
                logger.warning(f"Filename uses reserved name: {name_without_ext}")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error validating filename: {e}")
            return False

    async def _validate_file_type(self, filename: str, file_path: Path) -> bool:
        """Validate file type with header checking."""
        try:
            if self.config.ALLOW_ALL_FILE_TYPES:
                return True
            
            file_ext = SystemUtils.get_file_extension(filename)
            if not file_ext:
                logger.warning(f"File has no extension: {SystemUtils.sanitize_log_input(filename)}")
                return False
            
            allowed_extensions = [ext.lower() for ext in self.config.ALLOWED_FILE_TYPES]
            if file_ext.lower() not in allowed_extensions:
                logger.warning(f"File type '{file_ext}' not in allowed list: {allowed_extensions}")
                return False
            
            if not await self._validate_file_headers(file_path, file_ext):
                logger.warning(f"File header validation failed: {SystemUtils.sanitize_log_input(filename)}")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error validating file type: {e}")
            return False

    async def _validate_file_headers(self, file_path: Path, file_ext: str) -> bool:
        """Validate file headers match expected type."""
        try:
            if not file_path.exists():
                return False
            
            file_size = file_path.stat().st_size
            if file_size == 0:
                return file_ext.lower() in ['txt', 'log', 'csv']
            
            header_size = min(file_size, FILE_HEADERS.get('FILE_HEADER_READ_BYTES', 512))
            header_bytes = file_path.read_bytes()[:header_size]
            
            expected_headers = FILE_HEADERS.get(file_ext.lower(), [])
            if expected_headers:
                header_match = any(header_bytes.startswith(header) for header in expected_headers)
                if not header_match:
                    logger.warning(f"Header mismatch for {file_ext}. Got: {header_bytes[:16].hex()}")
                    return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error validating file headers: {e}")
            return False

    def get_validation_stats(self) -> Dict:
        """Get validation statistics."""
        stats = self.validation_stats.copy()
        stats['malware_scanner'] = self.malware_scanner.get_stats()
        return stats
# --- END OF security_validator.py ---

# --- START OF utils.py ---
"""
Utility functions for the Gmail Auto Printer system.
"""
import json
import logging
import re
import os
import asyncio
import subprocess
from pathlib import Path
from typing import Set, Optional, List
import email.header
import time
logger = logging.getLogger(__name__)
class SystemUtils:
    """System utility functions."""
    @staticmethod
    def get_version() -> str:
        """Get application version."""
        try:
            version_file = Path('version.txt')
            if version_file.exists():
                return version_file.read_text().strip()
            return "1.0.0"
        except Exception:
            return "1.0.0"
    @staticmethod
    def sanitize_filename(filename: str) -> str:
        """Sanitize filename for safe file system operations."""
        if not filename:
            return "unnamed_file"
        # Remove or replace dangerous characters
        filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
        filename = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', filename)
        # Remove leading/trailing dots and spaces
        filename = filename.strip('. ')
        # Ensure not empty
        if not filename:
            filename = "unnamed_file"
        # Limit length
        if len(filename) > 200:
            name, ext = os.path.splitext(filename)
            filename = name[:200-len(ext)] + ext
        return filename
    @staticmethod
    def sanitize_log_input(text: str) -> str:
        """Sanitize text for safe logging."""
        if not isinstance(text, str):
            text = str(text)
        # Remove control characters except newlines and tabs
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', '', text)
        # Limit length for logs
        if len(text) > 500:
            text = text[:497] + "..."
        return text
    @staticmethod
    def get_file_extension(filename: str) -> str:
        """Get file extension safely."""
        if not filename:
            return ""
        return Path(filename).suffix.lower().lstrip('.')
    @staticmethod
    def decode_email_header(header: str) -> str:
        """Decode email header with proper encoding handling."""
        try:
            decoded_parts = email.header.decode_header(header)
            decoded_string = ""
            for part, encoding in decoded_parts:
                if isinstance(part, bytes):
                    if encoding:
                        decoded_string += part.decode(encoding)
                    else:
                        decoded_string += part.decode('utf-8', errors='replace')
                else:
                    decoded_string += part
            return decoded_string
        except Exception as e:
            logger.warning(f"Failed to decode email header: {e}")
            return header
    @staticmethod
    def load_processed_ids(file_path: Path) -> Set[str]:
        """Load processed email IDs from file."""
        try:
            if file_path.exists():
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        return set(data)
                    elif isinstance(data, dict) and 'processed_ids' in data:
                        return set(data['processed_ids'])
            return set()
        except Exception as e:
            logger.warning(f"Failed to load processed IDs: {e}")
            return set()
    @staticmethod
    def save_processed_id(file_path: Path, message_id: str):
        """Save processed email ID to file."""
        try:
            processed_ids = SystemUtils.load_processed_ids(file_path)
            processed_ids.add(message_id)
            # Keep only last 1000 IDs to prevent file growth
            if len(processed_ids) > 1000:
                processed_ids = set(list(processed_ids)[-1000:])
            data = {
                'processed_ids': list(processed_ids),
                'last_updated': time.time()
            }
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save processed ID {message_id}: {e}")
    @staticmethod
    def cleanup_file(file_path: Path):
        """Safely cleanup a file."""
        try:
            if file_path.exists():
                file_path.unlink()
                logger.debug(f"Cleaned up file: {file_path}")
        except Exception as e:
            logger.warning(f"Failed to cleanup file {file_path}: {e}")
    @staticmethod
    def cleanup_temp_files(temp_dir: Path):
        """Cleanup temporary files older than 1 hour."""
        try:
            if not temp_dir.exists():
                return
            current_time = time.time()
            for file_path in temp_dir.glob('*'):
                try:
                    if file_path.is_file():
                        file_age = current_time - file_path.stat().st_mtime
                        if file_age > 3600:  # 1 hour
                            file_path.unlink()
                            logger.debug(f"Cleaned up old temp file: {file_path}")
                except Exception as e:
                    logger.warning(f"Failed to cleanup temp file {file_path}: {e}")
        except Exception as e:
            logger.warning(f"Failed to cleanup temp directory {temp_dir}: {e}")
class ExponentialBackoff:
    """Exponential backoff utility for retries."""
    def __init__(self, initial_delay: float = 1.0, max_delay: float = 60.0, backoff_factor: float = 2.0):
        self.initial_delay = initial_delay
        self.max_delay = max_delay
        self.backoff_factor = backoff_factor
        self.current_delay = initial_delay
        self.attempt_count = 0
    def get_next_delay(self) -> float:
        """Get next delay value and increment attempt count."""
        delay = min(self.current_delay, self.max_delay)
        self.current_delay *= self.backoff_factor
        self.attempt_count += 1
        return delay
    def reset(self):
        """Reset backoff to initial state."""
        self.current_delay = self.initial_delay
        self.attempt_count = 0

# --- END OF utils.py ---


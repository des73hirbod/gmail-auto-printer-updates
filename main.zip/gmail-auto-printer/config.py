"""
Production-ready configuration management with comprehensive validation.
"""
import os
import sys
import logging
from pathlib import Path
from dotenv import load_dotenv
from typing import List, Optional

logger = logging.getLogger(__name__)

class ConfigValidationError(Exception):
    """Raised when configuration validation fails."""
    pass

class Config:
    """Production configuration class with comprehensive validation."""
    
    def __init__(self, dry_run: bool = False, run_once: bool = False):
        """Initialize configuration with validation."""
        # Load environment variables
        load_dotenv()
        
        # Runtime flags
        self.DRY_RUN = dry_run
        self.RUN_ONCE = run_once
        self.ENABLE_AUTO_UPDATE = os.getenv('ENABLE_AUTO_UPDATE', 'false').lower() == 'true'
        
        # Email settings (REQUIRED)
        self.EMAIL_ADDRESS = self._get_required_env('EMAIL_ADDRESS')
        self.EMAIL_PASSWORD = self._get_required_env('EMAIL_PASSWORD')
        self.IMAP_SERVER = os.getenv('IMAP_SERVER', 'imap.gmail.com')
        self.IMAP_PORT = int(os.getenv('IMAP_PORT', '993'))
        self.MAILBOX = os.getenv('MAILBOX', 'INBOX')
        
        # Target email criteria (at least one required for production)
        self.TARGET_SENDER = os.getenv('TARGET_SENDER', '').strip()
        self.TARGET_SUBJECT = os.getenv('TARGET_SUBJECT', '').strip()
        
        # File handling
        allowed_types = os.getenv('ALLOWED_FILE_TYPES', 'pdf,docx,doc,jpg,jpeg,png,txt')
        self.ALLOWED_FILE_TYPES = [ext.strip().lower() for ext in allowed_types.split(',') if ext.strip()]
        self.MAX_ATTACHMENT_SIZE_MB = float(os.getenv('MAX_ATTACHMENT_SIZE_MB', '50'))
        self.ALLOW_ALL_FILE_TYPES = os.getenv('ALLOW_ALL_FILE_TYPES', 'false').lower() == 'true'
        
        # Printing settings
        self.COPIES = int(os.getenv('COPIES', '1'))
        self.ENABLE_DUPLEX = os.getenv('ENABLE_DUPLEX', 'false').lower() == 'true'
        self.PRINTER_NAME = os.getenv('PRINTER_NAME', 'Microsoft Print to PDF')
        self.MAX_PRINT_RETRIES = int(os.getenv('MAX_PRINT_RETRIES', '3'))
        self.PRINT_RETRY_DELAY_SECONDS = float(os.getenv('PRINT_RETRY_DELAY_SECONDS', '5'))
        
        # System settings
        self.POLL_INTERVAL_SECONDS = int(os.getenv('POLL_INTERVAL_SECONDS', '30'))
        self.LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO').upper()
        
        # Directory settings
        self.DOWNLOAD_DIR = self._create_directory('DOWNLOAD_DIR', 'attachments')
        self.MALWARE_SCAN_TEMP_DIR = self._create_directory('MALWARE_SCAN_TEMP_DIR', 'malware_scan_temp')
        self.PROCESSED_IDS_FILE = Path(os.getenv('PROCESSED_IDS_FILE', 'processed_ids.json')).resolve()
        
        # External tools with better defaults
        sumatra_path = os.getenv('SUMATRA_PDF_PATH', '')
        if sumatra_path:
            self.SUMATRA_PDF_PATH = Path(sumatra_path).resolve()
        else:
            # Common installation paths
            common_paths = [
                Path(r"C:\Program Files\SumatraPDF\SumatraPDF.exe"),
                Path(r"C:\Program Files (x86)\SumatraPDF\SumatraPDF.exe"),
                Path(r"C:\Users") / os.getenv('USERNAME', 'Default') / r"AppData\Local\SumatraPDF\SumatraPDF.exe"
            ]
            self.SUMATRA_PDF_PATH = None
            for path in common_paths:
                if path.exists():
                    self.SUMATRA_PDF_PATH = path
                    break
            if not self.SUMATRA_PDF_PATH:
                self.SUMATRA_PDF_PATH = Path('SumatraPDF.exe')  # Fallback
        
        # Security settings with proper defaults
        self.ENABLE_MALWARE_SCAN = os.getenv('ENABLE_MALWARE_SCAN', 'true').lower() == 'true'
        self.DISABLE_MALWARE_SCAN = os.getenv('DISABLE_MALWARE_SCAN', 'false').lower() == 'true'
        self.MAX_SCAN_FILE_SIZE_MB = float(os.getenv('MAX_SCAN_FILE_SIZE_MB', '100'))
        
        # Timeout settings - ensure all are defined
        self.TIMEOUT_DEFENDER_SCAN_SECONDS = int(os.getenv('TIMEOUT_DEFENDER_SCAN_SECONDS', '30'))
        self.TIMEOUT_CLAMAV_SCAN_SECONDS = int(os.getenv('TIMEOUT_CLAMAV_SCAN_SECONDS', '60'))
        self.TIMEOUT_SUMATRA_PRINT_SECONDS = int(os.getenv('TIMEOUT_SUMATRA_PRINT_SECONDS', '60'))
        self.TIMEOUT_LP_PRINT_SECONDS = int(os.getenv('TIMEOUT_LP_PRINT_SECONDS', '30'))
        self.TIMEOUT_WORD_CONVERSION_SECONDS = int(os.getenv('TIMEOUT_WORD_CONVERSION_SECONDS', '60'))
        
        # Domain validation
        allowed_domains = os.getenv('ALLOWED_SENDER_DOMAINS', '')
        self.ALLOWED_SENDER_DOMAINS = [d.strip().lower() for d in allowed_domains.split(',') if d.strip()] if allowed_domains else []
        self.ENABLE_DNS_VALIDATION = os.getenv('ENABLE_DNS_VALIDATION', 'false').lower() == 'true'
        
        # Auto-updater settings
        self.UPDATE_CHECK_INTERVAL_HOURS = int(os.getenv('UPDATE_CHECK_INTERVAL_HOURS', '24'))
        self.UPDATE_REPOSITORY_URL = os.getenv('UPDATE_REPOSITORY_URL', '').strip()
        self.UPDATE_BRANCH = os.getenv('UPDATE_BRANCH', 'main')
        
        # Error notification settings
        self.ERROR_WEBHOOK_URL = os.getenv('ERROR_WEBHOOK_URL', '').strip()
        self.ERROR_EMAIL_RECIPIENT = os.getenv('ERROR_EMAIL_RECIPIENT', '').strip()
        self.ERROR_NOTIFICATION_ENABLED = os.getenv('ERROR_NOTIFICATION_ENABLED', 'true').lower() == 'true'
        
        # Validate configuration
        self._validate_config()

    def _get_required_env(self, key: str) -> str:
        """Get required environment variable or raise error."""
        value = os.getenv(key, '').strip()
        if not value:
            raise ConfigValidationError(f"Required environment variable {key} is not set")
        return value

    def _create_directory(self, env_key: str, default_name: str) -> Path:
        """Create and return directory path."""
        dir_path = Path(os.getenv(env_key, default_name)).resolve()
        try:
            dir_path.mkdir(parents=True, exist_ok=True)
            return dir_path
        except (OSError, PermissionError) as e:
            raise ConfigValidationError(f"Failed to create directory {dir_path}: {e}")

    def _validate_config(self):
        """Comprehensive configuration validation."""
        errors = []
        
        # Validate email settings
        if '@' not in self.EMAIL_ADDRESS:
            errors.append("EMAIL_ADDRESS must be a valid email address")
        if not self.EMAIL_PASSWORD:
            errors.append("EMAIL_PASSWORD cannot be empty")
        
        # Production requires email filtering (but not for dry-run)
        if not self.DRY_RUN and not self.TARGET_SENDER and not self.TARGET_SUBJECT:
            errors.append("Either TARGET_SENDER or TARGET_SUBJECT must be set for production use")
        
        # Validate numeric settings
        if self.MAX_ATTACHMENT_SIZE_MB <= 0:
            errors.append("MAX_ATTACHMENT_SIZE_MB must be positive")
        if self.COPIES <= 0:
            errors.append("COPIES must be positive")
        if self.POLL_INTERVAL_SECONDS <= 0:
            errors.append("POLL_INTERVAL_SECONDS must be positive")
        if self.MAX_PRINT_RETRIES <= 0:
            errors.append("MAX_PRINT_RETRIES must be positive")
            
        # Validate timeout settings
        timeout_settings = [
            ('TIMEOUT_DEFENDER_SCAN_SECONDS', self.TIMEOUT_DEFENDER_SCAN_SECONDS),
            ('TIMEOUT_CLAMAV_SCAN_SECONDS', self.TIMEOUT_CLAMAV_SCAN_SECONDS),
            ('TIMEOUT_SUMATRA_PRINT_SECONDS', self.TIMEOUT_SUMATRA_PRINT_SECONDS),
            ('TIMEOUT_LP_PRINT_SECONDS', self.TIMEOUT_LP_PRINT_SECONDS),
            ('TIMEOUT_WORD_CONVERSION_SECONDS', self.TIMEOUT_WORD_CONVERSION_SECONDS)
        ]
        
        for setting_name, setting_value in timeout_settings:
            if setting_value <= 0:
                errors.append(f"{setting_name} must be positive")
        
        # Validate file types
        if not self.ALLOWED_FILE_TYPES and not self.ALLOW_ALL_FILE_TYPES:
            errors.append("Either ALLOWED_FILE_TYPES must be specified or ALLOW_ALL_FILE_TYPES must be true")
        
        # Validate log level
        valid_log_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
        if self.LOG_LEVEL not in valid_log_levels:
            errors.append(f"LOG_LEVEL must be one of: {valid_log_levels}")
        
        # Check malware scan settings
        if self.DISABLE_MALWARE_SCAN and self.ENABLE_MALWARE_SCAN:
            logger.warning("Both ENABLE_MALWARE_SCAN and DISABLE_MALWARE_SCAN are true; disabling malware scanning")
            self.ENABLE_MALWARE_SCAN = False
        
        # Validate error notification settings
        if self.ERROR_NOTIFICATION_ENABLED:
            if not self.ERROR_WEBHOOK_URL and not self.ERROR_EMAIL_RECIPIENT:
                logger.warning("Error notifications enabled but no webhook URL or email recipient specified")
        
        # Report validation errors
        if errors:
            error_message = "Configuration validation failed:\n" + "\n".join(f"  - {error}" for error in errors)
            raise ConfigValidationError(error_message)
        
        logger.info("Configuration validation passed")

    def get_summary(self) -> dict:
        """Get configuration summary for logging."""
        return {
            'email_address': self.EMAIL_ADDRESS,
            'target_sender': self.TARGET_SENDER or 'Not set',
            'target_subject': self.TARGET_SUBJECT or 'Not set',
            'printer_name': self.PRINTER_NAME,
            'allowed_file_types': self.ALLOWED_FILE_TYPES,
            'max_attachment_size_mb': self.MAX_ATTACHMENT_SIZE_MB,
            'copies': self.COPIES,
            'duplex_enabled': self.ENABLE_DUPLEX,
            'malware_scan_enabled': self.ENABLE_MALWARE_SCAN and not self.DISABLE_MALWARE_SCAN,
            'auto_update_enabled': self.ENABLE_AUTO_UPDATE,
            'dry_run': self.DRY_RUN,
            'run_once': self.RUN_ONCE,
            'sumatra_pdf_path': str(self.SUMATRA_PDF_PATH) if self.SUMATRA_PDF_PATH else 'Not found'
        }
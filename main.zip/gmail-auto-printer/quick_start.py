#!/usr/bin/env python3
"""
Gmail Auto Printer - Quick Start Launcher
Interactive setup and testing utility for new users.
"""
import subprocess
import sys
import os
from pathlib import Path

def check_python_version():
    """Check if Python version is compatible."""
    version = sys.version_info
    if version < (3, 8):
        print(f"❌ Python {version.major}.{version.minor} is too old. Please use Python 3.8 or newer.")
        return False
    elif version >= (3, 13):
        print(f"⚠️  Python {version.major}.{version.minor} detected. May have comtypes compatibility issues.")
    else:
        print(f"✅ Python {version.major}.{version.minor} - Compatible")
    return True

def check_files():
    """Check if required files exist."""
    required_files = [
        'main.py', 'config.py', 'gmail_client.py', 'printer_manager.py',
        'attachment_handler.py', 'requirements.txt'
    ]
    
    missing_files = []
    for file in required_files:
        if not Path(file).exists():
            missing_files.append(file)
    
    if missing_files:
        print(f"❌ Missing required files: {', '.join(missing_files)}")
        return False
    
    print("✅ All required files found")
    return True

def check_env_file():
    """Check .env file setup."""
    env_file = Path('.env')
    template_file = Path('.env.template')
    
    if not env_file.exists():
        if template_file.exists():
            print("⚠️  .env file not found, but .env.template exists")
            choice = input("Copy .env.template to .env? (y/n): ").lower()
            if choice == 'y':
                try:
                    template_file.read_text()  # Test read
                    env_file.write_text(template_file.read_text())
                    print("✅ Created .env from template")
                    return True
                except Exception as e:
                    print(f"❌ Failed to copy template: {e}")
                    return False
            else:
                print("❌ .env file is required")
                return False
        else:
            print("❌ Neither .env nor .env.template found")
            return False
    else:
        print("✅ .env file found")
        return True

def check_credentials():
    """Check Gmail API credentials."""
    creds_file = Path('credentials.json')
    
    if not creds_file.exists():
        print("❌ credentials.json not found")
        print("\nTo get Gmail API credentials:")
        print("1. Go to https://console.cloud.google.com/")
        print("2. Create a new project or select existing")
        print("3. Enable Gmail API")
        print("4. Create OAuth 2.0 credentials (Desktop Application)")
        print("5. Download JSON file and rename to 'credentials.json'")
        return False
    
    print("✅ credentials.json found")
    return True

def install_dependencies():
    """Install required Python packages."""
    print("\n📦 Installing dependencies...")
    try:
        subprocess.run([
            sys.executable, "-m", "pip", "install", "-r", "requirements.txt"
        ], check=True, capture_output=True)
        print("✅ Dependencies installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies: {e}")
        return False

def run_printer_setup():
    """Run the printer setup utility."""
    print("\n🖨️  Running printer setup...")
    try:
        subprocess.run([sys.executable, "printer_setup.py"], check=False)
        return True
    except Exception as e:
        print(f"❌ Printer setup failed: {e}")
        return False

def run_quick_test():
    """Run a quick system test."""
    print("\n🧪 Running quick system test...")
    try:
        result = subprocess.run([
            sys.executable, "main.py", "--dry-run", "--debug", "--once", "--skip-env-check"
        ], capture_output=True, text=True, timeout=60)
        
        if result.returncode == 0:
            print("✅ Quick test passed!")
            return True
        else:
            print(f"❌ Quick test failed with return code {result.returncode}")
            if result.stderr:
                print(f"Error: {result.stderr}")
            return False
            
    except subprocess.TimeoutExpired:
        print("❌ Quick test timed out")
        return False
    except Exception as e:
        print(f"❌ Quick test error: {e}")
        return False

def run_environment_check():
    """Run full environment check."""
    print("\n🔍 Running environment check...")
    try:
        result = subprocess.run([
            sys.executable, "main.py", "--dry-run", "--debug", "--once"
        ], capture_output=True, text=True, timeout=120)
        
        if result.returncode == 0:
            print("✅ Environment check passed!")
            return True
        else:
            print(f"⚠️  Environment check had issues (return code {result.returncode})")
            print("This is normal if printer setup is needed.")
            return False
            
    except subprocess.TimeoutExpired:
        print("❌ Environment check timed out")
        return False
    except Exception as e:
        print(f"❌ Environment check error: {e}")
        return False

def show_next_steps():
    """Show next steps for the user."""
    print("\n🎉 SETUP COMPLETE!")
    print("=" * 50)
    print("Next steps:")
    print("1. Test with dry run:")
    print("   python main.py --dry-run --debug --once")
    print("")
    print("2. Test with real printing (one email):")
    print("   python main.py --debug --once")
    print("")
    print("3. Run continuously (production mode):")
    print("   python main.py")
    print("")
    print("📧 Send a test email to yourself with:")
    print(f"   Subject: Print Request")
    print(f"   Attachment: Any PDF file")
    print("=" * 50)

def main():
    """Main setup flow."""
    print("🚀 Gmail Auto Printer - Quick Start Setup")
    print("=" * 50)
    
    # Step 1: Check Python version
    print("Step 1: Checking Python version...")
    if not check_python_version():
        return False
    
    # Step 2: Check required files
    print("\nStep 2: Checking required files...")
    if not check_files():
        return False
    
    # Step 3: Setup .env file
    print("\nStep 3: Checking configuration...")
    if not check_env_file():
        return False
    
    # Step 4: Check credentials
    print("\nStep 4: Checking Gmail credentials...")
    if not check_credentials():
        print("\n❌ Setup cannot continue without Gmail API credentials.")
        print("Please follow the instructions above to get credentials.json")
        return False
    
    # Step 5: Install dependencies
    print("\nStep 5: Installing dependencies...")
    deps_choice = input("Install Python dependencies? (y/n): ").lower()
    if deps_choice == 'y':
        if not install_dependencies():
            print("⚠️  Continuing without installing dependencies...")
    
    # Step 6: Printer setup
    print("\nStep 6: Printer setup...")
    printer_choice = input("Run printer setup utility? (y/n): ").lower()
    if printer_choice == 'y':
        run_printer_setup()
    
    # Step 7: Quick test
    print("\nStep 7: Quick system test...")
    test_choice = input("Run quick system test? (y/n): ").lower()
    if test_choice == 'y':
        if run_quick_test():
            show_next_steps()
    return True

if __name__ == "__main__":
    try:
        success = main()
        if not success:
            print("\n❌ Setup incomplete. Please resolve the issues above.")
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n⏹️  Setup cancelled by user.")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Unexpected error during setup: {e}")
        sys.exit(1)next_steps()
            return True
        else:
            print("❌ Quick test failed. Please check the configuration.")
    
    # Step 8: Environment check
    print("\nStep 8: Full environment check...")
    env_choice = input("Run full environment check? (y/n): ").lower()
    if env_choice == 'y':
        run_environment_check()
    
    print("\n📋 Setup Summary:")
    print("- Configuration files: Ready")
    print("- Gmail credentials: Ready")
    print("- Dependencies: Check manually if needed")
    print("- Printer: May need configuration")
    
    show_
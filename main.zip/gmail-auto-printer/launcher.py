#!/usr/bin/env python3
"""
Gmail Auto Printer Launcher
Safe wrapper that handles Python version compatibility and missing dependencies.
"""
import sys
import os
import subprocess
from pathlib import Path

def check_python_version():
    """Check if Python version is compatible."""
    version = sys.version_info
    if version < (3, 8):
        print(f"❌ Error: Python {version.major}.{version.minor} is too old.")
        print("   Gmail Auto Printer requires Python 3.8 or newer.")
        print("   Please upgrade Python and try again.")
        return False
    
    if version >= (3, 13):
        print(f"⚠️  Warning: Python {version.major}.{version.minor} detected.")
        print("   Some features (DOCX conversion) may have compatibility issues.")
        print("   Consider using Python 3.11 or 3.12 for best compatibility.")
    
    return True

def check_required_files():
    """Check if required files exist."""
    required_files = [
        'main.py',
        'config.py',
        'gmail_client.py',
        'printer_manager.py',
        'attachment_handler.py',
    ]
    
    missing_files = []
    for file in required_files:
        if not Path(file).exists():
            missing_files.append(file)
    
    if missing_files:
        print("❌ Error: Missing required files:")
        for file in missing_files:
            print(f"   - {file}")
        return False
    
    return True

def check_credentials():
    """Check if credentials are configured."""
    if not Path('.env').exists():
        print("❌ Error: .env file not found.")
        print("   Please copy .env.template to .env and configure your settings.")
        return False
    
    if not Path('credentials.json').exists():
        print("❌ Error: credentials.json not found.")
        print("   Please download your Gmail API credentials from Google Cloud Console.")
        return False
    
    return True

def install_requirements():
    """Install required packages."""
    try:
        print("📦 Installing required packages...")
        result = subprocess.run([
            sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'
        ], check=True, capture_output=True, text=True)
        print("✅ Requirements installed successfully.")
        return True
    except subprocess.CalledProcessError as e:
        print("❌ Error installing requirements:")
        print(e.stderr)
        print("\nTry running manually:")
        print(f"   {sys.executable} -m pip install -r requirements.txt")
        return False
    except FileNotFoundError:
        print("❌ Error: pip not found. Please install pip first.")
        return False

def run_application(args):
    """Run the main application."""
    try:
        cmd = [sys.executable, 'main.py'] + args
        print(f"🚀 Starting Gmail Auto Printer...")
        print(f"   Command: {' '.join(cmd)}")
        
        # Run the application
        result = subprocess.run(cmd)
        return result.returncode
    
    except KeyboardInterrupt:
        print("\n⏹️  Application stopped by user.")
        return 0
    except Exception as e:
        print(f"❌ Error running application: {e}")
        return 1

def main():
    """Main launcher function."""
    print("=" * 50)
    print("🖨️  Gmail Auto Printer Launcher v2.0.0")
    print("=" * 50)
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Check required files
    if not check_required_files():
        sys.exit(1)
    
    # Check credentials
    if not check_credentials():
        sys.exit(1)
    
    # Install requirements if needed
    if Path('requirements.txt').exists():
        try:
            import google.auth
            print("✅ Requirements already installed.")
        except ImportError:
            if not install_requirements():
                sys.exit(1)
    
    # Run application
    args = sys.argv[1:]  # Pass all command line arguments
    exit_code = run_application(args)
    
    print("=" * 50)
    if exit_code == 0:
        print("✅ Gmail Auto Printer completed successfully.")
    else:
        print(f"❌ Gmail Auto Printer exited with code {exit_code}.")
    print("=" * 50)
    
    sys.exit(exit_code)

if __name__ == '__main__':
    main()
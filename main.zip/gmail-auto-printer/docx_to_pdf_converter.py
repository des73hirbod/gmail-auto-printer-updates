"""
DOCX to PDF converter with multiple fallback options for maximum compatibility.
Fixed COM threading issues and improved error handling.
"""
import logging
import asyncio
import sys
import subprocess
import threading
from pathlib import Path
from typing import Optional

# Try to import comtypes - handle compatibility issues
COMTYPES_AVAILABLE = False
WORD_CONVERSION_AVAILABLE = False

try:
    # Check Python version compatibility
    if sys.version_info >= (3, 13):
        logger = logging.getLogger(__name__)
        logger.warning("Python 3.13+ detected - comtypes may have compatibility issues")
        logger.info("Will use alternative conversion methods")
    else:
        import comtypes.client
        import comtypes
        from comtypes import COMError
        COMTYPES_AVAILABLE = True
        WORD_CONVERSION_AVAILABLE = True
except ImportError as e:
    logger = logging.getLogger(__name__)
    logger.warning(f"comtypes not available: {e}")
    logger.info("Will use alternative conversion methods")
    COMError = Exception
except Exception as e:
    logger = logging.getLogger(__name__)
    logger.warning(f"comtypes initialization failed: {e}")
    COMError = Exception

logger = logging.getLogger(__name__)

class DocxToPDFConverter:
    """Converts DOCX files to PDF using multiple fallback methods."""
    
    def __init__(self):
        self.conversion_methods = [
            ("PowerShell", self._convert_with_powershell),  # Move PowerShell first - more reliable
            ("Microsoft Word COM", self._convert_with_word_com),
            ("LibreOffice", self._convert_with_libreoffice),
            ("Copy as is", self._copy_as_fallback)
        ]

    async def convert_to_pdf(self, docx_path: Path, pdf_path: Path) -> bool:
        """Convert DOCX file to PDF using best available method."""
        docx_path = docx_path.resolve()
        pdf_path = pdf_path.resolve()

        if not docx_path.exists():
            logger.error(f"DOCX file not found: {docx_path}")
            return False

        logger.info(f"Converting {docx_path.name} to PDF")

        # Try each conversion method in order
        for method_name, method_func in self.conversion_methods:
            try:
                logger.debug(f"Trying conversion method: {method_name}")
                success = await method_func(docx_path, pdf_path)
                
                if success and pdf_path.exists():
                    logger.info(f"DOCX conversion successful using {method_name}: {pdf_path.name}")
                    return True
                else:
                    logger.debug(f"Method {method_name} failed or produced no output")
                    
            except Exception as e:
                logger.debug(f"Method {method_name} failed with error: {e}")
                continue

        logger.error(f"All conversion methods failed for: {docx_path.name}")
        return False

    async def _convert_with_word_com(self, docx_path: Path, pdf_path: Path) -> bool:
        """Convert using Microsoft Word COM API - Fixed threading issues."""
        if not WORD_CONVERSION_AVAILABLE:
            return False

        try:
            # Run COM operations in a separate thread to avoid threading issues
            success = await asyncio.to_thread(self._convert_com_sync, docx_path, pdf_path)
            return success

        except asyncio.TimeoutError:
            logger.warning(f"Word COM conversion timed out: {docx_path.name}")
            return False
        except Exception as e:
            logger.debug(f"Word COM conversion error: {e}")
            return False

    def _convert_com_sync(self, docx_path: Path, pdf_path: Path) -> bool:
        """Synchronous COM conversion - runs in separate thread."""
        word = None
        doc = None
        
        try:
            # Initialize COM for this thread
            comtypes.CoInitialize()
            
            # Create Word application
            word = comtypes.client.CreateObject("Word.Application")
            word.Visible = False
            word.DisplayAlerts = False
            
            # Open document
            doc = word.Documents.Open(
                str(docx_path),
                ReadOnly=True,
                AddToRecentFiles=False
            )
            
            # Save as PDF (format 17 = wdFormatPDF)
            doc.SaveAs2(str(pdf_path), FileFormat=17)
            
            return True
            
        except Exception as e:
            logger.debug(f"COM sync conversion error: {e}")
            return False
        finally:
            # Clean up resources
            try:
                if doc:
                    doc.Close(SaveChanges=False)
                if word:
                    word.Quit()
                comtypes.CoUninitialize()
            except:
                pass

    async def _convert_with_libreoffice(self, docx_path: Path, pdf_path: Path) -> bool:
        """Convert using LibreOffice command line."""
        try:
            # Check if LibreOffice is available
            libreoffice_paths = [
                "soffice",
                "libreoffice",
                r"C:\Program Files\LibreOffice\program\soffice.exe",
                r"C:\Program Files (x86)\LibreOffice\program\soffice.exe"
            ]
            
            soffice_path = None
            for path in libreoffice_paths:
                try:
                    result = await asyncio.to_thread(
                        subprocess.run, [path, "--version"],
                        capture_output=True, timeout=5,
                        creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
                    )
                    if result.returncode == 0:
                        soffice_path = path
                        break
                except:
                    continue

            if not soffice_path:
                return False

            # Convert with LibreOffice
            cmd = [
                soffice_path,
                "--headless",
                "--convert-to", "pdf",
                "--outdir", str(pdf_path.parent),
                str(docx_path)
            ]

            result = await asyncio.to_thread(
                subprocess.run, cmd,
                capture_output=True, text=True, timeout=60,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )

            # LibreOffice creates PDF with same name as input
            expected_pdf = pdf_path.parent / f"{docx_path.stem}.pdf"
            if expected_pdf.exists() and expected_pdf != pdf_path:
                expected_pdf.rename(pdf_path)

            return result.returncode == 0 and pdf_path.exists()

        except Exception as e:
            logger.debug(f"LibreOffice conversion error: {e}")
            return False

    async def _convert_with_powershell(self, docx_path: Path, pdf_path: Path) -> bool:
        """Convert using PowerShell with Word automation - More reliable than COM."""
        try:
            # Escape paths for PowerShell
            docx_escaped = str(docx_path).replace("'", "''")
            pdf_escaped = str(pdf_path).replace("'", "''")
            
            script = f'''
            try {{
                $ErrorActionPreference = "Stop"
                $word = New-Object -ComObject Word.Application
                $word.Visible = $false
                $word.DisplayAlerts = 0
                
                $doc = $word.Documents.Open('{docx_escaped}', $false, $true)
                $doc.SaveAs2('{pdf_escaped}', 17)
                $doc.Close($false)
                $word.Quit()
                
                [System.Runtime.Interopservices.Marshal]::ReleaseComObject($doc) | Out-Null
                [System.Runtime.Interopservices.Marshal]::ReleaseComObject($word) | Out-Null
                [System.GC]::Collect()
                [System.GC]::WaitForPendingFinalizers()
                
                Write-Output "Conversion successful"
                exit 0
            }} catch {{
                Write-Error "Conversion failed: $($_.Exception.Message)"
                if ($word) {{ 
                    try {{ $word.Quit() }} catch {{}}
                }}
                exit 1
            }}
            '''

            result = await asyncio.to_thread(
                subprocess.run, 
                ["powershell", "-ExecutionPolicy", "Bypass", "-Command", script],
                capture_output=True, text=True, timeout=60,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )

            if result.returncode == 0 and pdf_path.exists():
                logger.debug(f"PowerShell conversion successful: {result.stdout.strip()}")
                return True
            else:
                logger.debug(f"PowerShell conversion failed: {result.stderr}")
                return False

        except Exception as e:
            logger.debug(f"PowerShell conversion error: {e}")
            return False

    async def _copy_as_fallback(self, docx_path: Path, pdf_path: Path) -> bool:
        """Fallback: copy DOCX as-is but rename to PDF (for basic printing support)."""
        try:
            logger.warning(f"No conversion method available - copying {docx_path.name} as PDF")
            logger.warning("File may not print correctly without proper conversion")
            
            # Copy the file
            await asyncio.to_thread(pdf_path.write_bytes, docx_path.read_bytes())
            return pdf_path.exists()

        except Exception as e:
            logger.debug(f"Fallback copy error: {e}")
            return False

    async def cleanup(self):
        """Clean up resources - simplified since we don't hold persistent COM objects."""
        try:
            logger.debug("DocX converter cleanup completed")
        except Exception as e:
            logger.debug(f"Error during cleanup: {e}")

    def get_available_methods(self) -> list:
        """Get list of available conversion methods."""
        methods = []
        
        methods.append("PowerShell (if Word installed)")
        
        if WORD_CONVERSION_AVAILABLE:
            methods.append("Microsoft Word COM")
        
        # Check LibreOffice
        try:
            subprocess.run(["soffice", "--version"], 
                         capture_output=True, timeout=2,
                         creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0)
            methods.append("LibreOffice")
        except:
            pass
        
        methods.append("Copy as fallback")
        
        return methods
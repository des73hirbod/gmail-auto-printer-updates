#!/usr/bin/env python3
"""
Gmail Auto Printer - Production Ready
Main application entry point with complete error handling and production features.
FIXED: DOCX converter initialization
"""
import asyncio
import argparse
import logging
import sys
import os
import signal
import traceback
import time
from pathlib import Path

# Core modules
from config import Config, ConfigValidationError
from gmail_client import GmailClient
from attachment_handler import AttachmentHandler
from printer_manager import PrinterManager
from docx_to_pdf_converter import DocxToPDFConverter  # Add this import
from auto_updater import AutoUpdater
from error_notifier import ErrorNotifier
from environment_checker import EnvironmentChecker
from logger_config import setup_logging
from utils import SystemUtils
from constants import APP_VERSION, APP_NAME

logger = logging.getLogger(__name__)

class GmailAutoPrinter:
    """Main application class for Gmail Auto Printer."""
    
    def __init__(self, config: Config, no_updates: bool):
        self.config = config
        self.no_updates = no_updates
        self.running = True
        self.error_notifier = None
        self.auto_updater = None
        self.gmail_client = None
        self.attachment_handler = None
        self.printer_manager = None
        self.docx_converter = None  # Add this line

    async def initialize(self):
        """Initialize all components."""
        try:
            logger.info("Initializing Gmail Auto Printer components...")
            
            # Error notifier (initialize first for error reporting)
            self.error_notifier = ErrorNotifier(self.config)
            logger.debug("Error notifier initialized")
            
            # Auto updater
            if self.config.ENABLE_AUTO_UPDATE and not self.no_updates:
                self.auto_updater = AutoUpdater(self.config, self.error_notifier)
                logger.debug("Auto updater initialized")
                try:
                    await asyncio.wait_for(self.auto_updater.check_for_updates(), timeout=30)
                except asyncio.TimeoutError:
                    logger.warning("Update check timed out, continuing with startup")
                    await self.error_notifier.send_error_notification(
                        "Auto Update Timeout",
                        "Update check timed out after 30 seconds",
                        traceback.format_exc(),
                        error_type="auto_update"
                    )
                except Exception as e:
                    logger.warning(f"Update check failed: {e}")
                    await self.error_notifier.send_error_notification(
                        "Auto Update Failure",
                        f"Failed to check for updates: {str(e)}",
                        traceback.format_exc(),
                        error_type="auto_update"
                    )
            
            # Gmail client
            self.gmail_client = GmailClient(self.config)
            logger.debug("Gmail client initialized")
            
            # DOCX Converter (FIXED: Initialize before printer manager)
            self.docx_converter = DocxToPDFConverter()
            logger.debug("DOCX converter initialized")
            
            # Printer manager
            self.printer_manager = PrinterManager(
                printer_name=self.config.PRINTER_NAME,
                sumatra_pdf_path=Path(self.config.SUMATRA_PDF_PATH),
                debug_mode=True  # Enable debug mode to retain PDFs
            )
            
            # FIXED: Set the DOCX converter in printer manager
            self.printer_manager.docx_converter = self.docx_converter
            logger.debug("Printer manager initialized with DOCX converter")
            
            # Attachment handler
            self.attachment_handler = AttachmentHandler(
                self.config, 
                self.gmail_client, 
                self.printer_manager,
                self.error_notifier
            )
            logger.debug("Attachment handler initialized")
            
            logger.info("✅ All components initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize components: {e}")
            if self.error_notifier:
                await self.error_notifier.send_error_notification(
                    "System Initialization Failed",
                    str(e),
                    traceback.format_exc(),
                    error_type="initialization"
                )
            raise

    async def process_emails(self):
        """Main email processing loop with timeout protection."""
        processed_count = 0
        error_count = 0
        last_error_notification = 0
        ERROR_NOTIFICATION_COOLDOWN = 1800  # 30 minutes
        OPERATION_TIMEOUT = 300  # 5 minutes per operation

        logger.info("🚀 Starting email processing loop...")

        while self.running:
            try:
                # Add timeout to prevent getting stuck
                try:
                    messages = await asyncio.wait_for(
                        self.gmail_client.get_unread_emails(), 
                        timeout=OPERATION_TIMEOUT
                    )
                except asyncio.TimeoutError:
                    logger.error(f"⏰ Gmail API timeout after {OPERATION_TIMEOUT} seconds")
                    if self.error_notifier:
                        await self.error_notifier.send_error_notification(
                            "Gmail API Timeout",
                            f"Gmail API call timed out after {OPERATION_TIMEOUT} seconds",
                            traceback.format_exc(),
                            error_type="gmail_timeout"
                        )
                    if self.config.RUN_ONCE:
                        logger.info("Run-once mode: Timeout occurred, exiting")
                        break
                    await asyncio.sleep(self.config.POLL_INTERVAL_SECONDS)
                    continue
                
                if not messages:
                    logger.debug("No unread emails found")
                    if self.config.RUN_ONCE:
                        logger.info("Run-once mode: No emails to process, exiting")
                        break
                    
                    sleep_time = min(self.config.POLL_INTERVAL_SECONDS, 10) if self.config.RUN_ONCE else self.config.POLL_INTERVAL_SECONDS
                    logger.debug(f"Sleeping for {sleep_time} seconds before next poll")
                    await asyncio.sleep(sleep_time)
                    continue

                logger.info(f"📧 Found {len(messages)} unread emails to process")

                # Load processed IDs to avoid duplicates
                processed_ids = SystemUtils.load_processed_ids(self.config.PROCESSED_IDS_FILE)

                for i, message in enumerate(messages, 1):
                    if not self.running:
                        break

                    message_id = message['id']
                    logger.info(f"Processing email {i}/{len(messages)}: {message_id}")

                    # Skip already processed emails
                    if message_id in processed_ids:
                        logger.debug(f"⏭️  Skipping already processed email: {message_id}")
                        continue

                    try:
                        # Get email details with timeout
                        try:
                            email_data = await asyncio.wait_for(
                                self.gmail_client.get_email(message_id),
                                timeout=60
                            )
                        except asyncio.TimeoutError:
                            logger.error(f"⏰ Email fetch timeout for {message_id}")
                            error_count += 1
                            continue
                        
                        if not email_data:
                            logger.warning(f"No email data received for {message_id}")
                            error_count += 1
                            continue
                        
                        # Process attachments with timeout
                        try:
                            attachment_count = await asyncio.wait_for(
                                self.attachment_handler.download_attachments(message_id, email_data),
                                timeout=180
                            )
                        except asyncio.TimeoutError:
                            logger.error(f"⏰ Attachment processing timeout for {message_id}")
                            error_count += 1
                            continue

                        if attachment_count > 0:
                            logger.info(f"✅ Successfully processed {attachment_count} attachments from email {message_id}")
                            processed_count += attachment_count
                        else:
                            logger.info(f"📎 No valid attachments found in email {message_id}")

                        # Move email to trash (unless dry run) with timeout
                        try:
                            if not self.config.DRY_RUN:
                                await asyncio.wait_for(
                                    self.gmail_client.trash_email(message_id),
                                    timeout=30
                                )
                                SystemUtils.save_processed_id(self.config.PROCESSED_IDS_FILE, message_id)
                                logger.debug(f"Email {message_id} moved to trash and marked as processed")
                            else:
                                logger.info(f"DRY-RUN: Would trash email {message_id}")
                        except asyncio.TimeoutError:
                            logger.error(f"⏰ Email trash timeout for {message_id}")
                            if not self.config.DRY_RUN:
                                SystemUtils.save_processed_id(self.config.PROCESSED_IDS_FILE, message_id)

                    except Exception as e:
                        error_count += 1
                        logger.error(f"❌ Failed to process email {message_id}: {e}")
                        
                        current_time = time.time()
                        if current_time - last_error_notification > ERROR_NOTIFICATION_COOLDOWN:
                            if self.error_notifier:
                                await self.error_notifier.send_error_notification(
                                    f"Email Processing Error (ID: {message_id})",
                                    str(e),
                                    traceback.format_exc(),
                                    error_type="email_processing"
                                )
                            last_error_notification = current_time

                # Update error count with attachment handler stats
                stats = self.attachment_handler.get_stats()
                error_count += stats.get('validation_failures', 0) + stats.get('print_failures', 0)

                if self.config.RUN_ONCE:
                    logger.info("Run-once mode: Processing complete, exiting")
                    break

                logger.debug(f"Sleeping for {self.config.POLL_INTERVAL_SECONDS} seconds before next poll")
                await asyncio.sleep(self.config.POLL_INTERVAL_SECONDS)

            except KeyboardInterrupt:
                logger.info("⏹️  Received interrupt signal, shutting down...")
                self.running = False
                break

            except Exception as e:
                error_count += 1
                logger.error(f"❌ Error in main processing loop: {e}")
                logger.error(traceback.format_exc())
                
                if self.error_notifier:
                    await self.error_notifier.send_error_notification(
                        "Critical Processing Loop Error",
                        str(e),
                        traceback.format_exc(),
                        error_type="processing_loop"
                    )

                if not self.config.RUN_ONCE:
                    logger.info("Waiting 30 seconds before retry...")
                    await asyncio.sleep(30)
                else:
                    break

        logger.info(f"📊 Processing complete. Processed: {processed_count}, Errors: {error_count}")

    async def cleanup(self):
        """Cleanup resources."""
        try:
            logger.info("🧹 Cleaning up resources...")
            if self.docx_converter:  # Add cleanup for DOCX converter
                await self.docx_converter.cleanup()
            if self.printer_manager:
                await self.printer_manager.cleanup()
            if self.attachment_handler:
                await self.attachment_handler.cleanup()
            logger.info("✅ Cleanup completed successfully")
        except Exception as e:
            logger.error(f"❌ Error during cleanup: {e}")
            if self.error_notifier:
                await self.error_notifier.send_error_notification(
                    "Cleanup Error",
                    str(e),
                    traceback.format_exc(),
                    error_type="cleanup"
                )

    def setup_signal_handlers(self):
        """Setup signal handlers for graceful shutdown."""
        def signal_handler(signum, frame):
            logger.info(f"Received signal {signum}, initiating shutdown...")
            self.running = False
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)


async def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description=f"{APP_NAME} - Production Ready")
    parser.add_argument("--dry-run", action="store_true", help="Simulate actions without making changes")
    parser.add_argument("--once", action="store_true", help="Run once and exit")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    parser.add_argument("--skip-env-check", action="store_true", help="Skip environment validation")
    parser.add_argument("--no-updates", action="store_true", help="Disable auto-updates")
    parser.add_argument("--version", action="version", version=f"{APP_NAME} v{APP_VERSION}")
    
    args = parser.parse_args()
    app = None

    try:
        # Setup logging
        log_level = 'DEBUG' if args.debug else 'INFO'
        setup_logging(log_level=log_level)
        
        logger.info("=" * 60)
        logger.info(f"🚀 {APP_NAME} v{APP_VERSION} Starting")
        logger.info("=" * 60)
        logger.info(f"Python version: {sys.version}")
        logger.info(f"Arguments: {vars(args)}")

        # Load configuration
        try:
            config = Config(
                dry_run=args.dry_run,
                run_once=args.once
            )
            logger.info("✅ Configuration loaded successfully")
            
            config_summary = config.get_summary()
            logger.info("📋 Configuration Summary:")
            for key, value in config_summary.items():
                logger.info(f"   {key}: {value}")
            
        except ConfigValidationError as e:
            logger.error(f"❌ Configuration validation failed:")
            for line in str(e).split('\n'):
                if line.strip():
                    logger.error(f"   {line}")
            sys.exit(1)

        # Initialize error notifier for environment check
        error_notifier = ErrorNotifier(config)

        # Environment check
        if not args.skip_env_check:
            logger.info("🔍 Running environment checks...")
            env_checker = EnvironmentChecker(config)
            if not await env_checker.check_all():
                logger.error("❌ Environment check failed. Use --skip-env-check to bypass.")
                await error_notifier.send_error_notification(
                    "Environment Check Failure",
                    "Environment check failed. Check logs for details.",
                    traceback.format_exc(),
                    error_type="environment_check"
                )
                sys.exit(1)
            logger.info("✅ Environment checks passed")

        # Initialize and run application
        app = GmailAutoPrinter(config, args.no_updates)
        app.setup_signal_handlers()
        
        try:
            await asyncio.wait_for(app.initialize(), timeout=120)
        except asyncio.TimeoutError:
            logger.error("⏰ Application initialization timed out")
            sys.exit(1)
        
        if config.RUN_ONCE:
            try:
                await asyncio.wait_for(app.process_emails(), timeout=600)
            except asyncio.TimeoutError:
                logger.error("⏰ Email processing timed out in run-once mode")
                sys.exit(1)
        else:
            await app.process_emails()
        
        logger.info("=" * 60)
        logger.info(f"✅ {APP_NAME} Shutdown Complete")
        logger.info("=" * 60)

    except KeyboardInterrupt:
        logger.info("⏹️  Application interrupted by user")
        sys.exit(0)

    except Exception as e:
        logger.error(f"💥 Fatal application error: {e}")
        logger.error(traceback.format_exc())
        
        try:
            if app and app.error_notifier:
                await app.error_notifier.send_error_notification(
                    "Fatal Application Error",
                    str(e),
                    traceback.format_exc(),
                    error_type="fatal"
                )
            elif 'error_notifier' in locals():
                await error_notifier.send_error_notification(
                    "Fatal Application Error",
                    str(e),
                    traceback.format_exc(),
                    error_type="fatal"
                )
        except:
            pass
        
        sys.exit(1)

    finally:
        if app:
            await app.cleanup()


if __name__ == '__main__':
    if hasattr(sys, '_MEIPASS'):
        os.chdir(sys._MEIPASS)
    else:
        os.chdir(Path(__file__).parent)
    
    if sys.platform.startswith('win'):
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    
    asyncio.run(main())
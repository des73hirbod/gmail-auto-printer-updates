"""
DOCX to PDF converter using Microsoft Word COM or alternative methods.
FIXED: Added retry logic for COM operations, suppressed Word dialogs, and improved cleanup to prevent disconnection errors.
"""
import logging
import asyncio
from pathlib import Path
import win32com.client
import pythoncom
import time
from utils import SystemUtils

logger = logging.getLogger(__name__)

class DocxConverter:
    """Handles conversion of DOCX files to PDF using Microsoft Word."""

    def __init__(self):
        self.word = None
        self.initialized = False
        self.max_retries = 3
        self.retry_delay = 2  # seconds

    async def initialize(self):
        """Initialize the Word COM object with retry logic."""
        for attempt in range(self.max_retries):
            try:
                pythoncom.CoInitialize()
                self.word = win32com.client.Dispatch("Word.Application")
                self.word.Visible = False
                self.word.DisplayAlerts = False  # Suppress Word dialogs
                self.initialized = True
                logger.info("Microsoft Word initialized for DOCX conversion")
                return
            except Exception as e:
                logger.error(f"Failed to initialize Word COM object (attempt {attempt + 1}/{self.max_retries}): {e}")
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(self.retry_delay)
                else:
                    raise Exception(f"Failed to initialize Word COM after {self.max_retries} attempts: {e}")
            finally:
                if not self.initialized and self.word:
                    try:
                        self.word.Quit()
                    except:
                        pass
                    self.word = None
                    pythoncom.CoUninitialize()

    async def convert_to_pdf(self, docx_path: Path, pdf_path: Path) -> bool:
        """Convert a DOCX file to PDF with retry logic."""
        if not self.initialized:
            logger.error("DocxConverter not initialized")
            return False

        docx_path = docx_path.resolve()
        pdf_path = pdf_path.resolve()
        logger.debug(f"Converting {docx_path} to {pdf_path}")

        for attempt in range(self.max_retries):
            doc = None
            try:
                doc = self.word.Documents.Open(str(docx_path))
                doc.SaveAs(str(pdf_path), FileFormat=17)  # 17 = wdFormatPDF
                doc.Close()
                logger.info(f"Converted {docx_path.name} to PDF")
                return True
            except Exception as e:
                logger.error(f"Failed to convert {docx_path.name} to PDF (attempt {attempt + 1}/{self.max_retries}): {e}")
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(self.retry_delay)
                else:
                    logger.error(f"Failed to convert {docx_path.name} after {self.max_retries} attempts")
                    return False
            finally:
                if doc:
                    try:
                        doc.Close(SaveChanges=False)
                    except:
                        pass

        return False

    async def cleanup(self):
        """Clean up Word COM resources."""
        try:
            if self.word:
                self.word.Quit()
                self.word = None
            pythoncom.CoUninitialize()
            logger.debug("DocxConverter cleaned up")
        except Exception as e:
            logger.error(f"Error during DocxConverter cleanup: {e}")
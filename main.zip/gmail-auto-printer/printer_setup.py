#!/usr/bin/env python3
"""
Printer Setup Utility for Gmail Auto Printer
Helps detect and configure printers for the application.
"""
import subprocess
import sys
import os
from pathlib import Path
from typing import List, Dict, Optional

def get_available_printers() -> List[Dict[str, str]]:
    """Get all available printers with detailed information."""
    printers = []
    
    # Method 1: PowerShell with detailed info
    try:
        cmd = [
            "powershell", "-Command",
            "Get-Printer | Select-Object Name, PrinterStatus, DriverName, PortName | ConvertTo-Json"
        ]
        
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=15,
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
        )
        
        if result.returncode == 0 and result.stdout.strip():
            import json
            try:
                data = json.loads(result.stdout)
                if isinstance(data, dict):
                    data = [data]  # Single printer
                
                for printer in data:
                    printers.append({
                        'name': printer.get('Name', 'Unknown'),
                        'status': printer.get('PrinterStatus', 'Unknown'),
                        'driver': printer.get('DriverName', 'Unknown'),
                        'port': printer.get('PortName', 'Unknown')
                    })
            except json.JSONDecodeError:
                # Fallback to simple list
                names = [p.strip() for p in result.stdout.strip().split('\n') if p.strip()]
                printers = [{'name': name, 'status': 'Unknown', 'driver': 'Unknown', 'port': 'Unknown'} for name in names]
    
    except Exception as e:
        print(f"PowerShell detection failed: {e}")
    
    # Fallback method if PowerShell failed
    if not printers:
        try:
            cmd = ["wmic", "printer", "get", "name", "/format:value"]
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=15,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if line.startswith('Name=') and '=' in line:
                        printer_name = line.split('=', 1)[1].strip()
                        if printer_name:
                            printers.append({
                                'name': printer_name,
                                'status': 'Unknown',
                                'driver': 'Unknown',
                                'port': 'Unknown'
                            })
        except Exception as e:
            print(f"WMI fallback failed: {e}")
    
    return printers

def test_printer(printer_name: str) -> Dict[str, str]:
    """Test if a printer is working and get its capabilities."""
    results = {
        'accessible': False,
        'status': 'Unknown',
        'duplex_support': 'Unknown',
        'error': None
    }
    
    try:
        # Check printer status
        cmd = [
            "powershell", "-Command",
            f"Get-Printer -Name '{printer_name}' -ErrorAction SilentlyContinue | Select-Object PrinterStatus"
        ]
        
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=10,
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
        )
        
        if result.returncode == 0:
            results['accessible'] = True
            status = result.stdout.strip()
            if '0' in status:
                results['status'] = 'Normal'
            else:
                results['status'] = status or 'Unknown'
        
        # Check duplex support
        cmd = [
            "powershell", "-Command",
            f"Get-PrinterProperty -PrinterName '{printer_name}' -ErrorAction SilentlyContinue | Where-Object {{$_.PropertyName -like '*duplex*'}}"
        ]
        
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=10,
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
        )
        
        if result.returncode == 0 and result.stdout.strip():
            results['duplex_support'] = 'Yes' if 'true' in result.stdout.lower() else 'No'
        else:
            results['duplex_support'] = 'No'
            
    except Exception as e:
        results['error'] = str(e)
    
    return results

def get_current_config() -> Dict[str, str]:
    """Get current printer configuration from .env file."""
    config = {
        'PRINTER_NAME': None,
        'ENABLE_DUPLEX': None,
        'found_env': False
    }
    
    env_file = Path('.env')
    if env_file.exists():
        config['found_env'] = True
        try:
            with open(env_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line.startswith('PRINTER_NAME='):
                        config['PRINTER_NAME'] = line.split('=', 1)[1].strip()
                    elif line.startswith('ENABLE_DUPLEX='):
                        config['ENABLE_DUPLEX'] = line.split('=', 1)[1].strip()
        except Exception as e:
            print(f"Error reading .env file: {e}")
    
    return config

def update_env_file(printer_name: str):
    """Update the .env file with the selected printer."""
    env_file = Path('.env')
    
    if not env_file.exists():
        print("❌ .env file not found. Please copy .env.template to .env first.")
        return False
    
    try:
        # Read current content
        lines = []
        with open(env_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # Update PRINTER_NAME line
        updated = False
        for i, line in enumerate(lines):
            if line.strip().startswith('PRINTER_NAME='):
                lines[i] = f'PRINTER_NAME={printer_name}\n'
                updated = True
                break
        
        # If not found, add it
        if not updated:
            lines.append(f'PRINTER_NAME={printer_name}\n')
        
        # Write back
        with open(env_file, 'w', encoding='utf-8') as f:
            f.writelines(lines)
        
        print(f"✅ Updated .env file with PRINTER_NAME={printer_name}")
        return True
        
    except Exception as e:
        print(f"❌ Error updating .env file: {e}")
        return False

def install_print_to_pdf():
    """Guide user through installing Microsoft Print to PDF."""
    print("\n📖 HOW TO INSTALL MICROSOFT PRINT TO PDF:")
    print("=" * 50)
    print("1. Open Windows Settings (Win + I)")
    print("2. Go to 'Devices' > 'Printers & scanners'")
    print("3. Click 'Add a printer or scanner'")
    print("4. Wait for scan, then click 'The printer that I want isn't listed'")
    print("5. Select 'Add a local printer or network printer...'")
    print("6. Choose 'Use an existing port' > 'FILE: (Print to File)'")
    print("7. In manufacturer list, select 'Microsoft'")
    print("8. In printer list, select 'Microsoft Print To PDF'")
    print("9. Click 'Next' and follow remaining prompts")
    print("10. Optionally set as default printer")
    print("=" * 50)
    print("After installation, run this script again to verify!")

def main():
    print("🖨️  Gmail Auto Printer - Printer Setup Utility")
    print("=" * 50)
    
    # Get current configuration
    config = get_current_config()
    
    if config['found_env']:
        print(f"📋 Current configuration:")
        print(f"   PRINTER_NAME: {config['PRINTER_NAME'] or 'Not set'}")
        print(f"   ENABLE_DUPLEX: {config['ENABLE_DUPLEX'] or 'Not set'}")
    else:
        print("⚠️  No .env file found. Please copy .env.template to .env first.")
        return
    
    print("\n🔍 Scanning for available printers...")
    printers = get_available_printers()
    
    if not printers:
        print("❌ No printers found on your system!")
        print("\nPossible solutions:")
        print("1. Install Microsoft Print to PDF (recommended)")
        print("2. Install any physical printer")
        print("3. Check Windows printer settings")
        
        choice = input("\nWould you like installation instructions for Microsoft Print to PDF? (y/n): ").lower()
        if choice == 'y':
            install_print_to_pdf()
        return
    
    print(f"\n✅ Found {len(printers)} printer(s):")
    print("-" * 50)
    
    for i, printer in enumerate(printers, 1):
        print(f"{i}. {printer['name']}")
        print(f"   Status: {printer['status']}")
        print(f"   Driver: {printer['driver']}")
        print(f"   Port: {printer['port']}")
        
        # Test the printer
        test_results = test_printer(printer['name'])
        if test_results['accessible']:
            print(f"   ✅ Accessible - Status: {test_results['status']}")
            print(f"   Duplex Support: {test_results['duplex_support']}")
        else:
            print(f"   ❌ Not accessible: {test_results.get('error', 'Unknown error')}")
        print()
    
    # Check current configuration
    if config['PRINTER_NAME']:
        current_printer = config['PRINTER_NAME']
        printer_names = [p['name'] for p in printers]
        
        if current_printer in printer_names:
            print(f"✅ Your current printer '{current_printer}' was found!")
            test_results = test_printer(current_printer)
            if test_results['accessible']:
                print("✅ Printer is accessible and should work.")
                print("\nYour printer setup appears to be correct!")
                return
            else:
                print(f"❌ Printer is not accessible: {test_results.get('error', 'Unknown error')}")
        else:
            print(f"❌ Your current printer '{current_printer}' was NOT found!")
    
    # Let user select a printer
    print("\nSelect a printer to use:")
    print("0. Exit without changes")
    
    while True:
        try:
            choice = input(f"Enter choice (0-{len(printers)}): ").strip()
            
            if choice == '0':
                print("No changes made.")
                return
            
            choice_num = int(choice)
            if 1 <= choice_num <= len(printers):
                selected_printer = printers[choice_num - 1]
                break
            else:
                print(f"Please enter a number between 0 and {len(printers)}")
                
        except ValueError:
            print("Please enter a valid number")
    
    # Test selected printer
    print(f"\n🧪 Testing printer: {selected_printer['name']}")
    test_results = test_printer(selected_printer['name'])
    
    if test_results['accessible']:
        print("✅ Printer test successful!")
        print(f"   Status: {test_results['status']}")
        print(f"   Duplex Support: {test_results['duplex_support']}")
        
        # Update .env file
        if update_env_file(selected_printer['name']):
            print("\n🎉 Printer setup complete!")
            print("You can now run the Gmail Auto Printer without printer errors.")
            print("\nNext steps:")
            print("1. Test with: python main.py --dry-run --debug --once")
            print("2. Run production: python main.py --once")
        
    else:
        print(f"❌ Printer test failed: {test_results.get('error', 'Unknown error')}")
        print("This printer may not work properly with the application.")
        
        choice = input("Do you still want to use this printer? (y/n): ").lower()
        if choice == 'y':
            update_env_file(selected_printer['name'])

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nSetup cancelled.")
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        print("Please check your Windows printer settings and try again.")
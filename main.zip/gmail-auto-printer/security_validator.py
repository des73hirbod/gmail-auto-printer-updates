"""
Security validation for email attachments with comprehensive checks.
"""
import re
import socket
import logging
from pathlib import Path
from typing import Dict, Tuple
from dataclasses import dataclass

from config import Config
from malware_scanner import MalwareScanner
from constants import FILE_HEADERS
from utils import SystemUtils

logger = logging.getLogger(__name__)

@dataclass
class ValidationResult:
    """Result of security validation."""
    is_valid: bool
    details: str

class SecurityValidator:
    """Comprehensive security validator for email attachments."""
    
    DANGEROUS_PATTERNS = {
        '..', './', '.\\', '../', '..\\',
        '/', '\\', ':', '|', '<', '>', '"', '*', '?'
    }
    
    RESERVED_NAMES = {
        'CON', 'PRN', 'AUX', 'NUL', 'CLOCK$',
        'COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7', 'COM8', 'COM9',
        'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9'
    }
    
    EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    
    def __init__(self, config: Config, error_notifier):
        self.config = config
        self.error_notifier = error_notifier
        self.malware_scanner = MalwareScanner(config, error_notifier)
        
        self.validation_stats = {
            'total_validations': 0,
            'sender_rejections': 0,
            'filename_rejections': 0,
            'filetype_rejections': 0,
            'malware_detections': 0
        }

    async def validate_attachment(self, sender_email: str, filename: str, file_path: Path) -> Dict:
        """Validate attachment through all security checks."""
        self.validation_stats['total_validations'] += 1
        
        try:
            logger.debug(f"🔍 Security validation starting for: {filename}")
            
            # Step 1: Validate sender
            if not self._validate_sender(sender_email):
                self.validation_stats['sender_rejections'] += 1
                await self.error_notifier.send_error_notification(
                    title="Sender Validation Failure",
                    error_message=f"Invalid sender email: {sender_email}",
                    stack_trace="",
                    error_type="validation_failure"
                )
                return ValidationResult(False, "Invalid sender email").__dict__
            
            # Step 2: Validate filename
            if not self._validate_filename(filename):
                self.validation_stats['filename_rejections'] += 1
                await self.error_notifier.send_error_notification(
                    title="Filename Validation Failure",
                    error_message=f"Invalid filename: {filename}",
                    stack_trace="",
                    error_type="validation_failure"
                )
                return ValidationResult(False, "Invalid filename").__dict__
            
            # Step 3: Validate file type and headers
            if not await self._validate_file_type(filename, file_path):
                self.validation_stats['filetype_rejections'] += 1
                await self.error_notifier.send_error_notification(
                    title="File Type Validation Failure",
                    error_message=f"Invalid file type or headers: {filename}",
                    stack_trace="",
                    error_type="validation_failure"
                )
                return ValidationResult(False, "Invalid file type or headers").__dict__
            
            # Step 4: Malware scan
            if self.config.ENABLE_MALWARE_SCAN and not self.config.DISABLE_MALWARE_SCAN:
                if not await self.malware_scanner.scan_file(file_path):
                    self.validation_stats['malware_detections'] += 1
                    return ValidationResult(False, "Malware scan failed").__dict__
            
            logger.debug(f"✅ Security validation passed: {SystemUtils.sanitize_log_input(filename)}")
            return ValidationResult(True, "All security checks passed").__dict__
            
        except Exception as e:
            logger.error(f"Security validation error for {SystemUtils.sanitize_log_input(filename)}: {e}")
            await self.error_notifier.send_error_notification(
                title="Security Validation Error",
                error_message=f"Security validation error for {filename}: {str(e)}",
                stack_trace="",
                error_type="validation_failure"
            )
            return ValidationResult(False, f"Validation error: {str(e)}").__dict__

    def _validate_sender(self, sender_email: str) -> bool:
        """Validate email sender with security checks."""
        try:
            if not sender_email or not isinstance(sender_email, str):
                return False
            
            sender_email = sender_email.strip()
            
            email_match = re.search(r'<([^>]+)>', sender_email)
            if email_match:
                actual_email = email_match.group(1).strip()
                display_name = sender_email.split('<')[0].strip()
                
                if any(char in display_name for char in ['<', '>', '\n', '\r', '\0']):
                    logger.warning(f"Suspicious display name: {SystemUtils.sanitize_log_input(display_name)}")
                    return False
            else:
                actual_email = sender_email
            
            if not self.EMAIL_REGEX.match(actual_email):
                logger.warning(f"Invalid email format: {SystemUtils.sanitize_log_input(actual_email)}")
                return False
            
            if len(actual_email) > 254:
                logger.warning(f"Email address too long: {len(actual_email)} chars")
                return False
            
            if '..' in actual_email or actual_email.startswith('.') or actual_email.endswith('.'):
                logger.warning(f"Suspicious email pattern: {SystemUtils.sanitize_log_input(actual_email)}")
                return False
            
            domain = actual_email.split('@')[-1].lower()
            
            if self.config.ENABLE_DNS_VALIDATION:
                if not self._validate_domain_dns(domain):
                    return False
            
            if self.config.ALLOWED_SENDER_DOMAINS:
                domain_allowed = any(
                    domain == allowed_domain or domain.endswith('.' + allowed_domain)
                    for allowed_domain in self.config.ALLOWED_SENDER_DOMAINS
                )
                if not domain_allowed:
                    logger.info(f"Email from non-whitelisted domain: {domain}")
                    return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error validating sender {SystemUtils.sanitize_log_input(sender_email)}: {e}")
            return False

    def _validate_domain_dns(self, domain: str) -> bool:
        """Validate domain via DNS lookup."""
        try:
            socket.setdefaulttimeout(3)
            socket.gethostbyname(domain)
            logger.debug(f"DNS validation passed: {domain}")
            return True
        except (socket.gaierror, socket.timeout):
            logger.warning(f"DNS validation failed: {domain}")
            return False
        finally:
            socket.setdefaulttimeout(None)

    def _validate_filename(self, filename: str) -> bool:
        """Comprehensive filename validation."""
        if not isinstance(filename, str) or not filename.strip():
            return False
        
        try:
            decoded_filename = SystemUtils.decode_email_header(filename).strip()
            
            if '\0' in decoded_filename:
                logger.warning(f"Filename contains null byte: {SystemUtils.sanitize_log_input(filename)}")
                return False
            
            control_chars = [c for c in decoded_filename if ord(c) < 32 or (127 <= ord(c) <= 159)]
            if control_chars:
                logger.warning(f"Filename contains control characters")
                return False
            
            for pattern in self.DANGEROUS_PATTERNS:
                if pattern in decoded_filename:
                    logger.warning(f"Filename contains dangerous pattern: {pattern}")
                    return False
            
            if len(decoded_filename.encode('utf-8')) > 255:
                logger.warning(f"Filename too long: {len(decoded_filename)} chars")
                return False
            
            name_without_ext = decoded_filename.upper()
            if '.' in name_without_ext:
                name_without_ext = name_without_ext.rsplit('.', 1)[0]
            
            if name_without_ext in self.RESERVED_NAMES:
                logger.warning(f"Filename uses reserved name: {name_without_ext}")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error validating filename: {e}")
            return False

    async def _validate_file_type(self, filename: str, file_path: Path) -> bool:
        """Validate file type with header checking."""
        try:
            if self.config.ALLOW_ALL_FILE_TYPES:
                return True
            
            file_ext = SystemUtils.get_file_extension(filename)
            if not file_ext:
                logger.warning(f"File has no extension: {SystemUtils.sanitize_log_input(filename)}")
                return False
            
            allowed_extensions = [ext.lower() for ext in self.config.ALLOWED_FILE_TYPES]
            if file_ext.lower() not in allowed_extensions:
                logger.warning(f"File type '{file_ext}' not in allowed list: {allowed_extensions}")
                return False
            
            if not await self._validate_file_headers(file_path, file_ext):
                logger.warning(f"File header validation failed: {SystemUtils.sanitize_log_input(filename)}")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error validating file type: {e}")
            return False

    async def _validate_file_headers(self, file_path: Path, file_ext: str) -> bool:
        """Validate file headers match expected type."""
        try:
            if not file_path.exists():
                return False
            
            file_size = file_path.stat().st_size
            if file_size == 0:
                return file_ext.lower() in ['txt', 'log', 'csv']
            
            header_size = min(file_size, FILE_HEADERS.get('FILE_HEADER_READ_BYTES', 512))
            header_bytes = file_path.read_bytes()[:header_size]
            
            expected_headers = FILE_HEADERS.get(file_ext.lower(), [])
            if expected_headers:
                header_match = any(header_bytes.startswith(header) for header in expected_headers)
                if not header_match:
                    logger.warning(f"Header mismatch for {file_ext}. Got: {header_bytes[:16].hex()}")
                    return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error validating file headers: {e}")
            return False

    def get_validation_stats(self) -> Dict:
        """Get validation statistics."""
        stats = self.validation_stats.copy()
        stats['malware_scanner'] = self.malware_scanner.get_stats()
        return stats
#!/usr/bin/env python3
"""
Gmail Auto Printer - Launch Fixer
Quick fix script to ensure the application is launch-ready.
"""
import sys
import os
import shutil
from pathlib import Path

def fix_malware_scanner():
    """Fix the malware scanner syntax error."""
    malware_file = Path("malware_scanner.py")
    
    if not malware_file.exists():
        print("❌ malware_scanner.py not found")
        return False
    
    try:
        # Read the file
        content = malware_file.read_text(encoding='utf-8')
        
        # Find and fix the syntax error
        if "PRINTER_NAME=Microsoft Print to PDF" in content:
            print("🔧 Fixing syntax error in malware_scanner.py...")
            
            # Remove the erroneous configuration section
            lines = content.split('\n')
            fixed_lines = []
            skip_section = False
            
            for line in lines:
                if "# === .env.template ===" in line:
                    skip_section = True
                    break
                if not skip_section:
                    fixed_lines.append(line)
            
            # Write the fixed content
            fixed_content = '\n'.join(fixed_lines)
            malware_file.write_text(fixed_content, encoding='utf-8')
            print("✅ Syntax error fixed")
            return True
        else:
            print("✅ No syntax error found")
            return True
            
    except Exception as e:
        print(f"❌ Error fixing malware_scanner.py: {e}")
        return False

def check_env_file():
    """Check if .env file exists."""
    env_file = Path(".env")
    template_file = Path(".env.template")
    
    if not env_file.exists():
        if template_file.exists():
            print("🔧 Creating .env from template...")
            try:
                shutil.copy(template_file, env_file)
                print("✅ .env file created")
                print("⚠️  Please edit .env with your settings")
                return True
            except Exception as e:
                print(f"❌ Error creating .env: {e}")
                return False
        else:
            print("❌ .env.template not found")
            return False
    else:
        print("✅ .env file exists")
        return True

def check_credentials():
    """Check if credentials.json exists."""
    creds_file = Path("credentials.json")
    
    if not creds_file.exists():
        print("❌ credentials.json not found")
        print("   Download from Google Cloud Console:")
        print("   https://console.cloud.google.com/")
        return False
    else:
        print("✅ credentials.json exists")
        return True

def check_directories():
    """Create required directories."""
    dirs = ["logs", "attachments", "malware_scan_temp"]
    
    for dir_name in dirs:
        dir_path = Path(dir_name)
        try:
            dir_path.mkdir(exist_ok=True)
            print(f"✅ Directory {dir_name} ready")
        except Exception as e:
            print(f"❌ Error creating {dir_name}: {e}")
            return False
    
    return True

def main():
    """Main launch fixer."""
    print("=" * 60)
    print("🔧 Gmail Auto Printer - Launch Fixer")
    print("=" * 60)
    
    fixes = [
        ("Malware Scanner", fix_malware_scanner),
        ("Environment File", check_env_file),
        ("Credentials", check_credentials),
        ("Directories", check_directories),
    ]
    
    all_passed = True
    
    for fix_name, fix_func in fixes:
        print(f"\n🔍 Checking {fix_name}...")
        try:
            if not fix_func():
                all_passed = False
        except Exception as e:
            print(f"❌ Error in {fix_name}: {e}")
            all_passed = False
    
    print("\n" + "=" * 60)
    if all_passed:
        print("🎉 All fixes applied! Ready to launch.")
        print("\nTry running:")
        print("   python main.py --dry-run --once --debug")
    else:
        print("⚠️  Some issues remain. Check the output above.")
    print("=" * 60)

if __name__ == "__main__":
    main()